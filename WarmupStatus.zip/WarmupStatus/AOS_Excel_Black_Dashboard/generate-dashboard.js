/*
const fs = require("fs");
const path = require("path");
const XLSX = require("xlsx");

// ============================================================
// PATHS
// ============================================================

const dashboardFolder = __dirname;

// Parent folder:
// C:\Users\Userda57ac9a84f\Desktop\WarmupStatus
const workingFolder = path.dirname(dashboardFolder);

// Dashboard template
const templatePath = path.join(
    dashboardFolder,
    "dashboard_template.html"
);

// Generated dashboard
const outputPath = path.join(
    dashboardFolder,
    "dashboard.html"
);

// Optional command-line Excel file.
// Example:
// node generate-dashboard.js "C:\...\AOS_Result_20260911_063742.xlsx"
const commandLineExcel = process.argv[2];

// ============================================================
// FIND LATEST EXCEL FILE
// ============================================================

function findLatestExcel() {

    // If Excel file is explicitly supplied through command line,
    // use that file.
    if (commandLineExcel) {

        const suppliedPath = path.resolve(commandLineExcel);

        if (!fs.existsSync(suppliedPath)) {
            throw new Error(
                "Specified Excel file not found: " + suppliedPath
            );
        }

        return suppliedPath;
    }

    // Search the parent WarmupStatus folder
    // for timestamped files:
    //
    // AOS_Result_20260911_063742.xlsx
    //
    const files = fs.readdirSync(workingFolder)
        .filter(file =>
            /^AOS_Result_\d{8}_\d{6}\.xlsx$/i.test(file)
        )
        .map(file => {

            const fullPath = path.join(
                workingFolder,
                file
            );

            const stats = fs.statSync(fullPath);

            return {
                file,
                fullPath,
                modifiedTime: stats.mtimeMs
            };
        })
        .sort((a, b) =>
            b.modifiedTime - a.modifiedTime
        );

    // If timestamped Excel files exist,
    // use the newest one.
    if (files.length > 0) {
        return files[0].fullPath;
    }

    // Fallback:
    // AOS_Excel_Black_Dashboard\AOS_Result.xlsx
    const fallback = path.join(
        dashboardFolder,
        "AOS_Result.xlsx"
    );

    if (fs.existsSync(fallback)) {
        return fallback;
    }

    throw new Error(
        "No AOS_Result Excel file was found."
    );
}

// ============================================================
// GENERATE DASHBOARD
// ============================================================

function generate() {

    try {

        // ----------------------------------------------------
        // Find latest Excel
        // ----------------------------------------------------

        const excelPath = findLatestExcel();

        console.log("");
        console.log("==============================================");
        console.log("AOS AUTOMATION DASHBOARD GENERATOR");
        console.log("==============================================");
        console.log("");

        console.log("Working folder:");
        console.log(workingFolder);
        console.log("");

        console.log("Excel source:");
        console.log(excelPath);
        console.log("");

        // ----------------------------------------------------
        // Check template
        // ----------------------------------------------------

        if (!fs.existsSync(templatePath)) {

            throw new Error(
                "Dashboard template not found: " +
                templatePath
            );
        }

        // ----------------------------------------------------
        // Read Excel
        // ----------------------------------------------------

        const workbook = XLSX.readFile(excelPath);

        if (!workbook.SheetNames.length) {

            throw new Error(
                "Excel workbook contains no worksheets."
            );
        }

        const firstSheetName =
            workbook.SheetNames[0];

        const sheet =
            workbook.Sheets[firstSheetName];

        const rows =
            XLSX.utils.sheet_to_json(
                sheet,
                {
                    defval: ""
                }
            );

        // ----------------------------------------------------
        // Read template
        // ----------------------------------------------------

        let html =
            fs.readFileSync(
                templatePath,
                "utf8"
            );

        // ----------------------------------------------------
        // Convert Excel data to JSON
        // ----------------------------------------------------

        const jsonData =
            JSON.stringify(rows)
                .replace(/</g, "\\u003c");

        // ----------------------------------------------------
        // Inject Excel data
        // ----------------------------------------------------

        if (!html.includes("__DATA__")) {

            throw new Error(
                'Template does not contain "__DATA__" placeholder.'
            );
        }

        html =
            html.replace(
                "__DATA__",
                jsonData
            );

        // ----------------------------------------------------
        // Optional metadata placeholders
        //
        // These are optional. If they exist in the template,
        // they will automatically be replaced.
        // ----------------------------------------------------

        const generatedTime =
            new Date().toLocaleString();

        const sourceFile =
            path.basename(excelPath);

        html =
            html.replace(
                /__SOURCE_FILE__/g,
                sourceFile
            );

        html =
            html.replace(
                /__GENERATED_TIME__/g,
                generatedTime
            );

        html =
            html.replace(
                /__RECORD_COUNT__/g,
                String(rows.length)
            );

        // ----------------------------------------------------
        // Write dashboard
        // ----------------------------------------------------

        fs.writeFileSync(
            outputPath,
            html,
            "utf8"
        );

        // ----------------------------------------------------
        // Success output
        // ----------------------------------------------------

        console.log("Excel sheet:");
        console.log(firstSheetName);
        console.log("");

        console.log("Records:");
        console.log(rows.length);
        console.log("");

        console.log("Generated dashboard:");
        console.log(outputPath);
        console.log("");

        console.log("Generated at:");
        console.log(generatedTime);
        console.log("");

        console.log("==============================================");
        console.log("DASHBOARD UPDATED SUCCESSFULLY");
        console.log("==============================================");
        console.log("");

        return true;

    } catch (error) {

        console.error("");
        console.error("==============================================");
        console.error("DASHBOARD GENERATION FAILED");
        console.error("==============================================");
        console.error("");
        console.error(error.message);
        console.error("");

        process.exitCode = 1;

        return false;
    }
}

// ============================================================
// RUN
// ============================================================

generate();
*/

////////////////////////////////////////////////////////////////////////////////////////////



const fs = require("fs");
const path = require("path");
const XLSX = require("xlsx");

// ============================================================
// PATHS
// ============================================================

const dashboardFolder = __dirname;

// Parent folder:
// C:\Users\Userda57ac9a84f\Desktop\WarmupStatus
const workingFolder = path.dirname(dashboardFolder);

// Dashboard template
const templatePath = path.join(
    dashboardFolder,
    "dashboard_template.html"
);

// Generated dashboard
const outputPath = path.join(
    dashboardFolder,
    "dashboard.html"
);

// Optional command-line file.
//
// Example:
//
// node generate-dashboard.js "C:\\...\AOS_Result_20260911_063742.xlsx"
//
// OR
//
// node generate-dashboard.js "C:\\...\AOS_Result_20260911_063742.csv"

const commandLineFile = process.argv[2];


// ============================================================
// FIND LATEST EXCEL / CSV FILE
// ============================================================

function findLatestDataFile() {

    // --------------------------------------------------------
    // If a specific file is supplied through command line,
    // use that file.
    // --------------------------------------------------------

    if (commandLineFile) {

        const suppliedPath = path.resolve(commandLineFile);

        if (!fs.existsSync(suppliedPath)) {

            throw new Error(
                "Specified data file not found: " +
                suppliedPath
            );

        }

        const extension =
            path.extname(suppliedPath).toLowerCase();

        if (extension !== ".xlsx" &&
            extension !== ".csv") {

            throw new Error(
                "Unsupported file type: " +
                extension +
                ". Only .xlsx and .csv files are supported."
            );

        }

        return suppliedPath;
    }


    // --------------------------------------------------------
    // Search the WarmupStatus folder for:
    //
    // .xlsx
    // .csv
    //
    // Example:
    //
    // AOS_Result_20260911_063742.xlsx
    // AOS_Result_20260911_063742.csv
    //
    // --------------------------------------------------------

    const files = fs.readdirSync(workingFolder)

        .filter(file => {

            const extension =
                path.extname(file).toLowerCase();

            return (
                extension === ".xlsx" ||
                extension === ".csv"
            );

        })

        .map(file => {

            const fullPath =
                path.join(
                    workingFolder,
                    file
                );

            const stats =
                fs.statSync(fullPath);

            return {

                file: file,

                fullPath: fullPath,

                modifiedTime: stats.mtimeMs

            };

        })

        // Newest file first
        .sort((a, b) =>
            b.modifiedTime - a.modifiedTime
        );


    // --------------------------------------------------------
    // If XLSX/CSV files exist, return the newest one.
    // --------------------------------------------------------

    if (files.length > 0) {

        return files[0].fullPath;

    }


    // --------------------------------------------------------
    // Fallback files inside dashboard folder
    // --------------------------------------------------------

    const fallbackFiles = [

        path.join(
            dashboardFolder,
            "AOS_Result.xlsx"
        ),

        path.join(
            dashboardFolder,
            "AOS_Result.csv"
        )

    ];


    for (const fallback of fallbackFiles) {

        if (fs.existsSync(fallback)) {

            return fallback;

        }

    }


    // --------------------------------------------------------
    // Nothing found
    // --------------------------------------------------------

    throw new Error(
        "No .xlsx or .csv data file was found."
    );
}


// ============================================================
// GENERATE DASHBOARD
// ============================================================

function generate() {

    try {

        // ----------------------------------------------------
        // Find newest XLSX / CSV
        // ----------------------------------------------------

        const dataFile =
            findLatestDataFile();


        console.log("");

        console.log(
            "=============================================="
        );

        console.log(
            "AOS AUTOMATION DASHBOARD GENERATOR"
        );

        console.log(
            "=============================================="
        );

        console.log("");

        console.log(
            "Working folder:"
        );

        console.log(
            workingFolder
        );

        console.log("");

        console.log(
            "Latest data file:"
        );

        console.log(
            dataFile
        );

        console.log("");


        // ----------------------------------------------------
        // Check template
        // ----------------------------------------------------

        if (!fs.existsSync(templatePath)) {

            throw new Error(
                "Dashboard template not found: " +
                templatePath
            );

        }


        // ----------------------------------------------------
        // Determine file type
        // ----------------------------------------------------

        const extension =
            path.extname(dataFile)
                .toLowerCase();


        console.log(
            "File type:"
        );

        console.log(
            extension.toUpperCase()
        );

        console.log("");


        // ----------------------------------------------------
        // Read XLSX / CSV
        // ----------------------------------------------------

        const workbook =
            XLSX.readFile(dataFile);


        if (!workbook.SheetNames.length) {

            throw new Error(
                "The data file contains no worksheets."
            );

        }


        // ----------------------------------------------------
        // First worksheet
        //
        // For CSV there will normally be one worksheet.
        // For XLSX the first worksheet is used.
        // ----------------------------------------------------

        const firstSheetName =
            workbook.SheetNames[0];


        const sheet =
            workbook.Sheets[firstSheetName];


        // ----------------------------------------------------
        // Convert worksheet to JSON
        // ----------------------------------------------------

        const rows =
            XLSX.utils.sheet_to_json(
                sheet,
                {
                    defval: ""
                }
            );


        // ----------------------------------------------------
        // Read dashboard template
        // ----------------------------------------------------

        let html =
            fs.readFileSync(
                templatePath,
                "utf8"
            );


        // ----------------------------------------------------
        // Convert Excel/CSV data to JSON
        // ----------------------------------------------------

        const jsonData =
            JSON.stringify(rows)
                .replace(
                    /</g,
                    "\\u003c"
                );


        // ----------------------------------------------------
        // Check DATA placeholder
        // ----------------------------------------------------

        if (!html.includes("__DATA__")) {

            throw new Error(
                'Template does not contain "__DATA__" placeholder.'
            );

        }


        // ----------------------------------------------------
        // Inject data
        // ----------------------------------------------------

        html =
            html.replace(
                "__DATA__",
                jsonData
            );


        // ----------------------------------------------------
        // Metadata
        // ----------------------------------------------------

        const generatedTime =
            new Date().toLocaleString();


        const sourceFile =
            path.basename(dataFile);


        const sourceExtension =
            extension.toUpperCase();


        // ----------------------------------------------------
        // Replace optional placeholders
        // ----------------------------------------------------

        html =
            html.replace(
                /__SOURCE_FILE__/g,
                sourceFile
            );


        html =
            html.replace(
                /__GENERATED_TIME__/g,
                generatedTime
            );


        html =
            html.replace(
                /__RECORD_COUNT__/g,
                String(rows.length)
            );


        html =
            html.replace(
                /__SOURCE_TYPE__/g,
                sourceExtension
            );


        // ----------------------------------------------------
        // Write dashboard
        // ----------------------------------------------------

        fs.writeFileSync(
            outputPath,
            html,
            "utf8"
        );


        // ----------------------------------------------------
        // Success output
        // ----------------------------------------------------

        console.log(
            "Data source:"
        );

        console.log(
            sourceFile
        );

        console.log("");

        console.log(
            "File type:"
        );

        console.log(
            sourceExtension
        );

        console.log("");

        console.log(
            "Excel/CSV sheet:"
        );

        console.log(
            firstSheetName
        );

        console.log("");

        console.log(
            "Records:"
        );

        console.log(
            rows.length
        );

        console.log("");

        console.log(
            "Generated dashboard:"
        );

        console.log(
            outputPath
        );

        console.log("");

        console.log(
            "Generated at:"
        );

        console.log(
            generatedTime
        );

        console.log("");

        console.log(
            "=============================================="
        );

        console.log(
            "DASHBOARD UPDATED SUCCESSFULLY"
        );

        console.log(
            "=============================================="
        );

        console.log("");


        return true;

    }

    catch (error) {

        console.error("");

        console.error(
            "=============================================="
        );

        console.error(
            "DASHBOARD GENERATION FAILED"
        );

        console.error(
            "=============================================="
        );

        console.error("");

        console.error(
            error.message
        );

        console.error("");

        process.exitCode = 1;

        return false;
    }
}


// ============================================================
// RUN
// ============================================================

generate();
