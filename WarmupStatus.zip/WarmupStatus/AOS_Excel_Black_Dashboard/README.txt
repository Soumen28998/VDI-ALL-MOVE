AOS Excel Dashboard
====================

Folder contents
---------------
AOS_Result.xlsx
dashboard_template.html
generate-dashboard.js
dashboard.html
package.json

1. Install Node.js
------------------
Make sure `node` and `npm` work in Command Prompt:
    node -v
    npm -v

2. Open Command Prompt in this folder
-------------------------------------
cd /d "PATH_TO_THIS_FOLDER"

3. Install dependency
---------------------
npm install

4. Generate dashboard once
--------------------------
npm run dashboard

5. Automatically regenerate when Excel changes
-----------------------------------------------
npm run watch

The watcher reads the first worksheet of AOS_Result.xlsx whenever the
Excel file is saved/changed and regenerates dashboard.html.

Important:
- Keep the Excel column names S.No, URL, SERVER AOS ID and STATUS.
- You can add/remove rows; KPIs, charts, filters and table update automatically.
- The browser does not automatically reload by itself. For automatic browser
  reload too, open the dashboard through a small local server/browser watcher,
  or use a browser extension. The Excel-to-HTML regeneration is automatic.
