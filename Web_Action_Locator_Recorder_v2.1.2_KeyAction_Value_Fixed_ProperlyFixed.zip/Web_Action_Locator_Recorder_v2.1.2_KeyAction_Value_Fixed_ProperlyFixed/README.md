# Web Action & Locator Recorder — v2.1.2 Updated

This build preserves the v2.1.2 recorder architecture and adds the requested Excel analytics, locator naming, red locator extraction highlight, clear-extracted-locator control, and refreshed popup UI.

## Preserved behavior
- Smart click recording
- Consolidated Fill/input recording with final values
- Password masking
- Navigation recording
- Keyboard action recording
- Multiple automation-ready locators
- Dynamic-looking IDs are retained as the Perfect Locator when an ID exists
- No floating recorder panel
- Session history and step editing/deletion

## First Excel sheet: Test Steps
The first sheet contains 35 columns:
1. S.No
2. Action
3. Element
4. Text
5. Value
6. Page Title
7. Page URL
8. Element Type
9. Visible Text
10. Name
11. Label
12. Role
13. Placeholder
14. ARIA Label
15. Title
16. Perfect Locator
17. Locator Type
18. Alternative Locator 1
19. Alternative Locator 2
20. CSS Selector
21. XPath
22. Stability Score
23. Confidence
24. Captured At
25. Page Views
26. Clicks
27. Scrolls
28. Form Inputs (Field Interactions)
29. Navigation Paths
30. Time Spent on Page
31. Errors
32. Crashes
33. Failed API Calls
34. Load Time (ms)
35. Latency (ms)

Additional workbook sheets include Locator Details, Element Details, Locator Validation, Navigation, Recording Info, Performance Analytics, and Failed API Calls.
