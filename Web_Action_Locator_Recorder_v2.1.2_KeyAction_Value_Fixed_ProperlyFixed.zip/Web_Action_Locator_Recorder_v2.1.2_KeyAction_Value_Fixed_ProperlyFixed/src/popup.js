const $=s=>document.querySelector(s);
const send=(type,p={})=>chrome.runtime.sendMessage({type,...p});
let st={},inspectResult=null,renderedLocators=[];
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
function showMessage(message){const el=$('#message');el.textContent=message;el.classList.remove('hidden');clearTimeout(showMessage.t);showMessage.t=setTimeout(()=>el.classList.add('hidden'),2400)}
async function refresh(){const r=await send('GET_STATE');st=r.state||{};const recording=!!st.recording;$('#status').className='status '+(recording?'recording':'stopped');$('#status').innerHTML=`<span class="pulse"></span><span>${recording?(st.paused?'Paused':'Recording'):'Stopped'}</span>`;$('#dot').className='dot '+(recording&&!st.paused?'on':'');$('#name').textContent=st.recordingName||'—';const q=await send('GET_SESSIONS'),s=(q.sessions||[]).find(x=>x.id===st.sessionId);$('#count').textContent=s?.steps?.length||0}
function locatorRows(result){if(!result)return[];const p=result.locators?.primary||{},rows=[];if(p.id)rows.push({type:'Perfect Locator',locator:p.id});if(p.css)rows.push({type:'Alternative Locator 1',locator:p.css});if(p.preferred)rows.push({type:'Alternative Locator 2',locator:p.preferred});for(const x of result.locators?.additional||[])if(x?.locator&&!rows.some(r=>r.locator===x.locator))rows.push({type:x.type||'Additional Locator',locator:x.locator});return rows}
function renderInspect(){const section=$('#locatorSection');if(!inspectResult){section.classList.add('hidden');renderedLocators=[];return}renderedLocators=locatorRows(inspectResult);section.classList.remove('hidden');const d=inspectResult,parts=[d.elementType||d.tag,d.visibleText?`Text: ${d.visibleText}`:'',d.name?`Name: ${d.name}`:'',d.label?`Label: ${d.label}`:'',d.role?`Role: ${d.role}`:''].filter(Boolean);$('#elementMeta').textContent=parts.join('  •  ')||'Element details unavailable';$('#noLocator').classList.toggle('hidden',renderedLocators.length>0);$('#locatorList').innerHTML=renderedLocators.map((x,i)=>`<div class="loc-row"><div class="loc-head"><span class="loc-type">${esc(x.type)}</span><button class="copy" data-i="${i}">Copy</button></div><div class="loc-value">${esc(x.locator)}</div></div>`).join('');document.querySelectorAll('.copy').forEach(btn=>btn.onclick=async()=>{const x=renderedLocators[+btn.dataset.i];if(!x)return;await navigator.clipboard.writeText(x.locator);btn.textContent='Copied';setTimeout(()=>btn.textContent='Copy',900)})}
async function loadInspect(){const r=await chrome.storage.local.get('inspectResult');inspectResult=r.inspectResult||null;renderInspect()}
$('#extract').onclick=async()=>{await send('CLEAR_INSPECT');await send('INSPECT_MODE',{enabled:true});showMessage('Click an element on the webpage to extract its locators.');window.close()};
$('#clearExtract').onclick=async()=>{await send('CLEAR_INSPECT');inspectResult=null;renderInspect();showMessage('Extracted locator cleared.')};
$('#start').onclick=async()=>{const n=prompt('Recording name:','Web Recording '+new Date().toLocaleString());if(n!==null){await send('START',{name:n});await refresh();showMessage('Recording started.')}};
$('#stop').onclick=async()=>{await send('STOP');await refresh();showMessage('Recording stopped.')};
$('#clear').onclick=async()=>{if(!confirm('Clear all recorded data? Extracted locator data will also be cleared.'))return;await send('CLEAR_DATA');inspectResult=null;renderInspect();await refresh();showMessage('Recorded data cleared.')};
function allLocatorsText(){return renderedLocators.map(x=>`${x.type}: ${x.locator}`).join('\n')}
$('#copyAll').onclick=async()=>{const t=allLocatorsText();if(!t)return;await navigator.clipboard.writeText(t);showMessage('All locators copied.')};
function valueForAction(x){return ['Fill','Search'].includes(x.action)?String(x.value??''):''}
function finalMetrics(a,s){
  const snaps=a.map(x=>x.analytics||{});
  const last=snaps[snaps.length-1]||{};
  const navCount=a.filter(x=>x.action==='Navigation').length;
  const clickCount=a.filter(x=>['Click','Double Click'].includes(x.action)).length;
  const formCount=a.filter(x=>['Fill','Search','Select','Check','Uncheck'].includes(x.action)).length;
  const scrollMax=Math.max(0,...snaps.map(x=>Number(x.scrolls||0)));
  const errorMax=Math.max(0,...snaps.map(x=>Number(x.errors||0)));
  const crashMax=Math.max(0,...snaps.map(x=>Number(x.crashes||0)));
  const apiMax=Math.max(0,...snaps.map(x=>Number(x.failedApiCalls||0)));
  const loadMax=Math.max(0,...snaps.map(x=>Number(x.loadTime||0)));
  const latencyMax=Math.max(0,...snaps.map(x=>Number(x.latency||0)));
  return {
    pageViews:Math.max(Number(s?.metrics?.pageViews||0),navCount||1),
    clicks:Math.max(Number(s?.metrics?.clicks||0),clickCount),
    scrolls:Math.max(Number(s?.metrics?.scrolls||0),scrollMax),
    formInputs:Math.max(Number(s?.metrics?.formInputs||0),formCount),
    errors:Math.max(Number(s?.metrics?.errors||0),errorMax),
    crashes:Math.max(Number(s?.metrics?.crashes||0),crashMax),
    failedApiCalls:Math.max(Number(s?.metrics?.failedApiCalls||0),apiMax),
    loadTime:Math.max(Number(s?.metrics?.loadTime||0),loadMax),
    latency:Math.max(Number(s?.metrics?.latency||0),latencyMax),
    navigationPaths:a.filter(x=>x.action==='Navigation').map(x=>`${x.fromUrl||''} → ${x.toUrl||x.url||''}`).filter(Boolean)
  };
}
function stepMetrics(a,index,s){
  const x=a[index]||{};
  const cur=index===a.length-1?{...(x.analytics||{}),...(s?.metrics||{})}:(x.analytics||{});
  const prev=a[index-1]?.analytics||{};
  const delta=(k)=>Math.max(0,Number(cur[k]||0)-Number(prev[k]||0));
  const isClick=['Click','Double Click'].includes(x.action);
  const isForm=['Fill','Search','Select','Check','Uncheck'].includes(x.action);
  const nav=x.action==='Navigation';
  return {
    pageViews:nav?1:0,
    clicks:isClick?1:0,
    scrolls:delta('scrolls'),
    formInputs:isForm?1:0,
    errors:delta('errors'),
    crashes:delta('crashes'),
    failedApiCalls:delta('failedApiCalls'),
    loadTime:nav?Number(cur.loadTime||0):0,
    latency:nav?Number(cur.latency||0):0,
    navigationPaths:nav&&x.fromUrl&& (x.toUrl||x.url)?`${x.fromUrl} → ${x.toUrl||x.url}`:'',
    timeSpentOnPage:Number(cur.timeSpentOnPage||0)
  };
}
function exportSession(s){
  if(!s)return false;
  const a=s.steps||[],agg=finalMetrics(a,s);
  const rows=a.map((x,i)=>{
    const d=x.elementDetails||{},m=stepMetrics(a,i,s);
    return {
      'S.No':i+1,Action:x.action||'',Element:x.element||'',Text:x.text||'',Value:valueForAction(x),
      'Page Title':x.pageTitle||'','Page URL':x.url||'','Element Type':d.elementType||d.tag||'',
      'Visible Text':d.visibleText||'',Name:d.name||'',Label:d.label||'',Role:d.role||'',Placeholder:d.placeholder||'',
      'ARIA Label':d.ariaLabel||'',Title:d.title||'','Perfect Locator':x.idLocator||'',
      'Locator Type':x.idLocator?'ID':x.preferredLocator?'Semantic/CSS':'',
      'Alternative Locator 1':x.cssLocator||'','Alternative Locator 2':x.preferredLocator||'',
      'CSS Selector':x.cssLocator||'','XPath':x.xpath||'',
      'Stability Score':d.idType==='Stable-looking'?'95':d.idType==='Dynamic-looking'?'70':x.preferredLocator?'85':x.cssLocator?'75':'50',
      Confidence:x.idLocator?'High':x.preferredLocator?'Medium':'Low','Captured At':x.timestamp||'',
      'Page Views':m.pageViews,'Clicks':m.clicks,'Scrolls':m.scrolls,
      'Form Inputs (Field Interactions)':m.formInputs,'Navigation Paths':m.navigationPaths,
      'Time Spent on Page':m.timeSpentOnPage?`${Math.round(m.timeSpentOnPage/1000)} sec`:'',
      Errors:m.errors,Crashes:m.crashes,'Failed API Calls':m.failedApiCalls,
      'Load Time (ms)':m.loadTime,'Latency (ms)':m.latency
    };
  });
  const loc=[];a.forEach(x=>(x.locatorDetails||[]).forEach(y=>loc.push({Step:x.step,'Locator Type':y.type,Locator:y.locator,'Match Count':y.matchCount,Status:y.status})));
  const el=a.map(x=>{const d=x.elementDetails||{};return{Step:x.step,'Element Type':d.elementType||d.tag||'','Visible Text':d.visibleText||'',Name:d.name||'',Label:d.label||'',Role:d.role||'',Tag:d.tag||'',Type:d.type||'',ID:d.id||'','ID Type':d.idType||'','ARIA Label':d.ariaLabel||'','ARIA Expanded':d.ariaExpanded||'','ARIA Haspopup':d.ariaHaspopup||'',Placeholder:d.placeholder||'',Title:d.title||'',Class:d.class||'',Text:d.text||'',Href:d.href||''}});
  const navigation=a.filter(x=>x.action==='Navigation').map(x=>({Step:x.step,'From URL':x.fromUrl||'','To URL':x.toUrl||x.url||'','Page Title':x.pageTitle||'','Time Spent (ms)':x.analytics?.timeSpentOnPage||'',Timestamp:x.timestamp||''}));
  const failures=(s.metrics?.apiFailures||[]).map(f=>({Step:'',URL:f.url,Status:f.statusCode,Error:f.error||'',Latency:f.latencyMs,Timestamp:f.at}));
  const info=[{'Recording Name':s.name,'Start Time':s.startTime,'Last Updated':s.lastUpdated,'Total Steps':a.length,Browser:s.browser,'Password Masking':'Enabled by default'}];
  const perf=[['Page Views',agg.pageViews],['Clicks',agg.clicks],['Scrolls',agg.scrolls],['Form Inputs (Field Interactions)',agg.formInputs],['Errors',agg.errors],['Crashes',agg.crashes],['Failed API Calls',agg.failedApiCalls],['Load Time (ms)',agg.loadTime],['Latency (ms)',agg.latency]].map(([Metric,Value])=>({Metric,Value}));
  const wb=XLSX.utils.book_new();
  [['Test Steps',rows],['Locator Details',loc],['Element Details',el],['Locator Validation',loc],['Navigation',navigation],['Recording Info',info],['Performance Analytics',perf],['Failed API Calls',failures]].forEach(([n,d])=>{const ws=XLSX.utils.json_to_sheet(d);if(n==='Test Steps')ws['!cols']=Array.from({length:35},()=>({wch:20}));XLSX.utils.book_append_sheet(wb,ws,n)});
  XLSX.writeFile(wb,(s.name||'recording').replace(/[\\/:*?"<>|]/g,'_')+'.xlsx');
  return true;
}
$('#download').onclick=async()=>{const q=await send('GET_SESSIONS'),sessions=q.sessions||[];if(!sessions.length){showMessage('No recorded sessions available.');return}if(exportSession(sessions[0]))showMessage('Excel downloaded for the latest recording.')};
refresh();loadInspect();
