const http = require("http");
const fs = require("fs");
const path = require("path");
const { exec } = require("child_process");

const ROOT = __dirname;
const PUBLIC = path.join(ROOT, "public");
const DATA = path.join(ROOT, "data");

const C = JSON.parse(
  fs.readFileSync(
    path.join(ROOT, "config.json"),
    "utf8"
  )
);

const STATUS = path.join(DATA, "status.json");
const JOB = path.join(DATA, "current-job.json");
const HISTORY = path.join(DATA, "history.json");

// ======================================================
// CREATE DATA FOLDER IF IT DOES NOT EXIST
// ======================================================

if (!fs.existsSync(DATA)) {
  fs.mkdirSync(DATA, {
    recursive: true
  });
}

// ======================================================
// FILE HELPERS
// ======================================================

const read = (file, defaultValue) => {
  try {
    return JSON.parse(
      fs.readFileSync(file, "utf8")
    );
  } catch {
    return defaultValue;
  }
};

const write = (file, value) => {
  fs.writeFileSync(
    file,
    JSON.stringify(value, null, 2),
    "utf8"
  );
};

// ======================================================
// COMPANY DETECTION
// ======================================================

const company = (name) => {
  const upperName = String(name || "")
    .toUpperCase();

  return (
    (C.companyCodes || []).find(code =>
      upperName.includes(
        String(code).toUpperCase()
      )
    ) || "OTHER"
  );
};

// ======================================================
// SCAN EXCEL FOLDER
// ======================================================

function scan() {

  if (!fs.existsSync(C.folderPath)) {
    console.log(
      "Excel folder does not exist:",
      C.folderPath
    );

    return [];
  }

  return fs
    .readdirSync(C.folderPath)

    // Only Excel files
    .filter(name =>
      /\.(xlsx|xls)$/i.test(name)
    )

    .map(name => ({
      name: name,
      company: company(name)
    }))

    .sort((a, b) =>
      a.name.localeCompare(b.name)
    );
}

// ======================================================
// RESET CURRENT RUN
// ======================================================

function fresh() {

  const result = {};

  for (const file of scan()) {

    result[file.name] = {
      status: "READY",
      company: file.company,
      lastRun: null,
      startedAt: null,
      completedAt: null,
      durationMs: null,
      retries: 0,
      error: null
    };
  }

  write(
    STATUS,
    result
  );

  return Object.keys(result);
}

// ======================================================
// SYNC STATUS WITH EXCEL FOLDER
// ======================================================

function sync() {

  const old = read(
    STATUS,
    {}
  );

  const result = {};

  for (const file of scan()) {

    result[file.name] = {

      status: "READY",

      company: file.company,

      lastRun: null,

      startedAt: null,

      completedAt: null,

      durationMs: null,

      retries: 0,

      error: null,

      ...(old[file.name] || {})
    };
  }

  write(
    STATUS,
    result
  );

  return Object.keys(result);
}

// ======================================================
// SEND JSON RESPONSE
// ======================================================

function send(
  response,
  statusCode,
  value
) {

  response.writeHead(
    statusCode,
    {
      "Content-Type":
        "application/json",

      "Cache-Control":
        "no-store"
    }
  );

  response.end(
    JSON.stringify(value)
  );
}

// ======================================================
// READ JSON REQUEST BODY
// ======================================================

async function jsonBody(req) {

  let body = "";

  for await (const chunk of req) {
    body += chunk;
  }

  if (!body) {
    return {};
  }

  return JSON.parse(body);
}

// ======================================================
// NORMALIZE SELECTED FILES
// ======================================================

function normalizeSelectedFiles(input) {

  if (!Array.isArray(input)) {
    return [];
  }

  return input

    .map(item => {

      // Normal string
      if (
        typeof item === "string"
      ) {
        return item.trim();
      }

      // Object formats
      if (
        item &&
        typeof item === "object"
      ) {

        return String(
          item.name ??
          item.fileName ??
          item.filename ??
          item.value ??
          ""
        ).trim();
      }

      return "";
    })

    .filter(Boolean);
}

// ======================================================
// API
// ======================================================

async function api(
  req,
  res,
  urlPath
) {

  // ====================================================
  // GET FILES
  // ====================================================

  if (
    req.method === "GET" &&
    urlPath === "/api/files"
  ) {

    const files = scan();

    const oldStatus =
      read(
        STATUS,
        {}
      );

    const newStatus = {};

    for (const file of files) {

      newStatus[file.name] = {

        status: "READY",

        company: file.company,

        lastRun: null,

        startedAt: null,

        completedAt: null,

        durationMs: null,

        retries: 0,

        error: null,

        ...(oldStatus[file.name] || {})
      };
    }

    write(
      STATUS,
      newStatus
    );

    return send(
      res,
      200,
      {
        files: files,
        status: newStatus
      }
    );
  }

  // ====================================================
  // GET CURRENT JOB
  // ====================================================

  if (
    req.method === "GET" &&
    urlPath === "/api/job"
  ) {

    return send(
      res,
      200,
      read(
        JOB,
        {}
      )
    );
  }

  // ====================================================
  // GET CONFIG
  // ====================================================

  if (
    req.method === "GET" &&
    urlPath === "/api/config"
  ) {

    return send(
      res,
      200,
      {
        folderPath:
          C.folderPath,

        pollMs:
          C.pollMs || 2000,

        companyCodes:
          C.companyCodes,

        autoTriggerPAD:
          C.autoTriggerPAD,

        padWorkflowId:
          !!C.padWorkflowId
      }
    );
  }

  // ====================================================
  // NEW RUN
  // ====================================================

  if (
    req.method === "POST" &&
    urlPath === "/api/new-run"
  ) {

    const files = fresh();

    const job = {

      jobId:
        `JOB-${Date.now()}`,

      selectedFiles: [],

      status: "READY",

      createdAt:
        new Date().toISOString(),

      startedAt: null,

      completedAt: null
    };

    write(
      JOB,
      job
    );

    console.log("");
    console.log(
      "======================================"
    );
    console.log(
      "NEW RUN"
    );
    console.log(
      "Files found:",
      files.length
    );
    console.log(
      "======================================"
    );
    console.log("");

    return send(
      res,
      200,
      {
        success: true,
        files: files
      }
    );
  }

  // ====================================================
  // RUN SELECTED
  // ====================================================

  if (
    req.method === "POST" &&
    urlPath === "/api/run"
  ) {

    const body =
      await jsonBody(req);

    console.log("");
    console.log(
      "======================================"
    );

    console.log(
      "RUN SELECTED REQUEST"
    );

    console.log(
      "Received body:"
    );

    console.log(
      JSON.stringify(
        body,
        null,
        2
      )
    );

    // -----------------------------------------------
    // Get selected files from dashboard
    // -----------------------------------------------

    const selectedFiles =
      normalizeSelectedFiles(
        body.selectedFiles || []
      );

    console.log(
      "Selected files:"
    );

    console.log(
      selectedFiles
    );

    // -----------------------------------------------
    // IMPORTANT FIX
    //
    // scan() returns:
    //
    // {
    //   name: "file.xlsx",
    //   company: "OV01"
    // }
    //
    // Therefore we must create the Set from .name
    // -----------------------------------------------

    const available =
      new Set(
        scan().map(
          file => file.name
        )
      );

    console.log(
      "Available files:"
    );

    console.log(
      [...available]
    );

    // -----------------------------------------------
    // Validate selected files
    // -----------------------------------------------

    const files =
      selectedFiles.filter(
        file =>
          available.has(file)
      );

    console.log(
      "Valid files:"
    );

    console.log(
      files
    );

    console.log(
      "======================================"
    );

    // -----------------------------------------------
    // No valid files
    // -----------------------------------------------

    if (!files.length) {

      return send(
        res,
        400,
        {
          success: false,

          message:
            "No valid files selected",

          received:
            selectedFiles,

          available:
            [...available]
        }
      );
    }

    // -----------------------------------------------
    // Create Job
    // -----------------------------------------------

    const job = {

      jobId:
        `JOB-${Date.now()}`,

      selectedFiles:
        files,

      status:
        "QUEUED",

      createdAt:
        new Date().toISOString(),

      startedAt:
        null,

      completedAt:
        null
    };

    write(
      JOB,
      job
    );

    // -----------------------------------------------
    // Update file status
    // -----------------------------------------------

    const status =
      read(
        STATUS,
        {}
      );

    files.forEach(
      fileName => {

        status[fileName] = {

          ...(status[fileName] || {}),

          status:
            "QUEUED",

          error:
            null,

          startedAt:
            null,

          completedAt:
            null,

          durationMs:
            null
        };
      }
    );

    write(
      STATUS,
      status
    );

    // -----------------------------------------------
    // OPTIONAL PAD AUTO TRIGGER
    // -----------------------------------------------

    if (
      C.autoTriggerPAD &&
      C.padWorkflowId
    ) {

      const powerAutomateUrl =
        `ms-powerautomate:/console/flow/run?workflowId=${encodeURIComponent(
          C.padWorkflowId
        )}&runId=${encodeURIComponent(
          job.jobId
        )}`;

      console.log(
        "Power Automate trigger:"
      );

      console.log(
        powerAutomateUrl
      );

      exec(
        `start "" "${powerAutomateUrl}"`,
        () => {}
      );
    }

    return send(
      res,
      200,
      {
        success: true,
        job: job
      }
    );
  }

  // ====================================================
  // RETRY
  // ====================================================

  if (
    req.method === "POST" &&
    urlPath === "/api/retry"
  ) {

    const body =
      await jsonBody(req);

    const fileName =
      String(
        body.fileName || ""
      ).trim();

    const status =
      read(
        STATUS,
        {}
      );

    if (
      !status[fileName]
    ) {

      return send(
        res,
        404,
        {
          success: false,

          message:
            "File not found"
        }
      );
    }

    status[fileName] = {

      ...status[fileName],

      status:
        "QUEUED",

      error:
        null,

      durationMs:
        null,

      retries:
        Number(
          status[fileName].retries || 0
        ) + 1
    };

    write(
      STATUS,
      status
    );

    const job = {

      ...read(
        JOB,
        {}
      ),

      jobId:
        `JOB-${Date.now()}`,

      selectedFiles:
        [fileName],

      status:
        "QUEUED",

      createdAt:
        new Date().toISOString()
    };

    write(
      JOB,
      job
    );

    return send(
      res,
      200,
      {
        success: true,
        job: job
      }
    );
  }

  // ====================================================
  // PAD STATUS UPDATE
  // ====================================================

  if (
    req.method === "POST" &&
    urlPath === "/api/pad/status"
  ) {

    const body =
      await jsonBody(req);

    const status =
      read(
        STATUS,
        {}
      );

    const now =
      new Date().toISOString();

    const fileName =
      String(
        body.fileName || ""
      ).trim();

    if (!fileName) {

      return send(
        res,
        400,
        {
          success: false,

          message:
            "fileName is required"
        }
      );
    }

    if (
      !status[fileName]
    ) {

      status[fileName] = {

        company:
          company(fileName),

        retries:
          0
      };
    }

    const item =
      status[fileName];

    item.status =
      String(
        body.status || ""
      ).toUpperCase();

    // -----------------------------------------------
    // RUNNING
    // -----------------------------------------------

    if (
      item.status === "RUNNING"
    ) {

      item.startedAt =
        now;

      item.error =
        null;
    }

    // -----------------------------------------------
    // SUCCESS / FAILED
    // -----------------------------------------------

    else if (
      [
        "SUCCESS",
        "FAILED"
      ].includes(
        item.status
      )
    ) {

      item.completedAt =
        now;

      if (
        item.startedAt
      ) {

        item.durationMs =
          new Date(now) -
          new Date(
            item.startedAt
          );
      }

      item.error =
        body.error || null;
    }

    // -----------------------------------------------
    // RETRIES
    // -----------------------------------------------

    if (
      body.retries != null
    ) {

      item.retries =
        Number(
          body.retries
        );
    }

    item.lastRun =
      now;

    write(
      STATUS,
      status
    );

    // -----------------------------------------------
    // UPDATE JOB
    // -----------------------------------------------

    const job =
      read(
        JOB,
        {}
      );

    if (
      item.status === "RUNNING"
    ) {

      job.status =
        "RUNNING";

      job.startedAt =
        job.startedAt ||
        now;
    }

    // -----------------------------------------------
    // CHECK JOB COMPLETION
    // -----------------------------------------------

    if (
      [
        "SUCCESS",
        "FAILED"
      ].includes(
        item.status
      )
    ) {

      const selected =
        job.selectedFiles ||
        [];

      const finished =
        selected.length > 0 &&
        selected.every(
          file =>
            [
              "SUCCESS",
              "FAILED"
            ].includes(
              (
                status[file] ||
                {}
              ).status
            )
        );

      if (finished) {

        job.status =
          selected.some(
            file =>
              status[file].status ===
              "FAILED"
          )
            ? "FAILED"
            : "SUCCESS";

        job.completedAt =
          now;

        job.durationMs =
          job.startedAt
            ? new Date(now) -
              new Date(
                job.startedAt
              )
            : null;

        const history =
          read(
            HISTORY,
            []
          );

        history.unshift(
          job
        );

        write(
          HISTORY,
          history.slice(
            0,
            100
          )
        );
      }
    }

    write(
      JOB,
      job
    );

    return send(
      res,
      200,
      {
        success: true,
        job: job,
        status: item
      }
    );
  }

  return false;
}

// ======================================================
// MIME TYPES
// ======================================================

const MIME = {

  ".html":
    "text/html",

  ".css":
    "text/css",

  ".js":
    "application/javascript",

  ".json":
    "application/json"
};

// ======================================================
// HTTP SERVER
// ======================================================

const server =
  http.createServer(
    async (
      req,
      res
    ) => {

      try {

        const url =
          new URL(
            req.url,

            `http://${
              req.headers.host ||
              "localhost"
            }`
          );

        // ---------------------------------------------
        // API
        // ---------------------------------------------

        if (
          url.pathname.startsWith(
            "/api/"
          )
        ) {

          const handled =
            await api(
              req,
              res,
              url.pathname
            );

          if (
            handled !== false
          ) {
            return;
          }
        }

        // ---------------------------------------------
        // STATIC FILES
        // ---------------------------------------------

        const requestedPath =
          url.pathname === "/"
            ? "/index.html"
            : url.pathname;

        const filePath =
          path.normalize(
            path.join(
              PUBLIC,
              requestedPath
            )
          );

        if (
          !filePath.startsWith(
            PUBLIC
          ) ||
          !fs.existsSync(
            filePath
          )
        ) {

          return send(
            res,
            404,
            {
              message:
                "Not found"
            }
          );
        }

        res.writeHead(
          200,
          {
            "Content-Type":
              MIME[
                path.extname(
                  filePath
                )
              ] ||
              "application/octet-stream",

            "Cache-Control":
              "no-store"
          }
        );

        fs.createReadStream(
          filePath
        ).pipe(res);

      } catch (error) {

        console.error(
          error
        );

        send(
          res,
          500,
          {
            message:
              error.message
          }
        );
      }
    }
  );

// ======================================================
// START SERVER
// ======================================================

server.listen(
  C.port,
  () => {

    console.log("");

    console.log(
      "======================================"
    );

    console.log(
      "   EXCEL PAD TRADING DASHBOARD"
    );

    console.log(
      "======================================"
    );

    console.log(
      `Dashboard: http://localhost:${C.port}`
    );

    console.log(
      `Watching folder: ${C.folderPath}`
    );

    console.log("");

    console.log(
      "Excel files detected:"
    );

    const files =
      scan();

    if (
      !files.length
    ) {

      console.log(
        "  No Excel files found."
      );

    } else {

      files.forEach(
        file => {

          console.log(
            `  ${file.name} [${file.company}]`
          );
        }
      );
    }

    console.log("");

    console.log(
      "Server is running..."
    );

    console.log(
      "======================================"
    );

    console.log("");

  }
);