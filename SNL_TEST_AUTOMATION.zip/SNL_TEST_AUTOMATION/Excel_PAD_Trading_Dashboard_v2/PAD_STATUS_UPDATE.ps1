param([Parameter(Mandatory=$true)][string]$FileName,[Parameter(Mandatory=$true)][string]$Status,[string]$ErrorMessage="",[int]$Retries=-1)
$body=@{fileName=$FileName;status=$Status;error=$ErrorMessage;retries=$Retries}|ConvertTo-Json
try{Invoke-RestMethod -Uri "http://localhost:3030/api/pad/status" -Method Post -ContentType "application/json" -Body $body|Out-Null}catch{Write-Host "Dashboard API unavailable: $($_.Exception.Message)"}
