# Excel PAD Trading Dashboard v2

Run `npm start`. Chrome opens automatically. Click **New Run** to clear the current run and rescan Excel files. Select files, then Run Selected. PAD reads `data/current-job.json` and reports status through `PAD_STATUS_UPDATE.ps1` or POST `/api/pad/status`. Historical runs remain in `data/history.json`.
