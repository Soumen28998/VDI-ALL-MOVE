const fs = require("fs");
const path = require("path");
const XLSX = require("xlsx");

const excelPath = path.resolve(process.argv[2] || "./AOS_Result.xlsx");
const outputPath = path.resolve(process.argv[3] || "./dashboard.html");

function generate() {
  if (!fs.existsSync(excelPath)) {
    console.error("Excel file not found:", excelPath);
    process.exitCode = 1;
    return;
  }
  const wb = XLSX.readFile(excelPath);
  const sheet = wb.Sheets[wb.SheetNames[0]];
  const rows = XLSX.utils.sheet_to_json(sheet, { defval: "" });

  const template = fs.readFileSync(path.join(__dirname, "dashboard_template.html"), "utf8");
  const html = template.replace("__DATA__", JSON.stringify(rows).replace(/</g, "\\u003c"));
  fs.writeFileSync(outputPath, html, "utf8");
  console.log(new Date().toLocaleString(), "Dashboard updated:", rows.length, "records");
}

generate();
if (process.argv.includes("--watch")) {
  let timer;
  console.log("Watching:", excelPath);
  fs.watch(excelPath, () => {
    clearTimeout(timer);
    timer = setTimeout(generate, 500);
  });
}
