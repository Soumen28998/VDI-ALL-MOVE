import { Page, Locator, expect } from '@playwright/test';
import { ENV } from '../config/env.config';
import { PageUtil } from '../utils/page.util';

/**
 * Page Object Model for Supplier Management in Orkla Dynamics 365
 * Encapsulates all locators and interaction methods for the Supplier (Vendor) pages
 */
export class SupplierPage {
    private readonly page: Page;

    // ─── Selectors ────────────────────────────────────────────────────────────────

    private readonly SELECTORS = {
        // General Section
        GENERAL_TAB_CAPTION: ['button[id*="TabGeneral_caption"]'],
        IDENTIFICATION_HEADING: ['text=Identification'],
        SUPPLIER_ID_INPUT: ['input[name="Identification_AccountNum"]'],
        NAME_INPUT: ['input[aria-labelledby*="Name"]'],
        NAME_ALIAS_INPUT: ['input[aria-labelledby*="NameAlias"]'],
        GROUP_INPUT: ['select[aria-labelledby*="Group"]', 'input[aria-labelledby*="Group"]'],
        TAX_GROUP_INPUT: ['select[aria-labelledby*="SalesTax_TaxGroup"]', 'input[aria-labelledby*="SalesTax_TaxGroup"]'],

    } as const;

    constructor(page: Page) {
        this.page = page;
    }

    // ─── Locators ────────────────────────────────────────────────────────────────

    // General Section
    get generalTabCaption(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, [...this.SELECTORS.GENERAL_TAB_CAPTION]);
    }

    get identificationHeading(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, [...this.SELECTORS.IDENTIFICATION_HEADING]);
    }

    get supplierIdInput(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, [...this.SELECTORS.SUPPLIER_ID_INPUT]);
    }

    get nameInput(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, [...this.SELECTORS.NAME_INPUT]);
    }

    get nameAliasInput(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, [...this.SELECTORS.NAME_ALIAS_INPUT]);
    }

    get groupInput(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, [...this.SELECTORS.GROUP_INPUT]);
    }

    get taxGroupInput(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, [...this.SELECTORS.TAX_GROUP_INPUT]);
    }

    get saveButton(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, ['button[name="Save"]', 'button:has-text("Save")']);
    }
    get waitForD365Loading(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, ['#ShellBlockingDiv']);
    }
    get newButton(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, ['#vendtablelistpage_1_SystemDefinedNewButton']);
    }

    // ─── Navigation ───────────────────────────────────────────────────────────

    /**
     * Navigate to the Vendor list page and wait for it to fully load
     */
    async navigateToSupplierList(): Promise<void> {
        await PageUtil.navigateTo(this.page, ENV.SUPPLIER_LIST_URL);
    }

    /**
     * Assert the page has loaded by verifying key elements are visible
     */
    async assertPageLoaded(): Promise<void> {
        await this.page.waitForLoadState('networkidle');
    }

    // ─── Toolbar Actions ──────────────────────────────────────────────────────

    /**
     * Click the New button to begin creating a new supplier record
     */
    async clickNew(): Promise<void> {
        await PageUtil.clickElementButtonName(this.newButton, 'New');
        // Wait for D365 to dismiss any loading overlay before checking for form
        await PageUtil.waitForD365Loading(this.waitForD365Loading);
    }

    /**
     * Click the Save button to persist changes
     */
    async clickSave(): Promise<void> {
        await PageUtil.clickElementButtonName(this.saveButton, 'Save');
        await PageUtil.waitForD365Loading(this.waitForD365Loading);
    }

    // ─── General Section ──────────────────────────────────────────────────────

    /**
     * Wait for the General section to become visible after clicking New
     */
    async waitForGeneralSection(): Promise<void> {
        await PageUtil.waitForElement(this.generalTabCaption, {
            state: 'visible',
            timeout: ENV.PAGE_LOAD_TIMEOUT,
        });
    }
    async waitForIdentificationHeading(): Promise<void> {
        await PageUtil.waitForElement(this.identificationHeading, {
            state: 'visible',
            timeout: ENV.PAGE_LOAD_TIMEOUT,
        });
    }

    /**
     * Read the auto-generated supplier ID from the Identification field
     */
    async getGeneratedSupplierId(): Promise<string> {
        return this.supplierIdInput.inputValue();
    }

    async fillName(name: string): Promise<void> {
        await PageUtil.fillInput(this.nameInput, name, 'Name');
    }

    async fillNameAlias(alias: string): Promise<void> {
        await PageUtil.fillInput(this.nameAliasInput, alias, 'Name Alias');
    }

    async selectVendorGroup(group: string): Promise<void> {
        await PageUtil.fillAndPressKey(this.groupInput, group, 'Escape', 'Vendor Group');
    }

    async selectTaxGroup(taxGroup: string): Promise<void> {
        await PageUtil.fillAndPressKey(this.taxGroupInput, taxGroup, 'Escape', 'Tax Group');
    }


    // ─── Assertions ───────────────────────────────────────────────────────────────

    async assertSupplierSaved(): Promise<void> {
        await PageUtil.assertElementVisible(this.generalTabCaption, ENV.PAGE_LOAD_TIMEOUT);
    }
}