const countEl = document.getElementById("count");
const statusEl = document.getElementById("status");
const startBtn = document.getElementById("start");
const stopBtn = document.getElementById("stop");
const downloadBtn = document.getElementById("download");
const clearBtn = document.getElementById("clear");

async function getTab() {
  const tabs = await chrome.tabs.query({active: true, currentWindow: true});
  return tabs[0];
}

async function send(message) {
  const tab = await getTab();
  if (!tab || !tab.id) throw new Error("No active tab.");
  return chrome.tabs.sendMessage(tab.id, message);
}

async function refreshCount() {
  const result = await chrome.storage.local.get({locatorRows: []});
  countEl.textContent = result.locatorRows.length;
}

startBtn.addEventListener("click", async () => {
  try {
    await send({type: "START_CAPTURE"});
    statusEl.textContent = "Capture ON — hover and click";
    await refreshCount();
  } catch (e) {
    statusEl.textContent = "Cannot start on this page.";
  }
});

stopBtn.addEventListener("click", async () => {
  try {
    await send({type: "STOP_CAPTURE"});
    statusEl.textContent = "Capture stopped";
  } catch (e) {
    statusEl.textContent = "Stopped";
  }
});

clearBtn.addEventListener("click", async () => {
  if (!confirm("Delete all captured elements?")) return;
  await chrome.storage.local.set({locatorRows: []});
  await refreshCount();
  statusEl.textContent = "Repository cleared";
});

downloadBtn.addEventListener("click", async () => {
  const result = await chrome.storage.local.get({locatorRows: []});
  if (!result.locatorRows.length) {
    statusEl.textContent = "Nothing to download";
    return;
  }

  const xml = buildExcelXml(result.locatorRows);
  const blob = new Blob([xml], {type: "application/vnd.ms-excel"});
  const url = URL.createObjectURL(blob);

  const filename = "UI_Locator_Repository_" +
    new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19) + ".xls";

  await chrome.downloads.download({
    url,
    filename,
    saveAs: true
  });

  setTimeout(() => URL.revokeObjectURL(url), 5000);
  statusEl.textContent = "Excel downloaded";
});

function esc(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function cell(value) {
  return `<Cell><Data ss:Type="String">${esc(value)}</Data></Cell>`;
}

function buildExcelXml(rows) {
  const headers = [
    "S.No",
    "Page URL",
    "Element Type",
    "Visible Text",
    "Name",
    "Label",
    "Placeholder",
    "ARIA Label",
    "Role",
    "Title",
    "Perfect Locator",
    "Locator Type",
    "Alternative Locator 1",
    "Alternative Locator 2",
    "CSS Selector",
    "XPath",
    "Stability Score",
    "Confidence",
    "Captured At"
  ];

  const body = rows.map((r, i) => {
    const values = [
      i + 1, r.pageUrl, r.elementType, r.visibleText, r.name, r.label,
      r.placeholder, r.ariaLabel, r.role, r.title, r.perfectLocator,
      r.locatorType, r.alternative1, r.alternative2, r.cssSelector,
      r.xpath, r.stabilityScore, r.confidence, r.capturedAt
    ];
    return `<Row>${values.map(cell).join("")}</Row>`;
  }).join("");

  return `<?xml version="1.0"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:o="urn:schemas-microsoft-com:office:office"
 xmlns:x="urn:schemas-microsoft-com:office:excel"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
 <Worksheet ss:Name="UI Elements">
  <Table>
   <Row>${headers.map(h => `<Cell><Data ss:Type="String">${esc(h)}</Data></Cell>`).join("")}</Row>
   ${body}
  </Table>
 </Worksheet>
</Workbook>`;
}

refreshCount();