LOCATOR EXTRACTOR - Chrome Extension
====================================

INSTALL
-------
1. Extract the ZIP file.
2. Open Chrome/Edge.
3. Go to:
   chrome://extensions/
4. Turn ON "Developer mode".
5. Click "Load unpacked".
6. Select the extracted "LocatorExtractorExtension" folder.
7. Pin "Locator Extractor" to the browser toolbar.

USE
---
1. Open the webpage you want to inspect.
2. Click the Locator Extractor extension.
3. Click "Start Capture".
4. Move the mouse over an element.
5. Click the element.
6. The extension captures one element as one repository row.
7. Continue with the next element.
8. Open the extension and click "Download Excel".

IMPORTANT
---------
The exported file is Excel-compatible .xls SpreadsheetML.
It opens directly in Microsoft Excel.

The extension prevents the normal click event from reaching the page
while capture mode is active, so buttons/links should not normally
execute their application action during capture.

The extractor prefers semantic/stable locators such as:
- getByRole()
- getByLabel()
- getByPlaceholder()
- getByTestId()
- stable aria-label/name/title
- CSS
- XPath only as a last fallback

No locator can be guaranteed permanently stable if the application
itself changes its accessible names, labels, test IDs, or DOM structure.
