(() => {
  if (window.__LOCATOR_EXTRACTOR_LOADED__) return;
  window.__LOCATOR_EXTRACTOR_LOADED__ = true;

  let captureMode = false;
  let hovered = null;
  let overlay = null;

  const HIGHLIGHT_ID = "__locator_extractor_highlight__";

  function ensureOverlay() {
    if (overlay) return;
    overlay = document.createElement("div");
    overlay.id = HIGHLIGHT_ID;
    Object.assign(overlay.style, {
      position: "fixed",
      zIndex: "2147483647",
      pointerEvents: "none",
      border: "2px solid #ff0000",
      background: "rgba(255,0,0,0.08)",
      display: "none",
      boxSizing: "border-box"
    });
    document.documentElement.appendChild(overlay);
  }

  function highlight(el) {
    ensureOverlay();
    if (!el || el === overlay || !el.getBoundingClientRect) return;
    const r = el.getBoundingClientRect();
    Object.assign(overlay.style, {
      display: "block",
      left: `${r.left}px`,
      top: `${r.top}px`,
      width: `${r.width}px`,
      height: `${r.height}px`
    });
  }

  function hideHighlight() {
    if (overlay) overlay.style.display = "none";
  }

  function normalize(s) {
    return (s || "").replace(/\s+/g, " ").trim();
  }

  function visibleText(el) {
    if (el.tagName === "INPUT" || el.tagName === "TEXTAREA") {
      return "";
    }
    return normalize(el.innerText || el.textContent || "").slice(0, 250);
  }

  function attr(el, name) {
    return normalize(el.getAttribute(name) || "");
  }

  function isDynamic(value) {
    if (!value) return false;
    const s = value.trim();

    // UUID / GUID
    if (/^[0-9a-f]{8}-[0-9a-f-]{27,}$/i.test(s)) return true;

    // Long random-looking values
    if (/^[A-Za-z0-9_-]{18,}$/.test(s) && /\d/.test(s)) return true;

    // Mostly numeric or generated numeric suffix
    if (/^\d{6,}$/.test(s)) return true;
    if (/[A-Za-z_-]+\d{5,}/.test(s)) return true;

    // Common framework-generated patterns
    if (/^(ember|react|vue|ng|mat|cdk|auto|uid|uuid)[-_]?[A-Za-z0-9_-]*\d+/i.test(s)) return true;

    return false;
  }

  function stable(value) {
    return !!value && !isDynamic(value);
  }

  function xpathFor(el) {
    if (!el || el.nodeType !== 1) return "";
    if (el === document.body) return "/html/body";

    const parts = [];
    let node = el;

    while (node && node.nodeType === 1 && node !== document.body) {
      let index = 1;
      let sib = node.previousElementSibling;
      while (sib) {
        if (sib.tagName === node.tagName) index++;
        sib = sib.previousElementSibling;
      }
      parts.unshift(`${node.tagName.toLowerCase()}[${index}]`);
      node = node.parentElement;
    }

    return "/html/body/" + parts.join("/");
  }

  function cssEscapeSafe(value) {
    try { return CSS.escape(value); }
    catch { return value.replace(/([^\w-])/g, "\\$1"); }
  }

  function cssFor(el) {
    if (el.id && stable(el.id)) return `#${cssEscapeSafe(el.id)}`;

    const stableAttrs = [
      "data-testid", "data-test", "data-cy", "data-qa",
      "aria-label", "name", "placeholder", "title"
    ];

    for (const a of stableAttrs) {
      const v = attr(el, a);
      if (stable(v)) return `[${a}="${v.replace(/"/g, '\\"')}"]`;
    }

    let node = el;
    const parts = [];

    while (node && node.nodeType === 1 && node !== document.body) {
      let part = node.tagName.toLowerCase();

      for (const a of stableAttrs) {
        const v = attr(node, a);
        if (stable(v)) {
          part += `[${a}="${v.replace(/"/g, '\\"')}"]`;
          parts.unshift(part);
          return parts.join(" > ");
        }
      }

      const parent = node.parentElement;
      if (!parent) break;

      const same = [...parent.children].filter(x => x.tagName === node.tagName);
      if (same.length > 1) {
        part += `:nth-of-type(${same.indexOf(node) + 1})`;
      }

      parts.unshift(part);
      node = parent;
    }

    return parts.join(" > ");
  }

  function countMatches(css) {
    if (!css) return 0;
    try { return document.querySelectorAll(css).length; }
    catch { return 0; }
  }

  function roleOf(el) {
    const explicit = attr(el, "role");
    if (explicit) return explicit;

    const tag = el.tagName.toLowerCase();
    const type = attr(el, "type").toLowerCase();

    if (tag === "button") return "button";
    if (tag === "a" && el.getAttribute("href")) return "link";
    if (tag === "textarea") return "textbox";
    if (tag === "select") return "combobox";
    if (tag === "input") {
      if (["checkbox"].includes(type)) return "checkbox";
      if (["radio"].includes(type)) return "radio";
      if (["submit", "button", "reset"].includes(type)) return "button";
      return "textbox";
    }
    return "";
  }

  function associatedLabel(el) {
    const id = attr(el, "id");
    if (id) {
      const label = document.querySelector(`label[for="${CSS.escape(id)}"]`);
      if (label) return normalize(label.innerText || label.textContent);
    }

    const parentLabel = el.closest("label");
    if (parentLabel) {
      return normalize(parentLabel.innerText || parentLabel.textContent);
    }

    const labelledBy = attr(el, "aria-labelledby");
    if (labelledBy) {
      return labelledBy.split(/\s+/).map(id => {
        const n = document.getElementById(id);
        return n ? normalize(n.innerText || n.textContent) : "";
      }).filter(Boolean).join(" ");
    }

    return attr(el, "aria-label");
  }

  function candidates(el) {
    const list = [];

    const text = visibleText(el);
    const name = attr(el, "name");
    const label = associatedLabel(el);
    const aria = attr(el, "aria-label");
    const placeholder = attr(el, "placeholder");
    const title = attr(el, "title");
    const role = roleOf(el);
    const testId = attr(el, "data-testid") || attr(el, "data-test") ||
                   attr(el, "data-cy") || attr(el, "data-qa");

    // Highest preference: semantic Playwright locators.
    if (role && text && text.length <= 100) {
      list.push({
        type: "Role",
        locator: `getByRole('${role}', { name: '${text.replace(/'/g, "\\'")}' })`,
        score: 98
      });
    }

    if (role && aria && aria.length <= 150) {
      list.push({
        type: "Role/ARIA",
        locator: `getByRole('${role}', { name: '${aria.replace(/'/g, "\\'")}' })`,
        score: 99
      });
    }

    if (label && label.length <= 150) {
      list.push({
        type: "Label",
        locator: `getByLabel('${label.replace(/'/g, "\\'")}')`,
        score: 100
      });
    }

    if (placeholder && placeholder.length <= 150) {
      list.push({
        type: "Placeholder",
        locator: `getByPlaceholder('${placeholder.replace(/'/g, "\\'")}')`,
        score: 96
      });
    }

    if (testId && stable(testId)) {
      list.push({
        type: "Test ID",
        locator: `getByTestId('${testId.replace(/'/g, "\\'")}')`,
        score: 100
      });
    }

    if (name && stable(name)) {
      list.push({
        type: "Name",
        locator: `locator('[name="${name.replace(/"/g, '\\"')}"]')`,
        score: 90
      });
    }

    if (aria && stable(aria)) {
      list.push({
        type: "ARIA",
        locator: `locator('[aria-label="${aria.replace(/"/g, '\\"')}"]')`,
        score: 94
      });
    }

    if (title && stable(title)) {
      list.push({
        type: "Title",
        locator: `locator('[title="${title.replace(/"/g, '\\"')}"]')`,
        score: 88
      });
    }

    const css = cssFor(el);
    if (css) {
      list.push({
        type: "CSS",
        locator: `locator('${css.replace(/'/g, "\\'")}')`,
        score: countMatches(css) === 1 ? 85 : 55
      });
    }

    const xpath = xpathFor(el);
    if (xpath) {
      list.push({
        type: "XPath",
        locator: `locator('xpath=${xpath}')`,
        score: 35
      });
    }

    // Prefer unique candidates.
    return list.map(c => {
      let uniqueness = 0;
      try {
        if (c.type === "Role" || c.type === "Role/ARIA" || c.type === "Label" ||
            c.type === "Placeholder" || c.type === "Test ID") {
          uniqueness = 1;
        }
      } catch {}
      return {...c, uniqueness};
    }).sort((a, b) => b.score - a.score);
  }

  function makeRecord(el) {
    const cs = candidates(el);
    const best = cs[0] || {type: "XPath", locator: `locator('xpath=${xpathFor(el)}')`, score: 20};

    const pageUrl = location.href;
    const role = roleOf(el);
    const text = visibleText(el);
    const label = associatedLabel(el);

    return {
      pageUrl,
      elementType: el.tagName.toLowerCase(),
      visibleText: text,
      name: attr(el, "name"),
      label,
      placeholder: attr(el, "placeholder"),
      ariaLabel: attr(el, "aria-label"),
      role,
      title: attr(el, "title"),
      perfectLocator: best.locator,
      locatorType: best.type,
      alternative1: cs[1]?.locator || "",
      alternative2: cs[2]?.locator || "",
      cssSelector: cssFor(el),
      xpath: xpathFor(el),
      stabilityScore: Math.min(100, best.score),
      confidence: `${Math.min(99, Math.max(50, best.score))}%`,
      capturedAt: new Date().toLocaleString()
    };
  }

  async function saveRecord(record) {
    const current = await chrome.storage.local.get({locatorRows: []});
    const rows = current.locatorRows;

    // Avoid duplicate capture of the exact same perfect locator on the same page.
    const duplicate = rows.some(r =>
      r.pageUrl === record.pageUrl &&
      r.perfectLocator === record.perfectLocator
    );

    if (!duplicate) {
      rows.push(record);
      await chrome.storage.local.set({locatorRows: rows});
      return true;
    }
    return false;
  }

  function onMouseOver(e) {
    if (!captureMode) return;
    const el = e.target;
    if (!(el instanceof Element)) return;
    if (el.id === HIGHLIGHT_ID) return;
    hovered = el;
    highlight(el);
  }

  async function onClick(e) {
    if (!captureMode) return;
    const el = e.target;
    if (!(el instanceof Element)) return;
    if (el.id === HIGHLIGHT_ID) return;

    // Capture without allowing the webpage to perform its normal click.
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();

    const record = makeRecord(el);
    const added = await saveRecord(record);

    hideHighlight();

    // Small visual confirmation.
    showToast(
      added
        ? `Captured: ${record.elementType} — ${record.label || record.visibleText || record.name || "element"}`
        : "Already captured"
    );
  }

  function showToast(message) {
    const old = document.getElementById("__locator_extractor_toast__");
    if (old) old.remove();

    const toast = document.createElement("div");
    toast.id = "__locator_extractor_toast__";
    toast.textContent = message;
    Object.assign(toast.style, {
      position: "fixed",
      left: "50%",
      bottom: "25px",
      transform: "translateX(-50%)",
      zIndex: "2147483647",
      background: "#111",
      color: "#fff",
      border: "1px solid #555",
      borderRadius: "7px",
      padding: "10px 14px",
      font: "13px Arial",
      boxShadow: "0 3px 15px rgba(0,0,0,.35)",
      pointerEvents: "none"
    });
    document.documentElement.appendChild(toast);
    setTimeout(() => toast.remove(), 1300);
  }

  function start() {
    captureMode = true;
    ensureOverlay();
    document.addEventListener("mouseover", onMouseOver, true);
    document.addEventListener("click", onClick, true);
    showToast("Capture ON — hover and click an element");
  }

  function stop() {
    captureMode = false;
    hideHighlight();
    document.removeEventListener("mouseover", onMouseOver, true);
    document.removeEventListener("click", onClick, true);
    showToast("Capture stopped");
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === "START_CAPTURE") {
      start();
      sendResponse({ok: true});
    } else if (msg.type === "STOP_CAPTURE") {
      stop();
      sendResponse({ok: true});
    }
    return true;
  });
})();