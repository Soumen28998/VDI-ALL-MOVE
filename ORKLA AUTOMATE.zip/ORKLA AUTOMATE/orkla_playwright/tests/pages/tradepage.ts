import { Page, Locator } from '@playwright/test';
import { ENV } from '../config/env.config';
import { PageUtil } from '../utils/page.util';

export class TradeAgreementPage {

    constructor(private readonly page: Page) { }

    // ───────────────────────── SELECTORS ─────────────────────────

    private readonly SELECTORS = {

        MODULE_ICON: ['#navPaneModuleID'],

        NEW_BUTTON: [
            'button[id*="SystemDefinedNewButton"][command="New"]',
            'button:has(span[id$="_SystemDefinedNewButton_label"])'
        ],

        OK_BUTTON: [
            'button:has-text("OK")'
        ],

        SAVE_BUTTON: [
            'button:has-text("Save")'
        ],

        LOADER: [
            '#ShellBlockingDiv'
        ]
    };

    // ───────────────────────── COMMON HELPERS ─────────────────────────

    private treeItem(name: string): Locator {
        return this.page.getByRole('treeitem', {
            name,
            exact: true
        });
    }

    private menuItem(name: string): Locator {
        return this.page.getByRole('link', {
            name,
            exact: true
        });
    }

    private button(buttonName: string): Locator {
        return this.page.getByRole('button', {
            name: new RegExp(buttonName, 'i')
        });
    }

    private textBox(fieldName: string): Locator {
        return this.page.getByRole('textbox', {
            name: fieldName,
            exact: true
        }).last();
    }

    private comboBox(fieldName: string): Locator {
        return this.page.getByRole('combobox', {
            name: fieldName,
            exact: true
        }).last();
    }

    private option(optionName: string): Locator {
        return this.page.getByRole('option', {
            name: optionName,
            exact: true
        });
    }

    // ───────────────────────── GETTERS ─────────────────────────

    get moduleIcon(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.MODULE_ICON
        );
    }

    get newButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.NEW_BUTTON
        );
    }

    get okButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.OK_BUTTON
        );
    }

    get saveButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.SAVE_BUTTON
        );
    }

    get waitForD365Loading(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.LOADER
        );
    }

    // ───────────────────────── NAVIGATION ─────────────────────────

    async navigateToTradeAgreementPage(): Promise<void> {

        await this.page.goto(ENV.DASHBOARD_URL);

        await this.page.waitForLoadState('domcontentloaded');
    }

    /*
    async openMenu(
        module: string,
        parent: string,
        child: string,
        menu: string
    ): Promise<void> {

        await this.moduleIcon.click();

        const moduleNode = this.treeItem(module);

        if ((await moduleNode.getAttribute('aria-expanded')) !== 'true') {
            await moduleNode.click();
        }

        await this.treeItem(parent).waitFor();
        await this.treeItem(parent).dblclick();

        await this.treeItem(child).waitFor();
        await this.treeItem(child).dblclick();

        await this.menuItem(menu).waitFor({
            state: 'visible'
        });

        await this.menuItem(menu).click();

        await PageUtil.waitForD365Loading(this.waitForD365Loading);
    }*/

    async openMenu(
        module: string,
        parent: string,
        child: string,
        menu: string
    ): Promise<void> {

        await this.moduleIcon.click();

        const moduleNode = this.treeItem(module);

        if ((await moduleNode.getAttribute('aria-expanded')) !== 'true') {
            await moduleNode.click();
        }

        await this.treeItem(parent).waitFor();
        await this.treeItem(parent).dblclick();

        // Child is optional
        if (child && child.trim() !== '') {
            await this.treeItem(child).waitFor();
            await this.treeItem(child).dblclick();
        }

        await this.menuItem(menu).waitFor({
            state: 'visible'
        });

        await this.menuItem(menu).click();

        await PageUtil.waitForD365Loading(this.waitForD365Loading);
    }

    async openTradeAgreementModule(): Promise<void> {

        await this.openMenu(
            'Procurement and sourcing',
            'Prices and discounts',
            ' ',
            'Trade agreement journals'
        );

        await PageUtil.waitForD365Loading(
            this.waitForD365Loading
        );
    }

    // ───────────────────────── TOOLBAR ─────────────────────────

    async clickNew(): Promise<void> {

        await this.newButton.first().click();

        await PageUtil.waitForD365Loading(
            this.waitForD365Loading
        );
    }

    async clickOK(): Promise<void> {

        await this.okButton.click();

        await PageUtil.waitForD365Loading(
            this.waitForD365Loading
        );
    }

    async clickSave(): Promise<void> {

        await this.saveButton.click();

        await PageUtil.waitForD365Loading(
            this.waitForD365Loading
        );
    }

    // ───────────────────────── TRADE AGREEMENT DETAILS ─────────────────────────

    async fillName(value: string): Promise<void> {

        const combo = this.comboBox('Name');

        await combo.waitFor({ state: 'visible' });

        await combo.click();

        await combo.fill(value);

        await this.page.keyboard.press('Enter');

        await PageUtil.waitForD365Loading(
            this.waitForD365Loading
        );
    }

    /*
    async fillPriceDiscountJournalNumber(value: string): Promise<void> {

        const textbox = this.textBox('Price/discount journal number');

        await textbox.waitFor({
            state: 'visible'
        });

        await textbox.click();

        await textbox.fill(value);

        await PageUtil.waitForD365Loading(
            this.waitForD365Loading
        );
    }
*/


async fillPriceDiscountJournalNumber(
    expectedJournalNumber?: string
): Promise<void> {
    const textbox = this.textBox(
        'Price/discount journal number'
    );

    await textbox.waitFor({
        state: 'visible',
        timeout: 30000
    });

    const actualJournalNumber =
        (await textbox.inputValue()).trim();

    const isReadOnly =
        (await textbox.getAttribute('readonly')) !== null;

    if (isReadOnly) {
        console.log(
            `D365-generated journal number: ${actualJournalNumber}`
        );

        if (
            expectedJournalNumber &&
            expectedJournalNumber !== actualJournalNumber
        ) {
            console.warn(
                `Provided journal number "${expectedJournalNumber}" ` +
                `was not entered because the field is read-only. ` +
                `D365 currently displays "${actualJournalNumber}".`
            );
        }

        return;
    }

    // Fill only when the field is genuinely editable.
    if (expectedJournalNumber) {
        await textbox.fill(expectedJournalNumber);
    }
}

/*
    async fillTradeAgreementDetails(
        name: string,
        journalNumber: string
    ): Promise<void> {

        await this.fillName(name);

        await this.fillPriceDiscountJournalNumber(
            journalNumber
        );
    }
*/

async fillTradeAgreementDetails(
    name: string,
    journalNumber?: string
): Promise<void> {
    await this.fillName(name);

    await this.fillPriceDiscountJournalNumber(
        journalNumber
    );
}

    // ───────────────────────── ASSERTIONS ─────────────────────────

    async assertTradeAgreementLoaded(): Promise<void> {

        await this.page.waitForLoadState('networkidle');
    }

    async verifyTradeAgreementCreated(): Promise<void> {

        await this.page.waitForLoadState('networkidle');
    }

}