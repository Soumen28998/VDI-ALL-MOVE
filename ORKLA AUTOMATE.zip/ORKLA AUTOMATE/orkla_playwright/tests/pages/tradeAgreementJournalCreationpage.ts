import { Page, Locator, expect } from "@playwright/test";
import { ENV } from "../config/env.config";
import { PageUtil } from "../utils/page.util";

export class CreateTradeAgreementJournalPage {
    constructor(private readonly page: Page) { }

    // ─── Selectors ────────────────────────────────────────────────────────────────

    private readonly SELECTORS = {
        // Navigation
        MODULE_ICON: ["#navPaneModuleID"],
        ACCOUNT_RECEIVABLE: ['a[role="treeitem"][data-dyn-title="Accounts receivable"]'],
        COLLAPSE_ALL: ['button.modulesFlyout-CollapseAll'],
        SETUP: ['a[role="treeitem"][data-dyn-title="Setup"]'],
        TRADE_AGREEMENT_JOURNAL: ['div[role="link"][aria-label="Trade agreement journals"]'],

        // Toolbar
        NEW_BUTTON: [
            'button[id*="SystemDefinedNewButton"][command="New"]',
            'button:has(span[id$="_SystemDefinedNewButton_label"])',
        ],
        SAVE_BUTTON: ['button:has-text("Save")'],
        LINE_BUTTON: ['button:has-text("Lines")'],
        POST_BUTTON: ['span.button-label[id$="_PriceDiscAdmPost_label"]'],

        // Input Field
        NAME_INPUT: ['input[id^="PriceDiscAdmTable_JournalName_"][id$="_input"]'],
        DESCRIPTION_INPUT: ['input[aria-label="Description"]'],
        PARTY_CODE_TYPE_INPUT: ['input[aria-label="Party code type"]'],
        ACCOUNT_SECTION: ['input[aria-label="Account selection"]'],
        ITEM_RELATION: ['input[aria-label="Item relation"]'],
        PRODUCT_CODE_TYPE_INPUT: ['input[aria-label="Product code type"]'],
        AMOUNT_IN_CURRENCY: ['input[aria-label="Amount in currency"]'],
        CURRENCY: ['input[aria-label="Currency"]'],
        PRICE_INDICATION: ['input[type="text"][role="combobox"][aria-label="Price indication"][aria-haspopup="dialog"]'],
        FROM_DATE: ['input[name="FromDate"]'],
        TO_DATE: ['input[name="ToDate"]'],
        PRICE_UNIT: ['input[id^="PriceDiscAdm_"][id$="_PriceUnit_input"]'],

        //Button
        OK_BUTTON: ['button:has-text("OK")'],

        // Loader
        LOADER: ["#ShellBlockingDiv"],
    };

    // ───────────────────────── LOCATORS ─────────────────────────

    get ModuleIcon(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.MODULE_ICON,
        );
    }

    get AccountReceivable(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.ACCOUNT_RECEIVABLE,
        );
    }

    get CollapseAll(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.COLLAPSE_ALL,
        );
    }

    get Setup(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.SETUP,
        );
    }

    get TradeAgreementJournal(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.TRADE_AGREEMENT_JOURNAL,
        );
    }

    get NewButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.NEW_BUTTON,
        );
    }

    get SaveButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.SAVE_BUTTON,
        );
    }

    get LineButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.LINE_BUTTON,
        );
    }

    get PostButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.POST_BUTTON,
        );
    }

    get NameInput(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.NAME_INPUT,
        );
    }

    get DescriptionInput(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.DESCRIPTION_INPUT,
        );
    }

    get PartyCodeTypeInput(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.PARTY_CODE_TYPE_INPUT,
        );
    }

    get AccountSection(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.ACCOUNT_SECTION,
        );
    }

    get ItemRelation(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.ITEM_RELATION,
        );
    }

    get ProductCodeTypeInput(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.PRODUCT_CODE_TYPE_INPUT,
        );
    }

    get AmountInCurrency(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.AMOUNT_IN_CURRENCY,
        );
    }

    get Currency(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.CURRENCY,
        );
    }

    get PriceIndication(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.PRICE_INDICATION,
        );
    }

    get FromDate(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.FROM_DATE,
        );
    }

    get ToDate(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.TO_DATE,
        );
    }

    get PriceUnit(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.PRICE_UNIT,
        );
    }

    get OKButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.OK_BUTTON,
        );
    }

    get Loader(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.LOADER,
        );
    }

    // ───────────────────────── NAVIGATION URL ─────────────────────────

    async navigateToTradeAgreementJournalPage(): Promise<void> {
        await this.page.goto(ENV.CON_URL);
        await this.page.waitForLoadState('domcontentloaded');
    }

    // ───────────────────────── NAVIGATION ACTIONS ─────────────────────────


    async clickModuleIcon(): Promise<void> {
        await this.ModuleIcon.waitFor({ state: "visible" });
        await this.ModuleIcon.click();
        await this.page.waitForLoadState('domcontentloaded');
    }

    async clickAccountReceivable(): Promise<void> {
        await this.AccountReceivable.waitFor({ state: "visible" });
        await this.AccountReceivable.click();
        await this.page.waitForLoadState('domcontentloaded');
    }

    async clickCollapseAll(): Promise<void> {
        await this.CollapseAll.waitFor({ state: "visible" });
        await this.CollapseAll.click();
        await this.page.waitForLoadState('domcontentloaded');
    }

    async clickSetup(): Promise<void> {
        await this.Setup.waitFor({ state: "visible" });
        await this.Setup.click();
        await this.page.waitForLoadState('domcontentloaded');
    }

    async clickTradeAgreementJournal(): Promise<void> {
        await this.TradeAgreementJournal.waitFor({ state: "visible" });
        await this.TradeAgreementJournal.click();
        await this.page.waitForLoadState('domcontentloaded');
    }

    async clickOKButton(): Promise<void> {
        await this.OKButton.waitFor({ state: "visible" });
        await this.OKButton.click();
        await this.page.waitForLoadState('domcontentloaded');
    }

    // ───────────────────────── TOOLBAR ACTIONS ─────────────────────────

    async clickNewButton(): Promise<void> {
        await this.NewButton.waitFor({ state: "visible" });
        await this.NewButton.click();
        await this.page.waitForLoadState('domcontentloaded');
    }

    async clickSaveButton(): Promise<void> {
        await this.SaveButton.waitFor({ state: "visible" });
        await this.SaveButton.click();
        await this.page.waitForLoadState('domcontentloaded');
    }

    async clickLineButton(): Promise<void> {
        await this.LineButton.waitFor({ state: "visible" });
        await this.LineButton.click();
        await this.page.waitForLoadState('domcontentloaded');
    }

    async clickPostButton(): Promise<void> {
        await this.page.keyboard.press('Alt+S');
        await this.PostButton.waitFor({ state: "visible" });
        await this.PostButton.click();
        await this.page.waitForLoadState('domcontentloaded');
    }

    // ───────────────────────── FILL ACTIONS ─────────────────────────

    async fillName(name: string): Promise<void> {
        await this.NameInput.waitFor({ state: "visible" });
        await this.NameInput.click();
        await this.NameInput.fill(name);
        await this.page.waitForLoadState('domcontentloaded');
    }

    async fillDescription(description: string): Promise<void> {
        await this.DescriptionInput.waitFor({ state: "visible" });
        await this.DescriptionInput.click();
        await this.DescriptionInput.fill(description);
        await this.page.waitForLoadState('domcontentloaded');
    }

    async fillPartyCodeType(partyCodeType: string): Promise<void> {
        await this.PartyCodeTypeInput.waitFor({ state: "visible" });
        await this.PartyCodeTypeInput.click();
        await this.PartyCodeTypeInput.fill(partyCodeType);
        await this.page.waitForLoadState('domcontentloaded');
    }

    async fillAccountSection(accountSection: string): Promise<void> {
        await this.AccountSection.waitFor({ state: "visible" });
        await this.AccountSection.click();
        await this.AccountSection.fill(accountSection);
        await this.page.waitForLoadState('domcontentloaded');
    }

    async fillItemRelation(itemRelation: string): Promise<void> {
        await this.ItemRelation.waitFor({ state: "visible" });
        await this.ItemRelation.click();
        await this.ItemRelation.fill(itemRelation);
        await this.page.waitForLoadState('domcontentloaded');
    }

    async fillProductCodeType(productCodeType: string): Promise<void> {
        await this.ProductCodeTypeInput.waitFor({ state: "visible" });
        await this.ProductCodeTypeInput.click();
        await this.ProductCodeTypeInput.fill(productCodeType);
        await this.page.waitForLoadState('domcontentloaded');
    }

    async fillAmountInCurrency(amountInCurrency: string): Promise<void> {
        await this.AmountInCurrency.waitFor({ state: "visible" });
        await this.AmountInCurrency.click();
        await this.AmountInCurrency.fill(amountInCurrency);
        await this.page.waitForLoadState('domcontentloaded');
    }

    async fillCurrency(currency: string): Promise<void> {
        await this.Currency.waitFor({ state: "visible" });
        await this.Currency.click();
        await this.Currency.fill(currency);
        await this.page.waitForLoadState('domcontentloaded');
    }

    async fillPriceIndication(priceIndication: string): Promise<void> {
        await this.PriceIndication.waitFor({ state: "visible" });
        await this.PriceIndication.click();
        await this.PriceIndication.fill(priceIndication);
        await this.page.waitForLoadState('domcontentloaded');
    }

    async fillFromDate(fromDate: string): Promise<void> {
        await this.FromDate.waitFor({ state: "visible" });
        await this.FromDate.click();
        await this.FromDate.fill(fromDate);
        await this.page.waitForLoadState('domcontentloaded');
    }

    async fillToDate(toDate: string): Promise<void> {
        await this.ToDate.waitFor({ state: "visible" });
        await this.ToDate.click();
        await this.ToDate.fill(toDate);
        await this.page.waitForLoadState('domcontentloaded');
    }

    async fillPriceUnit(priceUnit: string): Promise<void> {
        await this.PriceUnit.waitFor({ state: "visible" });
        await this.PriceUnit.click();
        await this.PriceUnit.fill(priceUnit);
        await this.page.waitForLoadState('domcontentloaded');
    }

    // ───────────────────────── ASSERTIONS ─────────────────────────

    async assertItemLoaded(): Promise<void> {
        await this.page.waitForLoadState("networkidle");
    }
}
