import { Page, Locator, expect } from "@playwright/test";
import { ENV } from "../config/env.config";
import { PageUtil } from "../utils/page.util";

export class CustomerInvoicePage {
    constructor(private readonly page: Page) { }

    // ─── Selectors ────────────────────────────────────────────────────────────────
    private readonly SELECTORS = {
        // Navigation
        MODULE_ICON: ["#navPaneModuleID"],

        // Toolbar
        NEW_BUTTON: [
            'button[id*="SystemDefinedNewButton"][command="New"]',
            'button:has(span[id$="_SystemDefinedNewButton_label"])',
        ],
        OK_BUTTON: ['button:has-text("OK")'],
        SAVE_BUTTON: ['button:has-text("Save")'],
        APPLY_BUTTON: ['button:has-text("Apply")'],
        SHIPPED_NOT_INVOICE: ['[id$="SalesOrdersShippedButNotInvoicedTile_text"]'],
        SALES_ORDER: ['[data-dyn-columnname="SalesTable_SalesIdAdvanced"]'],
        INVOICE_BUTTON: ['button[id$="_Invoice_button"]'],
        INVOICE_JURNAL_BUTTON: [
            'button:has(span[id$="buttonJournalInvoice_label"])',
        ],
        LASERNET_BUTTON: [
            'button:has(span[id$="LACMenuButton_label"])',
        ],
        SUB_INVOICE_BUTTON: ['button:has(span[id$="buttonUpdateInvoice_label"])'],
        LASERNET_ORIGINAL_PREVIEW: [
            'button:has(span[id$="LACMenuPreview_Original_label"])',
        ],
        DOWNLOAD_BUTTON: [
            'span[id$="_DownloadFile_label"]',
            'span.button-label.button-label-dropDown:has-text("Download")',
        ],
        DOWNLOAD_PDF: ['span[id$="PDF_label"]'],
        FILTER_SALES_ORDER: [
            'input[aria-label="Filter field: Sales order, operator: begins with"]',
        ],

        // Loader
        LOADER: ["#ShellBlockingDiv"],
    };

    private treeItem(name: string): Locator {
        return this.page.getByRole("treeitem", {
            name,
            exact: true,
        });
    }

    private async expandTreeItem(name: string, index = 0): Promise<void> {
        const item = this.treeItem(name).nth(index);

        await item.waitFor({ state: "visible" });

        if ((await item.getAttribute("aria-expanded")) !== "true") {
            await item.click();
        }
    }


    private textBox(fieldName: string, description?: string): Locator {
        return this.page
            .getByRole("textbox", {
                name: fieldName,
                description,
                exact: true,
            })
            .last();
    }

    private button(buttonName: string): Locator {
        return this.page.getByRole("button", {
            name: new RegExp(buttonName, "i"),
        });
    }

    private option(optionName: string): Locator {
        return this.page.getByRole("option", {
            name: optionName,
            exact: true,
        });
    }

    private comboBox(fieldName: string): Locator {
        return this.page.getByRole("combobox", {
            name: fieldName,
            exact: true,
        });
    }

    private menuLink(name: string): Locator {
        return this.page.getByRole("link", {
            name,
            exact: true,
        });
    }
    // ───────────────────────── LOCATORS ─────────────────────────

    get moduleIcon(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.MODULE_ICON,
        );
    }

    get downloadButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.DOWNLOAD_BUTTON,
        );
    }


    get downloadPdf(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.DOWNLOAD_PDF,
        );
    }

    get lasernetOriginalPreviewButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.LASERNET_ORIGINAL_PREVIEW,
        );
    }


    get invoiceJurnalButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.INVOICE_JURNAL_BUTTON,
        );
    }

    get lasernetButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.LASERNET_BUTTON,
        );
    }

    get filterSalesOrder(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.FILTER_SALES_ORDER,
        );
    }

    get salesOrder(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.SALES_ORDER,
        );
    }

    get shippedNotInvoicedTile(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.SHIPPED_NOT_INVOICE,
        );
    }

    get waitForD365Loading(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, ["#ShellBlockingDiv"]);
    }

    get saveButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.SAVE_BUTTON,
        );
    }

    get newButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.NEW_BUTTON,
        );
    }

    get invoiceButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.INVOICE_BUTTON,
        );
    }

    get applyButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.APPLY_BUTTON,
        );
    }

    get okButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.OK_BUTTON,
        );
    }

    get subinvoiceButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.SUB_INVOICE_BUTTON,
        );
    }

    // ───────────────────────── NAVIGATION ─────────────────────────
    async navigateToinvoicePage(): Promise<void> {
        await this.page.goto(ENV.DASHBOARD_URL);
        await this.page.waitForLoadState("domcontentloaded");
    }

    async openMenu(module: string, parent: string, menu: string): Promise<void> {
        // Expand main module
        await this.expandTreeItem(module);

        // Expand first matching parent
        await this.expandTreeItem(parent, 0);

        // Click menu
        const menuItem = this.menuLink(menu);

        await menuItem.waitFor({ state: "visible" });
        await this.page.waitForLoadState("domcontentloaded");
        await menuItem.click();

        await this.page.waitForLoadState("domcontentloaded");
    }


    async openSalesOrderModule(): Promise<void> {
        await this.moduleIcon.click();
        await this.page.waitForLoadState("domcontentloaded");

        await this.openMenu(
            "Accounts receivable",
            "Workspaces",
            "Customer invoicing",
        );

        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickPostConfirmationOK(): Promise<void> {
        const confirmationPopup = this.page.getByLabel("You are about to post the");

        await confirmationPopup.waitFor({
            state: "visible",
            timeout: 30000,
        });

        const okButton = confirmationPopup.getByRole("button", {
            name: "OK",
            exact: true,
        });

        await okButton.waitFor({
            state: "visible",
            timeout: 10000,
        });

        await expect(okButton).toBeEnabled();
        await okButton.click();
        await this.page.waitForLoadState("domcontentloaded");
        console.log("Post confirmation OK clicked.");
    }

    // ───────────────────────── TOOLBAR ACTIONS ─────────────────────────

    async clickInvoiceJurnalButton(): Promise<void> {
        await this.invoiceJurnalButton.waitFor({ state: "visible" });
         await this.page.waitForLoadState("domcontentloaded");
        await this.invoiceJurnalButton.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickDownloadButton(): Promise<void> {
        await this.downloadButton.click();
        await this.page.waitForLoadState("domcontentloaded");
        await this.downloadPdf.waitFor({
            state: 'visible',
        });
        await this.downloadPdf.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickLasernetButton(): Promise<void> {
        await this.lasernetButton.waitFor({ state: "visible" });
        await expect(this.lasernetButton).toBeEnabled();
        await this.lasernetButton.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickLasernetOriginalPreview(): Promise<void> {
        await this.lasernetOriginalPreviewButton.waitFor({
            state: "visible",
        });

        await expect(this.lasernetOriginalPreviewButton).toBeEnabled();
        await this.lasernetOriginalPreviewButton.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickInvoicebutton(): Promise<void> {
        await this.invoiceButton.waitFor({
            state: "visible",
        });
        await this.invoiceButton.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickSubInvoice(): Promise<void> {
        await this.subinvoiceButton.waitFor({
            state: "visible",
        });
        await this.subinvoiceButton.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickApply(): Promise<void> {
        await this.applyButton.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickNew(): Promise<void> {
        await this.newButton.first().click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickOK(): Promise<void> {
        await this.okButton.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickSave(): Promise<void> {
        await this.saveButton.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickShippedNotInvoicedTile(): Promise<void> {
        await this.shippedNotInvoicedTile.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickSalesOrder(): Promise<void> {
        await this.salesOrder.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async fillFilterField(value: string): Promise<void> {
        await this.clickSalesOrder();
        await this.page.waitForLoadState("domcontentloaded");
        await this.filterSalesOrder.click();
        await this.filterSalesOrder.fill(value);
        await this.page.waitForLoadState("domcontentloaded");
        await this.button("Apply").last().click();
    }

    async clickInvoice(): Promise<void> {
        await this.clickInvoicebutton();
        await this.clickSubInvoice();
        await this.clickOK();
        await this.page.waitForLoadState("domcontentloaded");
        await this.clickPostConfirmationOK();
        await this.page.waitForLoadState("domcontentloaded");
        await this.page.keyboard.press("Escape");
    }

    async clickInvoiceJurnal(): Promise<void> {
        await this.clickInvoiceJurnalButton();
        await this.clickLasernetButton();
        await this.clickLasernetOriginalPreview();
        await this.clickDownloadButton();
        await this.page.waitForLoadState("domcontentloaded");
    }

    // ───────────────────────── ASSERTIONS ─────────────────────────

    async assertItemLoaded(): Promise<void> {
        await this.page.waitForLoadState("networkidle");
    }
}
