import { Page, Locator } from '@playwright/test';
import { ENV } from '../config/env.config';
import { PageUtil } from '../utils/page.util';

export class ReleasedProductPage {

    constructor(private readonly page: Page) { }

    // ───────────────────────── SELECTORS ─────────────────────────

    private readonly SELECTORS = {

        MODULE_ICON: ['#navPaneModuleID'],

        NEW_BUTTON: [
            'button[id*="SystemDefinedNewButton"][command="New"]',
            'button:has(span[id$="_SystemDefinedNewButton_label"])'
        ],

        OK_BUTTON: [
            'button:has-text("OK")'
        ],

        SAVE_BUTTON: [
            'button:has-text("Save")'
        ],

        CLOSE_BUTTON: [
            'button:has-text("Close")'
        ],

        LOADER: [
            '#ShellBlockingDiv'
        ]
    };

    // ───────────────────────── COMMON HELPERS ─────────────────────────

    private treeItem(name: string): Locator {
        return this.page.getByRole('treeitem', {
            name,
            exact: true
        });
    }

    private menuItem(name: string): Locator {
        return this.page.getByRole('link', {
            name,
            exact: true
        });
    }

    private button(name: string): Locator {
        return this.page.getByRole('button', {
            name: new RegExp(name, 'i')
        });
    }

    private textBox(name: string): Locator {
        return this.page.getByRole('textbox', {
            name,
            exact: true
        }).last();
    }

    private comboBox(name: string): Locator {
        return this.page.getByRole('combobox', {
            name,
            exact: true
        }).last();
    }

    private option(name: string): Locator {
        return this.page.getByRole('option', {
            name,
            exact: true
        });
    }

    // ───────────────────────── GETTERS ─────────────────────────

    get moduleIcon(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, this.SELECTORS.MODULE_ICON);
    }

    get newButton(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, this.SELECTORS.NEW_BUTTON);
    }

    get okButton(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, this.SELECTORS.OK_BUTTON);
    }

    get saveButton(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, this.SELECTORS.SAVE_BUTTON);
    }

    get closeButton(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, this.SELECTORS.CLOSE_BUTTON);
    }

    get waitForD365Loading(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, this.SELECTORS.LOADER);
    }

    // ───────────────────────── NAVIGATION ─────────────────────────

    async navigateToReleasedProductPage(): Promise<void> {

        await this.page.goto(ENV.DASHBOARD_URL);
        await this.page.waitForTimeout(5000);
        await this.page.waitForLoadState('domcontentloaded');
    }

    async openMenu(
        module: string,
        parent: string,
        child: string,
        menu: string
    ): Promise<void> {

        await this.moduleIcon.click();

        const moduleNode = this.treeItem(module);

        if ((await moduleNode.getAttribute('aria-expanded')) !== 'true') {
            await moduleNode.click();
        }

        await this.treeItem(parent).waitFor();
        await this.treeItem(parent).dblclick();

        if (child && child.trim() !== '') {
            await this.treeItem(child).waitFor();
            await this.treeItem(child).dblclick();
        }

        await this.menuItem(menu).waitFor({ state: 'visible' });

        await this.menuItem(menu).click();

        await PageUtil.waitForD365Loading(this.waitForD365Loading);
    }

    async openReleasedProductModule(): Promise<void> {

        await this.openMenu(
            'Product information management',
            'Products',
            '',
            'Released products'
        );
    }

    // ───────────────────────── TOOLBAR ─────────────────────────

    async clickNew(): Promise<void> {

        await this.newButton.first().click();

        await PageUtil.waitForD365Loading(this.waitForD365Loading);
    }

    async clickOK(): Promise<void> {

        await this.okButton.click();

        await PageUtil.waitForD365Loading(this.waitForD365Loading);
    }

    async clickSave(): Promise<void> {

        await this.saveButton.click();

        await PageUtil.waitForD365Loading(this.waitForD365Loading);
    }

    async clickClose(): Promise<void> {

        await this.closeButton.click();

        await PageUtil.waitForD365Loading(this.waitForD365Loading);
    }

    // ───────────────────────── RELEASED PRODUCT DETAILS ─────────────────────────

    async fillProductName(value: string): Promise<void> {

        await this.textBox('Product name').fill(value);
    }

    async selectItemModelGroup(value: string): Promise<void> {

        await this.comboBox('Item model group').click();
        await this.comboBox('Item model group').fill(value);
        await this.page.keyboard.press('Enter');

        await PageUtil.waitForD365Loading(this.waitForD365Loading);
    }

    async selectItemGroup(value: string): Promise<void> {

        await this.comboBox('Item group').click();
        await this.comboBox('Item group').fill(value);
        await this.page.keyboard.press('Enter');

        await PageUtil.waitForD365Loading(this.waitForD365Loading);
    }

    async selectStorageDimensionGroup(value: string): Promise<void> {

        await this.comboBox('Storage dimension group').click();
        await this.comboBox('Storage dimension group').fill(value);
        await this.page.keyboard.press('Enter');

        await PageUtil.waitForD365Loading(this.waitForD365Loading);
    }

    async selectTrackingDimensionGroup(value: string): Promise<void> {

        await this.comboBox('Tracking dimension group').click();
        await this.comboBox('Tracking dimension group').fill(value);
        await this.page.keyboard.press('Enter');

        await PageUtil.waitForD365Loading(this.waitForD365Loading);
    }

    async fillReleasedProductDetails(
        productName: string,
        itemModelGroup: string,
        itemGroup: string,
        storageDimensionGroup: string,
        trackingDimensionGroup: string
    ): Promise<void> {

        await this.fillProductName(productName);
        await this.selectItemModelGroup(itemModelGroup);
        await this.selectItemGroup(itemGroup);
        await this.selectStorageDimensionGroup(storageDimensionGroup);
        await this.selectTrackingDimensionGroup(trackingDimensionGroup);
    }

    // ───────────────────────── MANAGE COSTS ─────────────────────────

    async openManageCosts(): Promise<void> {

        await this.button('Manage costs').click();

        await PageUtil.waitForD365Loading(this.waitForD365Loading);
    }

    async openItemPrice(): Promise<void> {

        await this.button('Item price').click();

        await PageUtil.waitForD365Loading(this.waitForD365Loading);
    }

    // ───────────────────────── ITEM PRICE ─────────────────────────

    async fillVersion(value: string): Promise<void> {

        await this.comboBox('Version').fill(value);
        await this.page.keyboard.press('Enter');
    }

    async fillSite(value: string): Promise<void> {

        await this.comboBox('Site').fill(value);
        await this.page.keyboard.press('Enter');
    }

    async fillPrice(value: string): Promise<void> {

        await this.textBox('Price').fill(value);
    }

    async fillItemPriceDetails(
        version: string,
        site: string,
        price: string
    ): Promise<void> {

        await this.fillVersion(version);
        await this.fillSite(site);
        await this.fillPrice(price);
    }

    // ───────────────────────── COST CALCULATION ─────────────────────────

    async clickCalculateItemCost(): Promise<void> {

        await this.button('Calculate item cost').click();

        await PageUtil.waitForD365Loading(this.waitForD365Loading);
    }

    async fillCostingVersion(value: string): Promise<void> {

        await this.comboBox('Costing version').fill(value);
        await this.page.keyboard.press('Enter');
    }

    async fillCostSite(value: string): Promise<void> {

        await this.comboBox('Site').last().fill(value);
        await this.page.keyboard.press('Enter');
    }

    async fillCostCalculationDetails(
        costingVersion: string,
        site: string
    ): Promise<void> {

        await this.fillCostingVersion(costingVersion);
        await this.fillCostSite(site);
    }

    async activatePendingPrices(): Promise<void> {

        await this.button('Activate pending price').click();

        await PageUtil.waitForD365Loading(this.waitForD365Loading);
    }

    // ───────────────────────── ASSERTIONS ─────────────────────────

    async assertReleasedProductLoaded(): Promise<void> {

        await this.page.waitForLoadState('networkidle');
    }

    async verifyReleasedProductCreated(): Promise<void> {

        await this.page.waitForLoadState('networkidle');
    }

}