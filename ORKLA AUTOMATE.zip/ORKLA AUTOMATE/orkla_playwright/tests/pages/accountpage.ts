import { Page, Locator, expect } from "@playwright/test";
import { ENV } from "../config/env.config";
import { PageUtil } from "../utils/page.util";

export class AccountPage {
    constructor(private readonly page: Page) { }

    // ─── Selectors ────────────────────────────────────────────────────────────────
    private readonly SELECTORS = {
        // Navigation
        MODULE_ICON: ["#navPaneModuleID"],

        // Toolbar
        NEW_BUTTON: [
            'button[id*="SystemDefinedNewButton"][command="New"]',
            'button:has(span[id$="_SystemDefinedNewButton_label"])',
        ],
        OK_BUTTON: ['button:has-text("OK")', '#SysOperationTemplateForm_2_CommandButton',
            'button[name="CommandButton"]',],
        SAVE_BUTTON: ['button:has-text("Save")'],
        APPLY_BUTTON: ['button:has-text("Apply")'],
        ACCOUNT: [
            'div[data-dyn-columnname="CustTable_AccountNum"][data-dyn-controlname="CustTable_AccountNum"]',
        ],
        FILTER_ACCOUNT: [
            'input[name="FilterField_CustTable_AccountNum_AccountNum_Input_0"]',
        ],
        COLLECT: ['[id$="_aptabCollect_button"]'],
        STATEMENT: [
            '[id$="_mibCustAccountStatementExt"]',
            'span.button-label[for*="_mibCustAccountStatementExt"]',
        ],

        FROM_DATE: ['input[name="Fld3_1"]'],
        TO_DATE: ['input[name="Fld4_1"]'],
        DOWNLOAD_BUTTON: [
            '#SrsReportPdfViewerForm_6_PdfViewerExportMenuButton_button',
            'span[id$="_PdfViewerExportMenuButton_label"]',
        ],
        EXPORT_PDF_BUTTON: [
            '#SrsReportPdfViewerForm_6_PdfViewerExportToPdfButton',
            'button[type="button"][role="menuitem"][aria-label="PDF"]',
            'button[name="PdfViewerExportToPdfButton"]',
        ],

        // Loader
        LOADER: ["#ShellBlockingDiv"],
    };

    private treeItem(name: string): Locator {
        return this.page.getByRole("treeitem", {
            name,
            exact: true,
        });
    }

    private async expandTreeItem(name: string, index = 0): Promise<void> {
        const item = this.treeItem(name).nth(index);

        await item.waitFor({ state: "visible" });

        if ((await item.getAttribute("aria-expanded")) !== "true") {
            await item.click();
        }
    }

    private textBox(fieldName: string, description?: string): Locator {
        return this.page
            .getByRole("textbox", {
                name: fieldName,
                description,
                exact: true,
            })
            .last();
    }

    private button(buttonName: string): Locator {
        return this.page.getByRole("button", {
            name: new RegExp(buttonName, "i"),
        });
    }

    private option(optionName: string): Locator {
        return this.page.getByRole("option", {
            name: optionName,
            exact: true,
        });
    }

    private comboBox(fieldName: string): Locator {
        return this.page.getByRole("combobox", {
            name: fieldName,
            exact: true,
        });
    }

    private menuLink(name: string): Locator {
        return this.page.getByRole("link", {
            name,
            exact: true,
        });
    }
    // ───────────────────────── LOCATORS ─────────────────────────

    get moduleIcon(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.MODULE_ICON,
        );
    }

    get exportPdfButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.EXPORT_PDF_BUTTON,
        );
    }

    get downloadButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.DOWNLOAD_BUTTON,
        );
    }

    get collectButton(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, this.SELECTORS.COLLECT);
    }

    get statementButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.STATEMENT,
        );
    }

    get waitForD365Loading(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, ["#ShellBlockingDiv"]);
    }

    get saveButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.SAVE_BUTTON,
        );
    }

    get newButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.NEW_BUTTON,
        );
    }

    get applyButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.APPLY_BUTTON,
        );
    }

    get filterAccount(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.FILTER_ACCOUNT,
        );
    }

    get accountColumnHeader(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, this.SELECTORS.ACCOUNT);
    }

    get okButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.OK_BUTTON,
        );
    }

    get fromDate(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.FROM_DATE,
        );
    }

    get toDate(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, this.SELECTORS.TO_DATE);
    }

    // ───────────────────────── NAVIGATION ─────────────────────────

    async navigateToOV01Dashboard(): Promise<void> {
        await PageUtil.navigateTo(this.page, ENV.DASHBOARD_URL);
        await this.page.waitForLoadState("domcontentloaded");
    }


    async openMenu(module: string, parent: string, menu: string): Promise<void> {
        // Expand main module
        await this.expandTreeItem(module);

        // Expand first matching parent
        await this.expandTreeItem(parent, 0);

        // Click menu
        const menuItem = this.menuLink(menu);

        await menuItem.waitFor({ state: "visible" });
        await this.page.waitForLoadState("domcontentloaded");
        await menuItem.click();

        await this.page.waitForLoadState("domcontentloaded");
    }

    async openSalesOrderModule(): Promise<void> {
        await this.moduleIcon.click();
        await this.page.waitForLoadState("domcontentloaded");
        await this.openMenu("Accounts receivable", "Customers", "All customers");
        await this.page.waitForLoadState("domcontentloaded");
    }

    // ───────────────────────── TOOLBAR ACTIONS ─────────────────────────

    async clickOK(): Promise<void> {
        await this.okButton.click();
        //await this.page.keyboard.press('Alt+Enter');
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickCollect(): Promise<void> {
        await this.collectButton.waitFor({ state: "visible" });
        await this.collectButton.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickDownloadButton(): Promise<void> {
        await this.page.waitForLoadState("domcontentloaded");
        await this.downloadButton.click();
        await this.page.waitForLoadState("domcontentloaded");
        await this.exportPdfButton.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickStatement(): Promise<void> {
        await this.statementButton.waitFor({ state: "visible" });
        await this.statementButton.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickAccountColumnHeader(): Promise<void> {
        await this.accountColumnHeader.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async fillFilterField(value: string): Promise<void> {
        await this.clickAccountColumnHeader();
        await this.page.waitForLoadState("domcontentloaded");
        await this.filterAccount.click();
        await this.filterAccount.fill(value);
        await this.page.waitForLoadState("domcontentloaded");
        await this.button("Apply").last().click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async fillFromDate(value: string): Promise<void> {
        await this.fromDate.waitFor({ state: "visible", });
        await this.fromDate.click();
        await this.page.waitForTimeout(2000);
        await this.fromDate.fill(value);
        await this.page.waitForTimeout(2000);
        //await this.fromDate.press("Tab");
        await this.page.waitForLoadState("domcontentloaded");
    }

    async fillToDate(value: string): Promise<void> {
        await this.toDate.waitFor({ state: "visible", });
        await this.page.waitForTimeout(2000);
        await this.toDate.click();
        await this.page.waitForTimeout(2000);
        await this.toDate.fill(value);
        await this.page.waitForTimeout(2000);
        //await this.toDate.press("Tab");
        await this.page.waitForLoadState("domcontentloaded");
    }

    // ───────────────────────── ASSERTIONS ─────────────────────────

    async assertItemLoaded(): Promise<void> {
        await this.page.waitForLoadState("networkidle");
    }
}
