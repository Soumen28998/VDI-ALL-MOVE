import { Page, Locator } from "@playwright/test";
import { PageUtil } from "../utils/page.util";
import { ENV } from "../config/env.config";

export class CreateWorkerPage {

    constructor(private readonly page: Page) { }

    private readonly D365_URL =
        "https://orkla-uat2.sandbox.operations.dynamics.com/?cmp=ni01&mi=DefaultDashboard";

    private readonly SELECTORS = {

        MODULES: ["#navPaneModuleID"],

        WAREHOUSE_MANAGEMENT: ['a[role="treeitem"][data-dyn-title="Warehouse management"]'],
        COLLAPSE_ALL: ['button.modulesFlyout-CollapseAll'],
        SETUP: ['a[role="treeitem"][data-dyn-title="Setup"]'],
        WORKER: [
            'div.modulesFlyout-link[aria-label="Worker"][role="link"]',
            'div[role="link"][aria-label="Worker"]',
            'a.modulesFlyout-linkText[data-dyn-title="Worker"]',
            'div.modulesFlyout-link:has(a[data-dyn-title="Worker"])'
        ],

        WORKER_FILTER: [
            'input[id^="whsworker_"][id$="_QuickFilterControl_Input_input"]',
            'input[name="QuickFilterControl_Input"][aria-label="Filter"]',
            'input[role="combobox"][aria-label="Filter"]'
        ],

        NEW_WORKER: [
            'button[id^="whsworker_"][id$="_WorkUserNewButton"]',
            'button[name="WorkUserNewButton"]',
            'span.button-label[for^="whsworker_"][for$="_WorkUserNewButton"]:has-text("New")',
            'span[id^="whsworker_"][id$="_WorkUserNewButton_label"]'
        ],

        USER_ID: [
            'input[id^="WHSWorkUser_UserId_"][id$="_0_0_input"]',
            'input[id^="WHSWorkUser_UserId_"][id$="_input"]',
            'input[aria-label="User ID"][role="textbox"]',
            'input[aria-label="User ID"][aria-required="true"]',
            'input[maxlength="10"][aria-label="User ID"]',
            'input[name="WHSWorkUser_UserId"]'
        ],

        USER_NAME: [
            'input[id^="WHSWorkUser_UserName_"][id$="_0_0_input"]',
            'input[id^="WHSWorkUser_UserName_"][id$="_input"]',
            'input[aria-label="User name"][role="textbox"]',
            'input[aria-label="User name"][maxlength="60"]'
        ],

        DEFAULT_WAREHOUSE: [
            'input[id^="WHSWorkUser_UserDefaultWarehouse_"][id$="_0_0_input"]',
            'input[id^="WHSWorkUser_UserDefaultWarehouse_"][id$="_input"]',
            'input[aria-label="Default warehouse"][role="combobox"]',
            'input[aria-label="Default warehouse"][aria-haspopup="dialog"]'
        ],

        MENU_NAME: [
            'input[id^="WHSWorkUser_MenuName_"][id$="_0_0_input"]',
            'input[id^="WHSWorkUser_MenuName_"][id$="_input"]',
            'input[aria-label="Menu name"][role="combobox"]',
            'input[aria-label="Menu name"][aria-haspopup="dialog"]'
        ],

        SAVE_BUTTON: [
            'button[name="SystemDefinedSaveButton"]',
            'button:has-text("Save")'
        ],

        PASSWORD: [
            'input[name="password"]',
            'input[aria-label="Password"]'
        ],

        CONFIRM_PASSWORD: [
            'input[name="passwordConfirmation"]',
            'input[aria-label="Confirm password"]'
        ],

        SET_PASSWORD: [
            'button[id^="WHSResetUserPassword_"][id$="_Ok"]',
            'span.button-label[for^="WHSResetUserPassword_"][for$="_Ok"]:has-text("Set password")',
            'span[id^="WHSResetUserPassword_"][id$="_Ok_label"]'
        ],

        LOADER: [
            '#ShellBlockingDiv'
        ]
    };

    // ─────────────────────────────────────────────
    // GETTERS
    // ─────────────────────────────────────────────

    get modules(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page, this.SELECTORS.MODULES
        );
    }
    get collapseAll(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.COLLAPSE_ALL,
        );
    }

    get setup(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.SETUP,
        );
    }
    get warehouseManagement(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page, this.SELECTORS.WAREHOUSE_MANAGEMENT
        );
    }

    get worker(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page, this.SELECTORS.WORKER
        );
    }

    get workerFilter(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page, this.SELECTORS.WORKER_FILTER
        );
    }

    get newWorker(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page, this.SELECTORS.NEW_WORKER
        );
    }

    get userId(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page, this.SELECTORS.USER_ID
        );
    }

    get userName(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page, this.SELECTORS.USER_NAME
        );
    }

    get defaultWarehouse(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page, this.SELECTORS.DEFAULT_WAREHOUSE
        );
    }

    get menuName(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page, this.SELECTORS.MENU_NAME
        );
    }

    get saveButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page, this.SELECTORS.SAVE_BUTTON
        );
    }

    get password(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page, this.SELECTORS.PASSWORD
        );
    }

    get confirmPassword(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page, this.SELECTORS.CONFIRM_PASSWORD
        );
    }

    get setPassword(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page, this.SELECTORS.SET_PASSWORD
        );
    }

    // ─────────────────────────────────────────────
    // NAVIGATION
    // ─────────────────────────────────────────────

    async navigateToD365Dashboard(): Promise<void> {
        await this.page.goto(ENV.DASHBOARD_URL);
        await this.page.waitForLoadState("domcontentloaded");
        await this.page.goto(this.D365_URL);
        await this.page.waitForLoadState("domcontentloaded");
        await this.modules.waitFor({ state: "visible" });
    }

    // ─────────────────────────────────────────────
    // OPEN WORKER PAGE
    // ─────────────────────────────────────────────
    async clickCollapseAll(): Promise<void> {
        await this.collapseAll.waitFor({ state: "visible" });
        await this.collapseAll.click();
        await this.page.waitForLoadState('domcontentloaded');
    }

    async clickSetup(): Promise<void> {
        await this.setup.waitFor({ state: "visible" });
        await this.setup.click();
        await this.page.waitForLoadState('domcontentloaded');
    }
    async clickModules(): Promise<void> {
        await this.modules.waitFor({ state: "visible" });
        await this.modules.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async selectWarehouseManagement(): Promise<void> {
        await this.warehouseManagement.waitFor({ state: "visible" });
        await this.warehouseManagement.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async openWorker(): Promise<void> {
        await this.worker.waitFor({ state: "visible" });
        await this.worker.click();
        await this.page.waitForLoadState("domcontentloaded");
        await this.workerFilter.waitFor({ state: "visible" });
    }

    // ─────────────────────────────────────────────
    // FILTER AND SELECT WORKER
    // ─────────────────────────────────────────────

    async filterWorkerByName(workerName: string): Promise<void> {
        await this.workerFilter.waitFor({ state: "visible" });
        await this.workerFilter.fill(workerName);
        await this.page.waitForLoadState("domcontentloaded");
    }

    async selectWorkerOption(workerName: string): Promise<void> {
        await this.page.keyboard.press('Enter');
        await this.page.waitForLoadState("domcontentloaded");
    }

    // ─────────────────────────────────────────────
    // CREATE NEW WORKER
    // ─────────────────────────────────────────────

    async clickNewWorker(): Promise<void> {
        await this.newWorker.waitFor({ state: "visible" });
        await this.newWorker.click();
        await this.page.waitForLoadState("domcontentloaded");
        await this.userId.waitFor({ state: "visible" });
    }

    async enterUserId(value: string): Promise<void> {
        await this.userId.waitFor({ state: "visible" });
        await this.userId.fill(value);
        await this.page.waitForLoadState("domcontentloaded");
    }

    async enterUserName(value: string): Promise<void> {
        await this.userName.waitFor({ state: "visible" });
        await this.userName.fill(value);
        await this.page.waitForLoadState("domcontentloaded");
    }

    async enterDefaultWarehouse(value: string): Promise<void> {
        await this.defaultWarehouse.waitFor({ state: "visible" });
        await this.defaultWarehouse.fill(value);
        await this.defaultWarehouse.press("Enter");
        await this.page.waitForLoadState("domcontentloaded");
    }

    async enterMenuName(value: string): Promise<void> {
        await this.menuName.waitFor({ state: "visible" });
        await this.menuName.fill(value);
        await this.menuName.press("Enter");
        await this.page.waitForLoadState("domcontentloaded");
    }

    // ─────────────────────────────────────────────
    // SAVE WORKER
    // ─────────────────────────────────────────────

    async saveWorkerDetails(): Promise<void> {
        await this.page.keyboard.press('Alt+S');
        await this.page.waitForLoadState("domcontentloaded");
    }

    // ─────────────────────────────────────────────
    // SET PASSWORD
    // ─────────────────────────────────────────────

    async enterPassword(value: string): Promise<void> {
        await this.password.waitFor({ state: "visible" });
        await this.password.fill(value);
        await this.page.waitForLoadState("domcontentloaded");
    }

    async enterConfirmPassword(value: string): Promise<void> {
        await this.confirmPassword.waitFor({ state: "visible" });
        await this.confirmPassword.fill(value);
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickSetPassword(): Promise<void> {
        await this.setPassword.waitFor({ state: "visible" });
        await this.setPassword.click();
        await this.page.waitForLoadState("domcontentloaded");
    }
}