import { Page, Locator, expect } from "@playwright/test";
import { ENV } from "../config/env.config";
import { PageUtil } from "../utils/page.util";

export class pricecorrection {
    // Loader

    constructor(private readonly page: Page) { }

    // ─── Selectors ──────────────────────────────────────────────────────────────
    private readonly SELECTORS = {
        SALES_ORDER_COLUMN: ['div[data-dyn-columnname="CustInvoiceJour_SalesNum"]'],
        APPLY_BUTTON: ['button:has-text("Apply")'],

    };

    private textBox(fieldName: string, description?: string): Locator {
        return this.page
            .getByRole("textbox", {
                name: fieldName,
                description,
                exact: true,
            })
            .last();
    }

    private comboBox(fieldName: string): Locator {
        return this.page.getByRole("combobox", {
            name: fieldName,
            exact: true,
        });
    }

    private button(buttonName: string): Locator {
        return this.page.getByRole("button", {
            name: new RegExp(buttonName, "i"),
        });
    }

    get SalesOrderHeader(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.SALES_ORDER_COLUMN,
        );
    }

    get applyButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.APPLY_BUTTON,
        );
    }

    async selectInvoiceHeaderRow(salesOrderNumber: string): Promise<void> {
        // Find the row containing the Sales order number
        const row = this.page
            .locator('[role="row"]')
            .filter({
                hasText: salesOrderNumber,
            })
            .first();

        await row.waitFor({
            state: "visible",
            timeout: 15000,
        });

        // Select the checkbox inside that row
        const rowCheckbox = row.getByRole("checkbox").first();

        await rowCheckbox.waitFor({
            state: "visible",
            timeout: 10000,
        });

        // Select only if not already selected
        if (!(await rowCheckbox.isChecked())) {
            await rowCheckbox.click();
        }

        console.log(`Selected invoice row: ${salesOrderNumber}`);
    }

    // ───────────────────────── ACTIONS ─────────────────────────

    async clickApply(): Promise<void> {
        await this.applyButton.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickcreditnote(): Promise<void> {
        await this.page.getByText("Sell", { exact: true }).last().click();
        await this.page
            .getByRole("button", { name: "Credit note" })
            .click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async fillSalesOrderFilter(salesOrderNumber: string): Promise<void> {
        const salesOrderFilter = this.page.getByRole("combobox", {
            name: "Filter field: Sales order, operator: begins with",
            exact: true,
        });

        await salesOrderFilter.waitFor({ state: "visible" });
        await salesOrderFilter.click();
        await salesOrderFilter.fill(salesOrderNumber);
        await this.page.keyboard.press("Enter");
        await this.page.waitForLoadState("domcontentloaded");
        await this.clickApply();
        //await this.button("Apply").click();
        await this.page.waitForLoadState("domcontentloaded");
        await this.selectInvoiceHeaderRow(salesOrderNumber);
        await this.button("OK").click();
    }

    // ───────────────────────── ASSERTIONS ─────────────────────────

    async assertSalesOrderLoaded(): Promise<void> {
        await this.page.waitForLoadState("networkidle");
    }
}
