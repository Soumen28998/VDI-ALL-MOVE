import { Page, Locator, expect } from "@playwright/test";
import { ENV } from "../config/env.config";
import { PageUtil } from "../utils/page.util";

export class FreeTaxPage {
    constructor(private readonly page: Page) { }

    // ─── Selectors ────────────────────────────────────────────────────────────────
    private readonly SELECTORS = {
        // Navigation
        MODULE_ICON: ["#navPaneModuleID"],

        // Toolbar
        NEW_BUTTON: [
            'button[id*="SystemDefinedNewButton"][command="New"]',
            'button:has(span[id$="_SystemDefinedNewButton_label"])',
        ],
        OK_BUTTON: ['button:has-text("OK")'],
        SAVE_BUTTON: ['button:has-text("Save")'],
        APPLY_BUTTON: ['button:has-text("Apply")'],
        ORDER_ACCOUNT_INPUT: [
            'input[name="CVHeader_OrderAccount"][role="combobox"]'
        ],
        DESCRIPTION_INPUT: [
            'input[aria-label="Description"][role="textbox"]'
        ],

        LEDGER_ACCOUNT_INPUT: [
            'input[id$="LedgerAccount_0_segmentedEntryLookup_input"][role="combobox"]'
        ],

        TAX_ITEM_GROUP_INPUT: [
            'input[aria-label="Item sales tax group"][role="combobox"]'
        ],

        UNIT_PRICE: [
            'input[aria-label="Unit price"][role="textbox"]'
        ],

        LINE_DETAILS_TAB: [
            'button[aria-label="Line details"]'
        ],

        FINANCIAL_DIMENSIONS_LINE: [
            'span.pivot-label:has-text("Financial dimensions line")'
        ],

        BUSINESS_UNIT: [
            'input[name="DimensionEntryControlLine_DECValue_BusinessUnit"][role="combobox"]'
        ],

        LOCAL_COST_CENTER: [
            'input[name="DimensionEntryControlLine_DECValue_LocalCostCenter"][role="combobox"]'
        ],

        LOCAL_PROJECT: [
            'input[name="DimensionEntryControlLine_DECValue_LocalProject"][role="combobox"]'
        ],

        POST_BUTTON: [
            'button:has-text("Post")'
        ],

        LASERNET_BUTTON: [
            'span.button-label-dropDown:has-text("Lasernet")'
        ],

        LASERNET_ORIGINAL: [

        ],

        DOWNLOAD_BUTTON: [
            'span[id$="_DownloadFile_label"]',
        ],
        EXPORT_PDF_BUTTON: [
            'button[role="menuitem"][aria-label$=".PDF"]'
        ],

        // Loader
        LOADER: ["#ShellBlockingDiv"],
    };

    private treeItem(name: string): Locator {
        return this.page.getByRole("treeitem", {
            name,
            exact: true,
        });
    }

    private async expandTreeItem(name: string, index = 0): Promise<void> {
        const item = this.treeItem(name).nth(index);

        await item.waitFor({ state: "visible" });

        if ((await item.getAttribute("aria-expanded")) !== "true") {
            await item.click();
        }
    }

    private textBox(fieldName: string, description?: string): Locator {
        return this.page
            .getByRole("textbox", {
                name: fieldName,
                description,
                exact: true,
            })
            .last();
    }

    private button(buttonName: string): Locator {
        return this.page.getByRole("button", {
            name: new RegExp(buttonName, "i"),
        });
    }

    private option(optionName: string): Locator {
        return this.page.getByRole("option", {
            name: optionName,
            exact: true,
        });
    }

    private comboBox(fieldName: string): Locator {
        return this.page.getByRole("combobox", {
            name: fieldName,
            exact: true,
        });
    }

    private menuLink(name: string): Locator {
        return this.page.getByRole("link", {
            name,
            exact: true,
        });
    }

    async expandLineDetailsTab(): Promise<void> {
        await this.lineDetailsTab.waitFor({ state: "visible" });

        if (await this.lineDetailsTab.getAttribute("aria-expanded") !== "true") {
            await this.lineDetailsTab.click();

            await expect(this.lineDetailsTab).toHaveAttribute(
                "aria-expanded",
                "true",
            );
        }
    }

    // ───────────────────────── LOCATORS ─────────────────────────

    get moduleIcon(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.MODULE_ICON,
        );
    }

    get exportPdfButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.EXPORT_PDF_BUTTON,
        );
    }

    get laserNetOriginal(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.LASERNET_ORIGINAL,
        );
    }

    get downloadButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.DOWNLOAD_BUTTON,
        );
    }

    get orderAccountInput(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.ORDER_ACCOUNT_INPUT,
        );
    }

    get laserNetButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.LASERNET_BUTTON,
        );
    }

    get descriptionInput(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.DESCRIPTION_INPUT,
        );
    }

    get taxItemGroupInput(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.TAX_ITEM_GROUP_INPUT,
        );
    }

    get businessUnit(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.BUSINESS_UNIT,
        );
    }

    get localProject(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.LOCAL_PROJECT,
        );
    }

    get unitPrice(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.UNIT_PRICE,
        );
    }

    get postButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.POST_BUTTON,
        );
    }

    get ledgerAccountInput(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.LEDGER_ACCOUNT_INPUT,
        );
    }

    get financialDimensionsLine(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.FINANCIAL_DIMENSIONS_LINE,
        );
    }

    get localCostCenter(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.LOCAL_COST_CENTER,
        );
    }

    get waitForD365Loading(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, ["#ShellBlockingDiv"]);
    }

    get saveButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.SAVE_BUTTON,
        );
    }

    get applyButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.APPLY_BUTTON,
        );
    }

    get okButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.OK_BUTTON,
        );
    }

    get newButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.NEW_BUTTON,
        );
    }

    get lineDetailsTab(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.LINE_DETAILS_TAB,
        );
    }

    // ───────────────────────── NAVIGATION ─────────────────────────

    async openMenu(module: string, parent: string, menu: string): Promise<void> {
        // Expand main module
        await this.expandTreeItem(module);

        // Expand first matching parent
        await this.expandTreeItem(parent, 0);

        // Click menu
        const menuItem = this.menuLink(menu);

        await menuItem.waitFor({ state: "visible" });
        await this.page.waitForLoadState("domcontentloaded");
        await menuItem.click();

        await this.page.waitForLoadState("domcontentloaded");
    }

    async openFreeTaxModule(): Promise<void> {
        await this.moduleIcon.click();
        await this.page.waitForLoadState("domcontentloaded");
        await this.openMenu("Accounts receivable", "Invoices", "All free text invoices");
        await this.page.waitForLoadState("domcontentloaded");
        await this.clickNew();
        await this.page.waitForLoadState("domcontentloaded");
    }

    // ───────────────────────── TOOLBAR ACTIONS ─────────────────────────

    async clickOK(): Promise<void> {
        await this.okButton.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickNew(): Promise<void> {
        await this.newButton.first().click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickPostButton(): Promise<void> {
        await this.postButton.waitFor({ state: "visible" });
        await this.postButton.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickFinancialDimensionsLine(): Promise<void> {
        await this.financialDimensionsLine.waitFor({ state: "visible" });
        await this.financialDimensionsLine.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickLaserNetOriginal(): Promise<void> {
        await this.page.keyboard.press("ArrowDown");
        await this.page.keyboard.press("Enter");
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickLaserNetButton(): Promise<void> {
        await this.laserNetButton.waitFor({ state: "visible" });
        await this.page.getByRole('button', { name: 'Lasernet' }).click();
        await this.page.waitForLoadState("domcontentloaded");
        await this.page.getByRole('menuitem', { name: 'Lasernet Original' }).click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickDownloadButton(): Promise<void> {
        await this.page.waitForLoadState("domcontentloaded");
        await this.page.getByRole('button', { name: 'Download' }).click();
        await this.page.waitForLoadState("domcontentloaded");
        await this.exportPdfButton.click();
        await this.page.waitForLoadState("domcontentloaded");
        await this.page.keyboard.press("Escape");
        await this.page.waitForLoadState("domcontentloaded");
    }

    async fillOrderAccountInput(value: string) {
        await this.orderAccountInput.click();
        await this.page.waitForLoadState("domcontentloaded");
        await this.orderAccountInput.fill(value);
        await this.page.keyboard.press("Enter");
        await this.page.waitForLoadState("domcontentloaded");
    }

    async filldescriptionInput(value: string) {
        await this.descriptionInput.click();
        await this.page.waitForLoadState("domcontentloaded");
        await this.descriptionInput.fill(value);
        await this.page.waitForLoadState("domcontentloaded");
    }

    async fillledgerAccountInput(value: string) {
        await this.ledgerAccountInput.click();
        await this.page.waitForLoadState("domcontentloaded");
        await this.ledgerAccountInput.fill(value);
        await this.page.waitForLoadState("domcontentloaded");
    }

    async filltaxItemGroupInput(value: string) {
        await this.taxItemGroupInput.click();
        await this.page.waitForLoadState("domcontentloaded");
        await this.taxItemGroupInput.fill(value);
        await this.page.waitForLoadState("domcontentloaded");
    }

    async fillUnitPrice(value: string): Promise<void> {
        await this.unitPrice.waitFor({ state: "visible" });
        await this.unitPrice.click();
        await this.page.waitForLoadState("domcontentloaded");
        await this.unitPrice.fill(value);
        await this.page.waitForLoadState("domcontentloaded");
    }

    async fillBusinessUnit(value: string): Promise<void> {
        await this.businessUnit.waitFor({ state: "visible" });
        await this.businessUnit.click();
        await this.page.waitForLoadState("domcontentloaded");
        await this.businessUnit.fill(value);
        await this.page.keyboard.press("Enter");
        await this.page.waitForLoadState("domcontentloaded");
    }

    async fillLocalCostCenter(value: string): Promise<void> {
        await this.localCostCenter.waitFor({ state: "visible" });
        await this.localCostCenter.click();
        await this.page.waitForLoadState("domcontentloaded");
        await this.localCostCenter.fill(value);
        await this.page.keyboard.press("Enter");
        await this.page.waitForLoadState("domcontentloaded");
    }

    async fillLocalProject(value: string): Promise<void> {
        await this.localProject.waitFor({ state: "visible" });
        await this.localProject.click();
        await this.page.waitForLoadState("domcontentloaded");
        await this.localProject.fill(value);
        await this.page.keyboard.press("Enter");
        await this.page.waitForLoadState("domcontentloaded");
    }

    // ───────────────────────── ASSERTIONS ─────────────────────────

    async assertItemLoaded(): Promise<void> {
        await this.page.waitForLoadState("networkidle");
    }
}

