import { Page, Locator, expect } from "@playwright/test";
import { ENV } from "../config/env.config";
import { PageUtil } from "../utils/page.util";

export class SalesForeignCurrency {
    constructor(private readonly page: Page) { }

    // ─── Selectors ────────────────────────────────────────────────────────────────
    private readonly SELECTORS = {
        // Navigation
        MODULE_ICON: ["#navPaneModuleID"],

        // Toolbar
        FOREIGN_CURRENCY_REVALUATION: [
            'button:has-text("Foreign currency revaluation")'
        ],
        OK_BUTTON: ['button:has-text("OK")'],
        CONSIDERED_DATE: ['input[name="Considered date"][role="combobox"]'],
        RATE_DATE: ['input[name="Date of rate"][role="combobox"]'],
        DESCRIPTION: ['input[name="Description"][role="textbox"]'],
        NOTES: ['input[name="Notes"][role="textbox"]'],
    };

    //     await page.getByRole('button', { name: 'Foreign currency revaluation' }).click();
    //   await page.getByRole('combobox', { name: 'Considered date' }).click();
    //   await page.getByRole('combobox', { name: 'Date of rate' }).click();
    //   await page.getByRole('textbox', { name: 'Description', exact: true }).click();
    //   await page.getByRole('textbox', { name: 'Notes', description: 'Notes about the foreign currency revaluation' }).click();


    private treeItem(name: string): Locator {
        return this.page.getByRole("treeitem", {
            name,
            exact: true,
        });
    }

    private async expandTreeItem(name: string, index = 0): Promise<void> {
        const item = this.treeItem(name).nth(index);

        await item.waitFor({ state: "visible" });

        if ((await item.getAttribute("aria-expanded")) !== "true") {
            await item.click();
        }
    }

    private textBox(fieldName: string, description?: string): Locator {
        return this.page
            .getByRole("textbox", {
                name: fieldName,
                description,
                exact: true,
            })
            .last();
    }

    private button(buttonName: string): Locator {
        return this.page.getByRole("button", {
            name: new RegExp(buttonName, "i"),
        });
    }

    private option(optionName: string): Locator {
        return this.page.getByRole("option", {
            name: optionName,
            exact: true,
        });
    }

    private comboBox(fieldName: string): Locator {
        return this.page.getByRole("combobox", {
            name: fieldName,
            exact: true,
        });
    }

    private menuLink(name: string): Locator {
        return this.page.getByRole("link", {
            name,
            exact: true,
        });
    }


    // ───────────────────────── LOCATORS ─────────────────────────

    get moduleIcon(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.MODULE_ICON,
        );
    }

    get okButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.OK_BUTTON,
        );
    }

    get rateDate(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.RATE_DATE,
        );
    }

    get notes(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.NOTES,
        );
    }

    get description(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.DESCRIPTION,
        );
    }

    get foreignCurrencyRevaluationButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.FOREIGN_CURRENCY_REVALUATION,
        );
    }

    get consideredDate(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.CONSIDERED_DATE,
        );
    }

    get waitForD365Loading(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, ["#ShellBlockingDiv"]);
    }


    // ───────────────────────── NAVIGATION ─────────────────────────

    async openMenu(module: string, parent: string, menu: string): Promise<void> {
        // Expand main module
        await this.expandTreeItem(module);

        // Expand first matching parent
        await this.expandTreeItem(parent, 0);

        // Click menu
        const menuItem = this.menuLink(menu);

        await menuItem.waitFor({ state: "visible" });
        await this.page.waitForLoadState("domcontentloaded");
        await menuItem.click();

        await this.page.waitForLoadState("domcontentloaded");
    }

    async openForeignCurrencyModule(): Promise<void> {
        await this.moduleIcon.click();
        await this.page.waitForLoadState("domcontentloaded");
        await this.openMenu("Accounts receivable", "Periodic tasks", "Foreign currency revaluation");
        await this.page.waitForLoadState("domcontentloaded");
        await this.clickForeignCurrencyRevaluation();
    }

    async clickPostConfirmationOK(): Promise<void> {
        const confirmationPopup = this.page.getByLabel("One or more account structures or advanced rules requires a dimension");
      
        await confirmationPopup.waitFor({
            state: "visible",
            timeout: 30000,
        });

        const okButton = confirmationPopup.getByRole("button", {
            name: "Yes",
            exact: true,
        });

        await okButton.waitFor({
            state: "visible",
            timeout: 10000,
        });

        await expect(okButton).toBeEnabled();
        await okButton.click();
        console.log("Post confirmation OK clicked.");
    }

    async clickPostConfirmationYes(): Promise<void> {
        const confirmationPopup = this.page.getByLabel(
            "The date of the rate is different from the considered date"
        );

        const popupVisible = await confirmationPopup
            .isVisible()
            .catch(() => false);

        if (!popupVisible) {
            console.log(
                "Confirmation popup not displayed. Continuing without clicking Yes."
            );
            return;
        }

        console.log("Confirmation popup displayed.");

        const yesButton = confirmationPopup.getByRole("button", {
            name: "Yes",
            exact: true,
        });

        await expect(yesButton).toBeVisible({ timeout: 10000 });
        await expect(yesButton).toBeEnabled();

        await yesButton.click();

        console.log("Clicked Yes on confirmation popup.");
    }

    // ───────────────────────── TOOLBAR ACTIONS ─────────────────────────

    async clickOK(): Promise<void> {
        await this.okButton.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickForeignCurrencyRevaluation(): Promise<void> {
        await this.page.getByRole('button', { name: 'Foreign currency revaluation' }).click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async fillconsideredDate(value: string): Promise<void> {
        await this.page.getByRole('combobox', { name: 'Considered date' }).click();
        await this.page.getByRole('combobox', { name: 'Considered date' }).fill(value);
        await this.page.waitForLoadState("domcontentloaded");
    }
    async fillrateDate(value: string): Promise<void> {
        await this.page.getByRole('combobox', { name: 'Date of rate' }).click();
        await this.page.getByRole('combobox', { name: 'Date of rate' }).fill(value);
        await this.page.waitForLoadState("domcontentloaded");
    }
    async filldescription(value: string): Promise<void> {
        await this.page.getByRole('textbox', { name: 'Description', exact: true }).click();
        await this.page.getByRole('textbox', { name: 'Description', exact: true }).fill(value);
        await this.page.waitForLoadState("domcontentloaded");
    }
    async fillnotes(value: string): Promise<void> {
        await this.page.getByRole('textbox', { name: 'Notes', description: 'Notes about the foreign currency revaluation' }).click();
        await this.page.getByRole('textbox', { name: 'Notes', description: 'Notes about the foreign currency revaluation' }).fill(value);
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickValidatepopup(): Promise<void> {
        await this.clickOK();
        await this.page.waitForLoadState("domcontentloaded");
        await this.clickPostConfirmationOK();
        await this.page.waitForLoadState("domcontentloaded");
        await this.clickPostConfirmationYes();
    }
    // ───────────────────────── ASSERTIONS ─────────────────────────

    async assertItemLoaded(): Promise<void> {
        await this.page.waitForLoadState("networkidle");
    }
}
