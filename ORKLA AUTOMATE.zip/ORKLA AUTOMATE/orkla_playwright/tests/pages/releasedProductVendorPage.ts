
import { Page, Locator } from "@playwright/test";
import { ENV } from "../config/env.config";
import { PageUtil } from "../utils/page.util";

export class ReleasedProductVendorPage {

    constructor(private readonly page: Page) { }

    // ───────────────────────── URL ─────────────────────────

    private readonly D365_URL =
        "https://orkla-uat2.sandbox.operations.dynamics.com/?cmp=snl&mi=DefaultDashboard";


    // ───────────────────────── SELECTORS ─────────────────────────

    private readonly SELECTORS = {

        // Navigation
        MODULE_ICON: ["#navPaneModuleID"],
        COLLAPSE_ALL: ['button.modulesFlyout-CollapseAll'],
        PRODUCT_INFORMATION_MANAGEMENT: [
            'a[role="treeitem"][data-dyn-title="Product information management"]',
            'a.modulesPane-module[aria-level="2"][data-dyn-title="Product information management"]'
        ],
        PRODUCTS_MENU: [
            'a[role="treeitem"][data-dyn-title="Products"]',
            'a.modulesFlyout-LinkGroup[aria-label="Products"][aria-level="1"]'
        ],
        RELEASED_PRODUCTS: [
            'div[role="link"][aria-label="Released products"]',
            'div.modulesFlyout-link:has(a[data-dyn-title="Released products"])',
            'a.modulesFlyout-linkText[data-dyn-title="Released products"]'
        ],

        // Product filter
        FILTER_INPUT: [
            'input[name="QuickFilter_Input"][aria-label="Filter"]',
            'input[id$="_QuickFilter_Input_input"]',
            'input[role="combobox"][aria-label="Filter"]'
        ],

        ITEM_NUMBER_OPTION: [
            'li[role="option"]:has(span.quickFilter-listFieldName:text-is("Item number"))',
            'li.quickFilter-listItem[id$="_QuickFilter_listbox_item0"]',
            'li[role="option"]:has-text("Item number")'
        ],

        PURCHASE_TAB: [
            'button[id$="_ActionPaneTabPurchase_button"]',
            'button.appBarTab-header:has(span.appBarTab-headerLabel:text-is("Purchase"))',
            'button[aria-expanded="true"]:has-text("Purchase")'
        ],
        // Vendor setup
        SETUP_BUTTON: [
            'button[data-dyn-controlname="PdsApprovedVendorList"]',
            'button[name="PdsApprovedVendorList"]',
            'button[id$="_PdsApprovedVendorList"]'
        ],

        ADD_BUTTON: [
            'button[id$="_AddRecord"]',
            'button[name="AddRecord"]'
        ],

        VENDOR_INPUT: [
            'input[aria-label="Vendor"][role="combobox"]',
            'input[type="text"][role="combobox"][aria-label="Vendor"]',
            'input[id^="PdsApprovedVendorList_PdsApprovedVendor_"][id$="_input"]',
            'input.dyn-field[aria-label="Vendor"]'
        ],

        SAVE_BUTTON: [
            'button[id$="_SystemDefinedSaveButton"]',
            'button[name="SystemDefinedSaveButton"]',
            'button:has(span.button-label:text-is("Save"))',
            'button[data-dyn-controlname="SystemDefinedSaveButton"]',
            'button:has-text("Save")'
        ]
    };


    // ───────────────────────── LOCATOR GETTERS ─────────────────────────

    get moduleIcon(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page, this.SELECTORS.MODULE_ICON
        );
    }
    get collapseAll(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.COLLAPSE_ALL,
        );
    }
    get PURCHASE_TAB(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.PURCHASE_TAB
        );
    }
    get productInformationManagement(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page, this.SELECTORS.PRODUCT_INFORMATION_MANAGEMENT
        );
    }
    get PRODUCTS_MENU(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.PRODUCTS_MENU
        );
    }
    get releasedProducts(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page, this.SELECTORS.RELEASED_PRODUCTS
        );
    }

    get filterInput(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page, this.SELECTORS.FILTER_INPUT
        );
    }

    get itemNumberOption(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page, this.SELECTORS.ITEM_NUMBER_OPTION
        );
    }

    get setupButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page, this.SELECTORS.SETUP_BUTTON
        );
    }

    get addButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page, this.SELECTORS.ADD_BUTTON
        );
    }

    get vendorInput(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page, this.SELECTORS.VENDOR_INPUT
        );
    }

    get saveButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page, this.SELECTORS.SAVE_BUTTON
        );
    }


    // ───────────────────────── COMMON WAIT ─────────────────────────

    private async waitVisible(locator: Locator): Promise<void> {
        await locator.waitFor({
            state: "visible",
            timeout: 30000
        });
    }


    // ───────────────────────── NAVIGATION ─────────────────────────

    async navigateToD365(): Promise<void> {

        await this.page.goto(ENV.DASHBOARD_URL, {
            waitUntil: "domcontentloaded"
        });

        await this.page.goto(this.D365_URL, {
            waitUntil: "domcontentloaded"
        });

        await this.waitVisible(this.moduleIcon);
    }

    async clickModuleIcon(): Promise<void> {
        await this.waitVisible(this.moduleIcon);
        await this.moduleIcon.click();
        await this.page.waitForLoadState('domcontentloaded');
    }

    async clickProductInformationManagement(): Promise<void> {
        await this.waitVisible(this.productInformationManagement);
        await this.productInformationManagement.click();
        await this.page.waitForLoadState('domcontentloaded');
        await this.clickCollapseAll();
        await this.page.waitForLoadState('domcontentloaded');
        await this.clickProductsMenu();
        await this.page.waitForLoadState('domcontentloaded');
    }

    async clickReleasedProducts(): Promise<void> {
        await this.waitVisible(this.releasedProducts);
        await this.releasedProducts.click();
        await this.page.waitForLoadState('domcontentloaded');
    }

    async clickCollapseAll(): Promise<void> {
        await this.collapseAll.waitFor({ state: "visible" });
        await this.collapseAll.click();
        await this.page.waitForLoadState('domcontentloaded');
    }

    async clickProductsMenu(): Promise<void> {
        await this.PRODUCTS_MENU.waitFor({ state: 'visible' });
        await this.PRODUCTS_MENU.click();
        await this.page.waitForLoadState('domcontentloaded');
    }
    async clickPurchaseTab(): Promise<void> {
        await this.PURCHASE_TAB.waitFor({ state: 'visible' });
        await this.PURCHASE_TAB.click();
        await this.page.waitForLoadState('domcontentloaded');
    }
    // ───────────────────────── FILTER PRODUCT ─────────────────────────

    async filterReleasedProduct(itemNumber: string): Promise<void> {

        await this.waitVisible(this.filterInput);

        await this.filterInput.fill(itemNumber);

        // Select Item number filter field.
        await this.waitVisible(this.itemNumberOption);
        await this.itemNumberOption.click();
        await this.page.waitForLoadState('domcontentloaded');

        // Allow D365 to apply the filter.
        await this.page.waitForLoadState("domcontentloaded").catch(() => { });
    }


    // ───────────────────────── VENDOR SETUP ─────────────────────────

    async clickSetup(): Promise<void> {
        await this.clickPurchaseTab();
        await this.page.waitForLoadState('domcontentloaded');
        await this.setupButton.click();
        await this.page.waitForLoadState('domcontentloaded');
    }

    async clickAdd(): Promise<void> {

        await this.waitVisible(this.addButton);
        await this.addButton.click();
        await this.page.waitForLoadState('domcontentloaded');
    }


    // ───────────────────────── ENTER VENDOR ─────────────────────────

    async enterVendor(vendor: string): Promise<void> {

        await this.waitVisible(this.vendorInput);
        await this.vendorInput.fill(vendor);
        // Commit vendor lookup.
        await this.vendorInput.press("Enter");
        await this.page.waitForLoadState('domcontentloaded');
    }


    // ───────────────────────── SAVE ─────────────────────────

    async clickSave(): Promise<void> {
        await this.page.keyboard.press('Alt+S');
        await this.page.waitForLoadState('domcontentloaded');
    }
}
