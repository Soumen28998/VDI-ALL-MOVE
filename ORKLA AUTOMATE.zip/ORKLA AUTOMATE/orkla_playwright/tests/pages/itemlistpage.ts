import { Page, Locator, expect } from "@playwright/test";
import { ENV } from "../config/env.config";
import { PageUtil } from "../utils/page.util";

export class ItemListPage {
  constructor(private readonly page: Page) { }

  // ─── Selectors ────────────────────────────────────────────────────────────────
  private readonly SELECTORS = {
    // Navigation
    MODULE_ICON: ["#navPaneModuleID"],

    // Toolbar
    NEW_BUTTON: [
      'button[id*="SystemDefinedNewButton"][command="New"]',
      'button:has(span[id$="_SystemDefinedNewButton_label"])',
    ],
    OK_BUTTON: ['button:has-text("OK")'],
    SAVE_BUTTON: ['button:has-text("Save")'],

    // Loader
    LOADER: ["#ShellBlockingDiv"],
  };

  private treeItem(name: string) {
    return this.page.getByRole("treeitem", { name });
  }

  private textBox(fieldName: string, description?: string): Locator {
    return this.page
      .getByRole("textbox", {
        name: fieldName,
        description,
        exact: true,
      })
      .last();
  }

  private button(buttonName: string): Locator {
    return this.page.getByRole("button", {
      name: new RegExp(buttonName, "i"),
    });
  }

  private option(optionName: string): Locator {
    return this.page.getByRole("option", {
      name: optionName,
      exact: true,
    });
  }

  private comboBox(fieldName: string): Locator {
    return this.page.getByRole("combobox", {
      name: fieldName,
      exact: true,
    });
  }

  private menuItem(name: string): Locator {
    return this.page.getByRole("link", {
      name,
      exact: true,
    });
  }

  // ───────────────────────── LOCATORS ─────────────────────────

  get moduleIcon(): Locator {
    return PageUtil.getFirstMatchingLocator(
      this.page,
      this.SELECTORS.MODULE_ICON,
    );
  }

  get waitForD365Loading(): Locator {
    return PageUtil.getFirstMatchingLocator(this.page, ["#ShellBlockingDiv"]);
  }

  get saveButton(): Locator {
    return PageUtil.getFirstMatchingLocator(
      this.page,
      this.SELECTORS.SAVE_BUTTON,
    );
  }

  get newButton(): Locator {
    return PageUtil.getFirstMatchingLocator(
      this.page,
      this.SELECTORS.NEW_BUTTON,
    );
  }

  get okButton(): Locator {
    return PageUtil.getFirstMatchingLocator(
      this.page,
      this.SELECTORS.OK_BUTTON,
    );
  }

  // ───────────────────────── NAVIGATION ─────────────────────────
  async navigateToItemlistPage(): Promise<void> {
    await this.page.goto(ENV.SBL_URL);
    await this.page.waitForLoadState("domcontentloaded");
  }

  async openMenu(module: string, parent: string, child: string, menu: string) {
    const moduleNode = this.treeItem(module);

    if ((await moduleNode.getAttribute("aria-expanded")) !== "true") {
      await moduleNode.click();
    }

    await this.treeItem(parent).waitFor();
    await this.treeItem(parent).dblclick();

    await this.treeItem(child).waitFor();
    await this.treeItem(child).dblclick();

    await this.menuItem(menu).waitFor({ state: "visible" });
    await this.menuItem(menu).click();

    await this.page.waitForLoadState("domcontentloaded");
  }

  async openItemModule(): Promise<void> {
    await this.moduleIcon.click();
    await this.openMenu("Sales and marketing", "Setup", "Items", "Item list");
    await this.page.waitForLoadState("domcontentloaded");
  }

  // ───────────────────────── TOOLBAR ACTIONS ─────────────────────────

  async clickNew(): Promise<void> {
    await this.newButton.first().click();
    await this.page.waitForLoadState("domcontentloaded");
  }

  async clickOK(): Promise<void> {
    await this.okButton.click();
    await this.page.waitForLoadState("domcontentloaded");
  }

  async clickSave(): Promise<void> {
    await this.saveButton.click();
    await this.page.waitForLoadState("domcontentloaded");
  }

  // ────────────────────────── SALES ITEMS ──────────────────────────
  async selectSalesItem(value: string): Promise<void> {
    const description = this.textBox("Description");

    await description.waitFor({ state: "visible" });
    await description.click();
    await description.fill(value);
    await this.button("Item list generation").click();
    await this.page.waitForLoadState("domcontentloaded");
  }
  loader(loader: any) {
    throw new Error("Method not implemented.");
  }

  async fillminimumquantity(value: string): Promise<void> {
    await this.textBox("Minimum quantity").click();
    await this.textBox("Minimum quantity").fill(value);
    await this.page.waitForLoadState("domcontentloaded");
  }

  async fillvalue(value: string): Promise<void> {
    await this.textBox("Value").click();
    await this.textBox("Value").fill(value);
    await this.page.waitForLoadState("domcontentloaded");
  }

  async fillGenerationtype(value: string): Promise<void> {
    const comboBox = this.comboBox(`Generation type`);
    await comboBox.waitFor({ state: "visible" });
    await comboBox.click();
    await comboBox.fill(value);
    await this.page.waitForLoadState("domcontentloaded");
  }

  async addItems(value: string): Promise<void> {
    await this.button("Add").click();
    await this.comboBox("Item number").fill(value);
    await this.page.keyboard.press("Enter");
    await this.page.waitForLoadState("domcontentloaded");
  }

  async copyItemNumber(): Promise<string> {
    const locator = this.textBox("Item list");
    await locator.waitFor({ state: "visible" });
    const itemNumber = await locator.inputValue();
    console.log("Item Number from UI =", itemNumber);
    return itemNumber.trim();
  }

  async fillFilter(): Promise<string> {
    const itemNumber = await this.copyItemNumber();

    const filter = this.comboBox("Filter");
    await filter.click();
    await filter.fill(itemNumber);
    await filter.press("Enter");
    await this.page.waitForLoadState("domcontentloaded");

    return itemNumber;
  }

  // ───────────────────────── ASSERTIONS ─────────────────────────

  async assertItemLoaded(): Promise<void> {
    await this.page.waitForLoadState("networkidle");
  }
}
