import { Page, Locator, expect } from "@playwright/test";
import { ENV } from "../config/env.config";
import { PageUtil } from "../utils/page.util";

export class QuantityAdjustmentPage {

    constructor(private readonly page: Page) { }

    // ───────────────────────── URL ─────────────────────────

    private readonly D365_URL =
        "https://orkla-uat2.sandbox.operations.dynamics.com/?cmp=ov05&mi=DefaultDashboard";


    // ───────────────────────── SELECTORS ─────────────────────────

    private readonly SELECTORS = {

        // Navigation
        MODULE_ICON: ["#navPaneModuleID"],
        COLLAPSE_ALL: ['button.modulesFlyout-CollapseAll'],
        INVENTORY_MANAGEMENT: [
            'a.modulesPane-module[data-dyn-title="Inventory management"][role="treeitem"]',
            'a.modulesPane-module[data-dyn-title="Inventory management"]',
            'a[role="treeitem"][data-dyn-title="Inventory management"]',
            'a.modulesPane-module:has-text("Inventory management")',
            'a[role="treeitem"]:text-is("Inventory management")'
        ],
        INQUIRIES_AND_REPORTS: [
            'a[role="treeitem"][data-dyn-title="Inquiries and reports"]',
            'a.modulesFlyout-LinkGroup[aria-label="Inquiries and reports"]',
            'a[aria-label="Inquiries and reports"][role="treeitem"]',
            'a[role="treeitem"]:text-is("Inquiries and reports")'
        ],
        ON_HAND_LIST: [
            'div.modulesFlyout-link[aria-label="On-hand list"][role="link"]',
            'div[role="link"][aria-label="On-hand list"]',
            'a.modulesFlyout-linkText[data-dyn-title="On-hand list"]',
            'div.modulesFlyout-link:has(a[data-dyn-title="On-hand list"])'
        ],

        // Item filter
        ITEM_FILTER: [
            'input[id^="inventonhanditem_"][id$="_SystemDefinedFilterPane_FilterDisplay_InventSum_ItemId0_Input_0_0_input"]',
            'input[name="SystemDefinedFilterPane_FilterDisplay_InventSum_ItemId0_Input_0"]',
            'input[aria-label="Filter field: Item number, operator: begins with"]',
            'input[role="combobox"][aria-haspopup="grid"]'
        ],

        APPLY_BUTTON: [
            'button:has-text("Apply")',
            'button[id^="inventonhanditem_"][id$="_SystemDefinedFilterPane_FilterDisplay_ApplyFilters"]',
            'button[data-dyn-controlname="SystemDefinedFilterPane_FilterDisplay_ApplyFilters"]',
            'button[name="SystemDefinedFilterPane_FilterDisplay_ApplyFilters"]',
            'button:has(span.button-label:text-is("Apply"))'
        ],

        // Quantity adjustment
        QUANTITY_ADJUSTMENT_BUTTON: [
            'button:has-text("Quantity adjustment")',
            'button[name="WMSOnlineCounting"]',
            'button[data-dyn-controlname="WMSOnlineCounting"]',
            'button[id^="inventonhanditem_"][id$="_WMSOnlineCounting"]',
            'button:has(span.button-label:text-is("Quantity adjustment"))'
        ],

        NEW_BUTTON: [
            'button[id^="WMSOnlineCounting_"][id$="_NewButton"]',
            'button[data-dyn-controlname="NewButton"][command="New"]',
            'button[type="button"][data-dyn-controlname="NewButton"][command="New"][name="NewButton"]',
            'button[id$="_NewButton"]',
            'button:has(span.button-label:text-is("New"))'
        ],

        // Inventory dimensions
        SITE: [
            'input[id^="InventoryDimensionsGrid_InventSiteId_"][id$="_input"]',
            'input[type="text"][role="combobox"][aria-label="Site"][aria-haspopup="dialog"]',
            'input[role="combobox"][aria-label="Site"]'
        ],

        WAREHOUSE: [
            'input[id^="InventoryDimensionsGrid_InventLocationId_"][id$="_input"]',
            'input[role="combobox"][aria-label="Warehouse"]',
            'input[type="text"][role="combobox"][aria-label="Warehouse"][aria-haspopup="dialog"]'
        ],

        BATCH_NUMBER: [
            'input[id^="InventoryDimensionsGrid_inventBatchId_"][id$="_input"]',
            'input[role="combobox"][aria-label="Batch number"]',
            'input[type="text"][role="combobox"][aria-label="Batch number"][aria-haspopup="dialog"]'
        ],

        LOCATION: [
            'input[id^="InventoryDimensionsGrid_wMSLocationId_"][id$="_input"]',
            'input[role="combobox"][aria-label="Location"]',
            'input[type="text"][role="combobox"][aria-label="Location"][aria-haspopup="dialog"]'
        ],

        LICENSE_PLATE: [
            'input[id^="InventoryDimensionsGrid_LicensePlateId_"][id$="_input"]',
            'input[role="combobox"][aria-label="License plate"]',
            'input[type="text"][role="combobox"][aria-label="License plate"][aria-haspopup="dialog"]'
        ],

        QUANTITY: [
            'input[id^="TmpWMSOnlineCounting_qtyCounted_"][id$="_input"]',
            'input[role="textbox"][aria-label="Quantity"]'
        ],

        // Confirmation
        OK_BUTTON: [
            'button:has-text("OK")',
            'button[name="OK"]',
            'button[data-dyn-controlname="OK"][name="OK"]',
            'button[id^="WMSOnlineCounting_"][id$="_OK"]'
        ]
    };


    // ───────────────────────── LOCATOR GETTERS ─────────────────────────

    get moduleIcon(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, this.SELECTORS.MODULE_ICON);
    }
    get collapseAll(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.COLLAPSE_ALL,
        );
    }
    get inventoryManagement(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, this.SELECTORS.INVENTORY_MANAGEMENT);
    }
    get inquiriesAndReports(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.INQUIRIES_AND_REPORTS
        );
    }
    get onHandList(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, this.SELECTORS.ON_HAND_LIST);
    }

    get itemFilter(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, this.SELECTORS.ITEM_FILTER);
    }

    get applyButton(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, this.SELECTORS.APPLY_BUTTON);
    }

    get quantityAdjustmentButton(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, this.SELECTORS.QUANTITY_ADJUSTMENT_BUTTON);
    }

    get newButton(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, this.SELECTORS.NEW_BUTTON);
    }

    get site(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, this.SELECTORS.SITE);
    }

    get warehouse(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, this.SELECTORS.WAREHOUSE);
    }

    get batchNumber(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, this.SELECTORS.BATCH_NUMBER);
    }

    get location(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, this.SELECTORS.LOCATION);
    }

    get licensePlate(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, this.SELECTORS.LICENSE_PLATE);
    }

    get quantity(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, this.SELECTORS.QUANTITY);
    }

    get okButton(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, this.SELECTORS.OK_BUTTON);
    }


    // ───────────────────────── NAVIGATION METHODS ─────────────────────────

    async navigateToQuantityAdjustmentPage(): Promise<void> {
        await this.page.goto(ENV.DASHBOARD_URL);
        await this.page.waitForLoadState('domcontentloaded');

        await this.page.goto(this.D365_URL, {
            waitUntil: "domcontentloaded"
        });
    }

    async clickModuleIcon(): Promise<void> {
        await this.moduleIcon.waitFor({ state: "visible" });
        await this.moduleIcon.click();
        await this.page.waitForLoadState("domcontentloaded");
    }
    async clickCollapseAll(): Promise<void> {
        await this.collapseAll.waitFor({ state: "visible" });
        await this.collapseAll.click();
        await this.page.waitForLoadState('domcontentloaded');
    }
    async clickInventoryManagement(): Promise<void> {
        await this.inventoryManagement.waitFor({ state: "visible" });
        await this.inventoryManagement.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickOnHandList(): Promise<void> {
        await this.onHandList.waitFor({ state: "visible" });
        await this.onHandList.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickInquiriesAndReports(): Promise<void> {
        await this.inquiriesAndReports.waitFor({ state: "visible" });
        await this.inquiriesAndReports.click();
        await this.page.waitForLoadState("domcontentloaded");
    }
    // ───────────────────────── FILTER ITEM NUMBER ─────────────────────────

    async filterItemNumber(itemNumber: string): Promise<void> {
        await this.itemFilter.waitFor({ state: "visible" });
        await this.itemFilter.fill(itemNumber);
        await this.applyButton.waitFor({ state: "visible" });
        await this.applyButton.click();
        await this.page.waitForLoadState("domcontentloaded");
    }


    // ───────────────────────── QUANTITY ADJUSTMENT ─────────────────────────

    async clickQuantityAdjustment(): Promise<void> {
        await this.quantityAdjustmentButton.waitFor({ state: "visible" });
        await this.quantityAdjustmentButton.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickNew(): Promise<void> {
        await this.newButton.waitFor({ state: "visible" });
        await this.newButton.click();
        await this.page.waitForLoadState("domcontentloaded");
    }


    // ───────────────────────── FILL INVENTORY DIMENSIONS ─────────────────────────

    async enterSite(value: string): Promise<void> {
        await this.site.waitFor({ state: "visible" });
        await this.site.fill(value);
        await this.page.waitForLoadState("domcontentloaded");
    }

    async enterWarehouse(value: string): Promise<void> {
        await this.warehouse.waitFor({ state: "visible" });
        await this.warehouse.fill(value);
        await this.page.waitForLoadState("domcontentloaded");
    }

    async enterBatchNumber(value: string): Promise<void> {
        await this.batchNumber.waitFor({ state: "visible" });
        await this.batchNumber.fill(value);
        await this.page.waitForLoadState("domcontentloaded");
    }

    async enterLocation(value: string): Promise<void> {
        await this.location.waitFor({ state: "visible" });
        await this.location.fill(value);
        await this.page.waitForLoadState("domcontentloaded");
    }

    async enterLicensePlate(value: string): Promise<void> {
        await this.licensePlate.waitFor({ state: "visible" });
        await this.licensePlate.fill(value);
        await this.page.waitForLoadState("domcontentloaded");
    }

    async enterQuantity(value: string): Promise<void> {
        await this.quantity.waitFor({ state: "visible" });
        await this.quantity.fill(value);
        await this.page.waitForLoadState("domcontentloaded");
    }


    // ───────────────────────── SAVE QUANTITY ADJUSTMENT ─────────────────────────

    async clickOK(): Promise<void> {
        await this.okButton.waitFor({ state: "visible" });
        await this.okButton.click();
        await this.page.waitForLoadState("domcontentloaded");
    }
}