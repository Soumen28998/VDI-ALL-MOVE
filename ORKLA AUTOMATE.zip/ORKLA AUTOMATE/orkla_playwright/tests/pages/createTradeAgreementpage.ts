import { Page, Locator, expect } from "@playwright/test";
import { ENV } from "../config/env.config";
import { PageUtil } from "../utils/page.util";

export class createTradeAgreement {
    constructor(private readonly page: Page) { }

    // ────────────────────────────────────────────────────────────────
    // Selectors
    // ────────────────────────────────────────────────────────────────

    private readonly SELECTORS = {
        // Navigation
        MODULE_ICON: ["#navPaneModuleID"],

        // Toolbar
        NEW_BUTTON: [
            'button[id*="SystemDefinedNewButton"]',
            'button:has(span[id$="_SystemDefinedNewButton_label"])',
        ],
        SAVE_BUTTON: ['button:has-text("Save")'],
        OK_BUTTON: ['button:has-text("OK")'],
        BACK_BUTTON: ['button[aria-label="Back"]'],
        CLOSE_BUTTON: ['button:has-text("Close")'],
        LINE_BUTTON: ['button:has-text("Lines")'],
        POST_BUTTON: ['button:has-text("Post")'],
        APPLY_BUTTON: ['button:has-text("Apply")'],
        LOADER: ["#ShellBlockingDiv"],

        NAME_INPUT: ['input[id^="PriceDiscAdmTable_JournalName_"][id$="_input"]'],
        DESCRIPTION_INPUT: ['input[aria-label="Description"]'],
        PARTY_CODE_TYPE_INPUT: ['input[aria-label="Party code type"]'],
        ACCOUNT_SECTION: ['input[aria-label="Account selection"]'],
        RELATION: ['input[aria-label="Relation"]'],
        UNIT: ['input[aria-label="Unit"]'],
        ITEM_RELATION: ['input[aria-label="Item relation"]'],
        PRODUCT_CODE_TYPE_INPUT: ['input[aria-label="Product code type"]'],
        AMOUNT_IN_CURRENCY: ['input[aria-label="Amount in currency"]'],

        CURRENCY: ['input[aria-label="Currency"]'],
        DETAILS_TAB: ['button[aria-label="Details"]'],
        FROM_DATE: ['input[name="FromDate"]'],
        TO_DATE: ['input[name="ToDate"]'],
        DISCOUNT_PERCENTAGE_01: ['input[id*="Percent1_input"]'],
    };

    // ────────────────────────────────────────────────────────────────
    // Generic Locators
    // ────────────────────────────────────────────────────────────────

    private treeItem(name: string): Locator {
        return this.page.getByRole("treeitem", {
            name,
        });
    }

    private menuItem(name: string): Locator {
        return this.page.getByRole("link", {
            name,
            exact: true,
        });
    }

    private button(name: string): Locator {
        return this.page.getByRole("button", {
            name: new RegExp(name, "i"),
        });
    }

    private section(sectionName: string): Locator {
        return this.page.getByRole("button", {
            name: sectionName,
            exact: true,
        });
    }

    private menuLink(name: string): Locator {
        return this.page.getByRole("link", {
            name,
            exact: true,
        });
    }

    private async expandTreeItem(name: string, index: number = 0): Promise<void> {
        const item = this.treeItem(name).nth(index);

        await item.waitFor({
            state: "visible",
        });

        const expanded = await item.getAttribute("aria-expanded");

        if (expanded !== "true") {
            await item.click();
        }
    }

    // ────────────────────────────────────────────────────────────────
    // Common Getters
    // ────────────────────────────────────────────────────────────────

    get moduleIcon(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.MODULE_ICON,
        );
    }

    get newButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.NEW_BUTTON,
        );
    }

    get lineButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.LINE_BUTTON,
        );
    }

    get backButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.BACK_BUTTON,
        );
    }

    get unitInput(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, this.SELECTORS.UNIT);
    }

    get relationInput(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, this.SELECTORS.RELATION);
    }

    get postButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.POST_BUTTON,
        );
    }

    get applyButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.APPLY_BUTTON,
        );
    }

    get saveButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.SAVE_BUTTON,
        );
    }

    get nameInput(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.NAME_INPUT,
        );
    }

    get partycodeInput(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.PARTY_CODE_TYPE_INPUT,
        );
    }

    get accountSectionInput(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.ACCOUNT_SECTION,
        );
    }

    get itemRelationInput(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.ITEM_RELATION,
        );
    }

    get productCodeInput(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.PRODUCT_CODE_TYPE_INPUT,
        );
    }

    get amountInput(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.AMOUNT_IN_CURRENCY,
        );
    }

    get fromDateInput(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.FROM_DATE,
        );
    }

    get discountPercentage01Input(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.DISCOUNT_PERCENTAGE_01,
        );
    }

    get toDateInput(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, this.SELECTORS.TO_DATE);
    }

    get CurrencyInput(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, this.SELECTORS.CURRENCY);
    }

    get DetailsTab(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.DETAILS_TAB,
        );
    }

    get loader(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, this.SELECTORS.LOADER);
    }

    get okButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.OK_BUTTON,
        );
    }

    get closeButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.CLOSE_BUTTON,
        );
    }

    get descriptionInput(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.DESCRIPTION_INPUT,
        );
    }

    get waitForD365Loading(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, this.SELECTORS.LOADER);
    }

    // ────────────────────────────────────────────────────────────────
    // Navigation
    // ────────────────────────────────────────────────────────────────

    async navigateToCreateTradeAgreement(): Promise<void> {
        await this.page.goto(ENV.SBL_URL);
        await this.page.waitForLoadState("domcontentloaded");
    }


    async openMenu(module: string, parent: string, menu: string): Promise<void> {
        await this.expandTreeItem(module);
        await this.expandTreeItem(parent);
        const menuItem = this.menuLink(menu);
        await menuItem.waitFor({ state: "visible" });
        await menuItem.click();
        await PageUtil.waitForD365Loading(this.loader);
    }

    async openTradeAgreementModule(): Promise<void> {
        await this.moduleIcon.click();

        await this.openMenu(
            "Procurement and sourcing",
            "Prices and discounts",
            "Trade agreement journals",
        );

        await this.newButton.click();
    }

    // ────────────────────────────────────────────────────────────────
    // Toolbar
    // ────────────────────────────────────────────────────────────────

    async clickNew(): Promise<void> {
        await this.newButton.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickSave(): Promise<void> {
        await this.saveButton.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickOK(): Promise<void> {
        await this.okButton.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickClose(): Promise<void> {
        await this.closeButton.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickLine(): Promise<void> {
        await this.lineButton.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickPost(): Promise<void> {
        await this.postButton.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickApply(): Promise<void> {
        await this.applyButton.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickBack(): Promise<void> {
        await this.page.pause();
        await this.page.waitForLoadState("domcontentloaded");
        await this.backButton.click();
        //await this.page.keyboard.press('Escape');
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickDetailsTab(): Promise<void> {
        await this.page.waitForLoadState("domcontentloaded");
        await this.DetailsTab.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async expandSection(sectionName: string): Promise<void> {
        const section = this.section(sectionName);
        await section.waitFor({ state: "visible" });
        if ((await section.getAttribute("aria-expanded")) !== "true") {
            await section.click();
            await expect(section).toHaveAttribute("aria-expanded", "true");
            await this.page.waitForLoadState("domcontentloaded");
        }
        
    }
    //--------------------------------METHODS---------------------------------

    async fillnameInput(value: string) {
        await this.nameInput.click();
        await this.nameInput.fill(value);
        await this.page.waitForLoadState("domcontentloaded");
    }

    async filldescriptionInput(value: string) {
        await this.descriptionInput.click();
        await this.descriptionInput.fill(value);
        await this.page.waitForLoadState("domcontentloaded");
    }

    async fillRelationInput(value: string) {
        await this.relationInput.click();
        await this.relationInput.fill(value);
        await this.page.waitForLoadState("domcontentloaded");
    }

    async fillPartyCodeInput(value: string) {
        await this.partycodeInput.click();
        await this.partycodeInput.fill(value);
        await this.page.waitForLoadState("domcontentloaded");
    }

    async fillAccountInput(value: string) {
        await this.accountSectionInput.click();
        await this.accountSectionInput.fill(value);
        await this.page.waitForLoadState("domcontentloaded");
    }

    async fillUnitInput(value: string) {
        await this.unitInput.click();
        await this.unitInput.fill(value);
        await this.page.waitForLoadState("domcontentloaded");
    }

    async fillItemRelationInput(value: string) {
        await this.itemRelationInput.click();
        await this.itemRelationInput.fill(value);
        await this.page.waitForLoadState("domcontentloaded");
    }

    async fillProductCodeInput(value: string) {
        await this.productCodeInput.click();
        await this.productCodeInput.fill(value);
        await this.page.waitForLoadState("domcontentloaded");
    }

    async fillAmountInput(value: string) {
        await this.amountInput.click();
        await this.amountInput.fill(value);
        await this.page.waitForLoadState("domcontentloaded");
    }

    async fillCurrencyInput(value: string) {
        await this.CurrencyInput.click();
        await this.CurrencyInput.fill(value);
        await this.page.waitForLoadState("domcontentloaded");
    }

    async fillFromDateInput(value: string) {
        await this.fromDateInput.click();
        await this.fromDateInput.fill(value);
        await this.page.waitForLoadState("domcontentloaded");
    }

    async fillToDateInput(value: string) {
        await this.toDateInput.click();
        await this.toDateInput.fill(value);
        await this.page.waitForLoadState("domcontentloaded");
    }

    async fillDiscountPercentage01Input(value: string) {
        await this.discountPercentage01Input.click();
        await this.discountPercentage01Input.press('Control+A');
        await this.discountPercentage01Input.press('Delete');
        await this.discountPercentage01Input.pressSequentially(value);
        await this.page.waitForLoadState("domcontentloaded");
    }

    async confirmSalesOrder(): Promise<void> {
        // Click the main OK button
        await this.okButton.click();
        await this.page.waitForLoadState("domcontentloaded");

        // Handle confirmation popup if it appears
        const dialogOk = this.page
            .locator('[role="dialog"]')
            .getByRole("button", { name: /^OK$/ });

        if (await dialogOk.isVisible({ timeout: 5000 }).catch(() => false)) {
            await dialogOk.click();
            await this.page.waitForLoadState("domcontentloaded");
        }
    }

    // ───────────────────────── ASSERTIONS ─────────────────────────

    async assertProductLoaded(): Promise<void> {
        await this.page.waitForLoadState("networkidle");
    }
}
