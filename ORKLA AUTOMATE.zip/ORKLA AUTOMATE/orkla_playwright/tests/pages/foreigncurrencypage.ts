import { Page, Locator, expect } from "@playwright/test";
import { ENV } from "../config/env.config";
import { PageUtil } from "../utils/page.util";

export class ForeignCurrency {
    constructor(private readonly page: Page) { }

    // ─── Selectors ────────────────────────────────────────────────────────────────
    private readonly SELECTORS = {
        // Navigation
        MODULE_ICON: ["#navPaneModuleID"],

        // Toolbar
        FOREIGN_CURRENCY_REVALUATION: [
            'span.button-label[for$="_BankCurrencyReval"]'
        ],
        REVALUATION_DATE: [
            'input[name="TransDate"]'
        ],
        EXCHANGE_RATE_DATE: [
            'input[name="DateOfRate"]'
        ],
        NAME_COLUMN_HEADER: [
            '[data-dyn-columnname="BankAccountTable_Name"]'
        ],
        NAME_FILTER_INPUT: [
            'input[name="FilterField_BankAccountTable_Name_Name_Input_0"]'
        ],
        OK_BUTTON: ['button:has-text("OK")'],
        PROCESS_DATE_COLUMN_HEADER: [
            '[data-dyn-columnname="BankCurrencyRevalHistory_CreatedDateTime"]'
        ],
        PROCESS_DATE_FILTER: [
            'input[name="FilterField_BankCurrencyRevalHistory_CreatedDateTime_createdDateTime_Input_0"]'
        ],

        SORT_NEWEST_TO_OLDEST: [
            'span.button-label[for="__Descending_BankCurrencyRevalHistory_CreatedDateTime"]'
        ],

        // Loader
        LOADER: ["#ShellBlockingDiv"],
    };

    private treeItem(name: string): Locator {
        return this.page.getByRole("treeitem", {
            name,
            exact: true,
        });
    }

    private async expandTreeItem(name: string, index = 0): Promise<void> {
        const item = this.treeItem(name).nth(index);

        await item.waitFor({ state: "visible" });

        if ((await item.getAttribute("aria-expanded")) !== "true") {
            await item.click();
        }
    }

    private textBox(fieldName: string, description?: string): Locator {
        return this.page
            .getByRole("textbox", {
                name: fieldName,
                description,
                exact: true,
            })
            .last();
    }

    private button(buttonName: string): Locator {
        return this.page.getByRole("button", {
            name: new RegExp(buttonName, "i"),
        });
    }

    private option(optionName: string): Locator {
        return this.page.getByRole("option", {
            name: optionName,
            exact: true,
        });
    }

    private comboBox(fieldName: string): Locator {
        return this.page.getByRole("combobox", {
            name: fieldName,
            exact: true,
        });
    }

    private menuLink(name: string): Locator {
        return this.page.getByRole("link", {
            name,
            exact: true,
        });
    }


    // ───────────────────────── LOCATORS ─────────────────────────

    get moduleIcon(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.MODULE_ICON,
        );
    }

    get okButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.OK_BUTTON,
        );
    }

    get sortNewestToOldest(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.SORT_NEWEST_TO_OLDEST,
        );
    }

    get processDateFilter(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.PROCESS_DATE_FILTER,
        );
    }

    get processDateColumnHeader(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.PROCESS_DATE_COLUMN_HEADER,
        );
    }

    get foreignCurrencyRevaluationButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.FOREIGN_CURRENCY_REVALUATION,
        );
    }

    get revaluationDate(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.REVALUATION_DATE,
        );
    }

    get nameColumnHeader(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.NAME_COLUMN_HEADER,
        );
    }

    get nameFilterInput(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.NAME_FILTER_INPUT,
        );
    }

    get exchangeRateDate(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.EXCHANGE_RATE_DATE,
        );
    }

    get waitForD365Loading(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, ["#ShellBlockingDiv"]);
    }

    // ───────────────────────── NAVIGATION ─────────────────────────

    async openMenu(module: string, parent: string, menu: string): Promise<void> {
        // Expand main module
        await this.expandTreeItem(module);

        // Expand first matching parent
        await this.expandTreeItem(parent, 0);

        // Click menu
        const menuItem = this.menuLink(menu);

        await menuItem.waitFor({ state: "visible" });
        await this.page.waitForLoadState("domcontentloaded");
        await menuItem.click();

        await this.page.waitForLoadState("domcontentloaded");
    }

    async openForeignCurrencyModule(): Promise<void> {
        await this.moduleIcon.click();
        await this.page.waitForLoadState("domcontentloaded");
        await this.openMenu("Cash and bank management", "Periodic tasks", "Foreign currency revaluation");
        await this.page.waitForLoadState("domcontentloaded");
        await this.clickForeignCurrencyRevaluation();
    }

    // ───────────────────────── TOOLBAR ACTIONS ─────────────────────────

    async clickOK(): Promise<void> {
        await this.okButton.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickSortNewestToOldest(): Promise<void> {
        await this.sortNewestToOldest.click();
        await this.page.waitForLoadState("domcontentloaded");
        await this.button("Apply").click();
    }

    async clickForeignCurrencyRevaluation(): Promise<void> {
        await this.foreignCurrencyRevaluationButton.waitFor({ state: "visible" });
        await this.foreignCurrencyRevaluationButton.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickNameColumnHeader(): Promise<void> {
        await this.nameColumnHeader.waitFor({ state: "visible" });
        await this.nameColumnHeader.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickProcessDateColumnHeader(): Promise<void> {
        await this.processDateColumnHeader.waitFor({ state: "visible" });
        await this.processDateColumnHeader.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async fillRevaluationDate(value: string): Promise<void> {
        await this.revaluationDate.waitFor({ state: "visible", });
        await this.revaluationDate.click();
        await this.revaluationDate.fill(value);
        await this.revaluationDate.press("Tab");
        await this.page.waitForLoadState("domcontentloaded");
    }

    async fillExchangeRateDate(value: string): Promise<void> {
        await this.exchangeRateDate.waitFor({ state: "visible", });
        await this.exchangeRateDate.click();
        await this.exchangeRateDate.fill(value);
        await this.page.waitForLoadState("domcontentloaded");
    }

    async fillNameFilter(value: string): Promise<void> {
        await this.clickNameColumnHeader();
        await this.nameFilterInput.waitFor({ state: "visible", });
        await this.nameFilterInput.click();
        await this.nameFilterInput.fill(value);
        //await this.nameFilterInput.press("Tab");
        await this.page.waitForLoadState("domcontentloaded");
        await this.button("Apply").click();
        await this.page.waitForLoadState("domcontentloaded");
        await this.page.locator('input[aria-label="Name"][value="DNB Bank EUR"]').click();
        await this.page.waitForLoadState("domcontentloaded");
        await this.clickOK();
        await this.page.waitForLoadState("domcontentloaded");
    }
    // ───────────────────────── ASSERTIONS ─────────────────────────

    async assertItemLoaded(): Promise<void> {
        await this.page.waitForLoadState("networkidle");
    }
}
