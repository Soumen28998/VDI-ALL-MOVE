import { Page, Locator, expect } from "@playwright/test";
import { ENV } from "../config/env.config";
import { PageUtil } from "../utils/page.util";

export class SalesOrderPage {
  // Loader

  constructor(private readonly page: Page) { }

  // ─── Selectors ────────────────────────────────────────────────────────────────
  private readonly SELECTORS = {
    // Navigation
    MODULE_ICON: ["#navPaneModuleID"],

    // Toolbar
    NEW_BUTTON: [
      'button[id*="SystemDefinedNewButton"][command="New"]',
      'button:has(span[id$="_SystemDefinedNewButton_label"])',
    ],
    OK_BUTTON: ['button:has-text("OK")'],
    SAVE_BUTTON: ['button:has-text("Save")'],

    GENERAL_TAB: ['div[role="tab"]:has-text("General")'],
    LINE_TAB: ['div[role="tab"]:has-text("Line details")'],
    DELIVERY_DATE_CONTROLS: ['input[name="SalesTable_DeliveryDateControl"]'],
    DELIVERY_MODE: ['input[name="SalesTable_DlvMode"]'],
    DELIVERY_TERMS: ['input[name="DeliveryAddition_DlvTerm"]'],

    // Loader
    LOADER: ["#ShellBlockingDiv"],
  };

  private async clickModules(): Promise<void> {

    // Element that is visible only when the navigation pane is open
    const navigationPane = this.page.locator('[role="tree"]').first();

    // First attempt
    await this.moduleIcon.click();

    // Wait briefly to allow the pane to open
    await this.page.waitForTimeout(1000);

    // If the pane is still not open, try again
    if (!(await navigationPane.isVisible().catch(() => false))) {
      console.log("Navigation pane did not open. Retrying...");
      await this.moduleIcon.click();
    }

    await PageUtil.waitForD365Loading(this.waitForD365Loading);
  }

  private textBox(fieldName: string, description?: string): Locator {
    return this.page
      .getByRole("textbox", {
        name: fieldName,
        description,
        exact: true,
      })
      .last();
  }

  private button(buttonName: string): Locator {
    return this.page.getByRole("button", {
      name: new RegExp(buttonName, "i"),
    });
  }

  private option(optionName: string): Locator {
    return this.page.getByRole("option", {
      name: optionName,
      exact: true,
    });
  }

  private comboBox(fieldName: string): Locator {
    return this.page
      .getByRole("combobox", {
        name: fieldName,
        exact: true,
      })
      .last();
  }

  private treeItem(name: string): Locator {
    return this.page.getByRole("treeitem", {
      name,
      exact: true,
    });
  }

  private menuLink(name: string): Locator {
    return this.page.getByRole("link", {
      name,
      exact: true,
    });
  }

  private async expandTreeItem(name: string, index = 0): Promise<void> {
    const item = this.treeItem(name).nth(index);

    await item.waitFor({ state: "visible" });

    if ((await item.getAttribute("aria-expanded")) !== "true") {
      await item.click();
    }
  }

  async clickConfirmSalesOrderOK(): Promise<void> {
    const dialog = this.page.getByLabel("Confirm sales order");

    await dialog
      .getByRole("button", {
        name: "OK",
      })
      .click();

    await PageUtil.waitForD365Loading(this.waitForD365Loading);
  }

  async clickPostingConfirmationOK(): Promise<void> {
    const dialog = this.page.getByLabel(/You are about to post/i);

    await dialog
      .getByRole("button", {
        name: "OK",
      })
      .click();

    await PageUtil.waitForD365Loading(this.waitForD365Loading);
  }

  // ───────────────────────── LOCATORS ─────────────────────────

  get moduleIcon(): Locator {
    return PageUtil.getFirstMatchingLocator(
      this.page,
      this.SELECTORS.MODULE_ICON,
    );
  }


  get LineTab(): Locator {
    return PageUtil.getFirstMatchingLocator(this.page, this.SELECTORS.LINE_TAB);
  }

  get waitForD365Loading(): Locator {
    return PageUtil.getFirstMatchingLocator(this.page, ["#ShellBlockingDiv"]);
  }

  get saveButton(): Locator {
    return PageUtil.getFirstMatchingLocator(
      this.page,
      this.SELECTORS.SAVE_BUTTON,
    );
  }

  get deliveryDateControlsInput(): Locator {
    return PageUtil.getFirstMatchingLocator(
      this.page,
      this.SELECTORS.DELIVERY_DATE_CONTROLS,
    );
  }

  get deliveryModeInput(): Locator {
    return PageUtil.getFirstMatchingLocator(
      this.page,
      this.SELECTORS.DELIVERY_MODE,
    );
  }

  get deliveryTermsInput(): Locator {
    return PageUtil.getFirstMatchingLocator(
      this.page,
      this.SELECTORS.DELIVERY_TERMS,
    );
  }

  get generalTab(): Locator {
    return this.page
      .getByText("General", {
        exact: true,
      })
      .last();
  }

  get newButton(): Locator {
    return PageUtil.getFirstMatchingLocator(
      this.page,
      this.SELECTORS.NEW_BUTTON,
    );
  }

  get okButton(): Locator {
    return PageUtil.getFirstMatchingLocator(
      this.page,
      this.SELECTORS.OK_BUTTON,
    );
  }

  // ───────────────────────── NAVIGATION ─────────────────────────
  async navigateToSalesOrderPage(): Promise<void> {
    await this.page.goto(ENV.SBL_URL);
    await this.page.waitForLoadState("domcontentloaded");
  }

  async openMenu(module: string, parent: string, menu: string): Promise<void> {
    // Expand main module
    await this.expandTreeItem(module);

    // Expand first matching parent
    await this.expandTreeItem(parent, 0);

    // Click menu
    const menuItem = this.menuLink(menu);

    await menuItem.waitFor({ state: "visible" });
    await PageUtil.waitForD365Loading(this.waitForD365Loading);
    await menuItem.click();

    await PageUtil.waitForD365Loading(this.waitForD365Loading);
  }

  async openSalesOrderModule(): Promise<void> {
    await this.clickModules();

    await this.openMenu(
      "Sales and marketing",
      "Sales orders",
      "All sales orders",
    );

     await PageUtil.waitForD365Loading(this.waitForD365Loading);
  }

  // ───────────────────────── TOOLBAR ACTIONS ─────────────────────────

  async clickNew(): Promise<void> {
    await PageUtil.waitForD365Loading(this.waitForD365Loading);
    await this.newButton.first().click();
    await PageUtil.waitForD365Loading(this.waitForD365Loading);
    // await this.page.waitForSelector('#ShellBlockingDiv', { state: 'detached' });
  }

  async clickOK(): Promise<void> {
    //await this.okButton.click();
    await this.button("OK").click();
    await this.page.waitForLoadState("domcontentloaded");
    await PageUtil.waitForD365Loading(this.waitForD365Loading);
  }

  async clickCancel(): Promise<void> {
    //await this.button().click();
  }

  async clickSave(): Promise<void> {
    await this.saveButton.click();
    // await this.button('Save').click();
    //await this.page.getByRole('button', { name: ' Save' }).click();
    await PageUtil.waitForD365Loading(this.waitForD365Loading);
  }

  async clickGeneralTab(): Promise<void> {
    await this.generalTab.waitFor({ state: "visible" });
    //await this.generalTab.click();
    await PageUtil.waitForD365Loading(this.waitForD365Loading);
  }

  async clickIntercompanySalesOrder(): Promise<void> {
    await this.page.getByText("Manage", { exact: true }).click();
    await this.page
      .getByText("Intercompany sales order", {
        exact: true,
      })
      .click();
      
    await PageUtil.waitForD365Loading(this.waitForD365Loading);
  }

  // ────────────────────────── SALES ITEMS ──────────────────────────
  async fillCustomerAccount(value: string): Promise<void> {
    await PageUtil.waitForD365Loading(this.waitForD365Loading);
    const comboBox = this.comboBox(`Customer account`);
    await comboBox.waitFor({ state: "visible" });
    await comboBox.click();
    await comboBox.fill(value);
    await this.page.waitForLoadState("domcontentloaded");
  }

  async fillWarehouse(value: string): Promise<void> {
    const comboBox = this.comboBox("Warehouse");
    await comboBox.waitFor({ state: "visible" });
    await comboBox.dblclick();
    await comboBox.fill(value);
    await this.page.waitForLoadState("domcontentloaded");
  }

  async fillCustomerRequisition(value: string): Promise<void> {
    const textBox = this.textBox(`Customer requisition`);
    await textBox.waitFor({ state: "visible" });
    await textBox.click();
    await textBox.fill(value);
    await this.page.waitForLoadState("domcontentloaded");
  }

  async fillCustomerReference(value: string): Promise<void> {
    const textBox = this.textBox("Customer reference");
    await textBox.waitFor({ state: "visible" });
    await textBox.click();
    await textBox.fill(value);
    await this.page.waitForLoadState("domcontentloaded");
  }

  async fillSalesTaker(value: string): Promise<void> {
    const comboBox = this.comboBox("Sales taker");
    await comboBox.waitFor({ state: "visible" });
    await comboBox.click();
    await comboBox.fill(value);
    await this.page.keyboard.press("Enter");
    await PageUtil.waitForD365Loading(this.waitForD365Loading);
    await this.button("Select").click();
  }

  async filldeliveryDateControlsInput(value: string): Promise<void> {
    await this.deliveryDateControlsInput.click();
    await this.deliveryDateControlsInput.fill(value);
  }

  async filldeliveryModeInput(value: string): Promise<void> {
    await this.deliveryModeInput.click();
    await this.deliveryModeInput.fill(value);
  }

  async filldeliveryTermsInput(value: string): Promise<void> {
    await this.deliveryTermsInput.click();
    await this.deliveryTermsInput.fill(value);
  }

  async fillFilter(itemNumber: string): Promise<void> {
    const filter = this.comboBox("Filter");

    await filter.click();
    await filter.fill(itemNumber);
    await this.page.waitForTimeout(3000);
    await this.page.keyboard.press('Enter');
    await PageUtil.waitForD365Loading(this.waitForD365Loading);
  }

  async clickCopyAndClose(): Promise<void> {
    await this.button("Copy and close").dblclick();
    await PageUtil.waitForD365Loading(this.waitForD365Loading);
  }

  /*
  async clickOnLineDetails(value: string): Promise<void> {
   await this.button('Delivery').click();

   const comboBox = this.comboBox('Delivery type');
    await comboBox.waitFor({ state: 'visible' });
    await comboBox.click();
    await comboBox.fill(value);
    await this.page.keyboard.press('Enter');

    await PageUtil.waitForD365Loading(this.waitForD365Loading);
  }*/
  async updateConfirmedShipDateIfPopupAppears(): Promise<void> {
    const updateButton = this.page.getByRole("button", {
      name: "Update confirmed ship date",
      exact: true,
    });

    if (await updateButton.isVisible({ timeout: 3000 }).catch(() => false)) {
      await updateButton.click();

      await this.page.waitForLoadState("networkidle");

      console.log("Available Ship & Receipt Dates popup handled.");
    } else {
      console.log("Popup did not appear.");
    }
  }

  async selectDeliveryType(value: string): Promise<void> {
    // Expand/activate Line details
    const lineDetails = this.page.locator('button[aria-label="Line details"]');

    await lineDetails.waitFor({ state: "visible" });

    if ((await lineDetails.getAttribute("aria-expanded")) !== "true") {
      await lineDetails.click();
    }

    // Click Delivery tab under Line details
    const lineDetailsContainer = this.page.locator(
      '[id$="LineViewLineDetails_container"]',
    );

    await lineDetailsContainer
      .locator("span.pivot-label")
      .filter({ hasText: "Delivery" })
      .click();

    // Delivery Type under Line details only
    const deliveryType = lineDetailsContainer.getByRole("combobox", {
      name: "Delivery type",
      exact: true,
    });

    await deliveryType.waitFor({ state: "visible" });
    await deliveryType.click();

    // Select the option
    await this.page
      .getByRole("option", {
        name: value,
        exact: true,
      })
      .click();

    await PageUtil.waitForD365Loading(this.waitForD365Loading);
  }

  async clickCancelIfVisible(): Promise<void> {
    const cancelButton = this.page
      .getByRole("button", { name: "Cancel" })
      .filter({ visible: true });

    if (await cancelButton.count()) {
      await cancelButton.first().click();
      await PageUtil.waitForD365Loading(this.waitForD365Loading);
    }
  }

  async clickConfirmSalesOrder(): Promise<void> {
    await this.page.getByText("Sell", { exact: true }).last().click();
    await this.page
      .getByRole("button", { name: "Confirm sales order" })
      .click();
    await PageUtil.waitForD365Loading(this.waitForD365Loading);
  }

  async clickConfirmedShipDate(): Promise<void> {
    // Click Lines tab
    await this.page
      .getByRole("tab", {
        name: "Lines",
        exact: true,
      })
      .click();

    await PageUtil.waitForD365Loading(this.waitForD365Loading);

    // Click Confirmed ship date textbox
    const comboBox = this.comboBox("Confirmed ship date");
    await comboBox.waitFor({ state: "visible" });
    await comboBox.dblclick();
    await this.page.keyboard.press("Enter");
    await this.page.keyboard.press("Enter");
    await PageUtil.waitForD365Loading(this.waitForD365Loading);
  }

  async copySalesOrder(): Promise<string> {
    // Click Header tab
    const headerTab = this.page.getByRole("tab", {
      name: "Header",
      exact: true,
    });
    await headerTab.waitFor({ state: "visible" });
    await headerTab.click();
    await PageUtil.waitForD365Loading(this.waitForD365Loading);
    // Sales order textbox
    const salesOrder = this.page.locator(
      'input[id*="SalesTable_SalesId_input"]',
    );
    await salesOrder.waitFor({ state: "visible" });
    const value = await salesOrder.inputValue();
    console.log("Sales Order:", value);
    return value;
  }

  // ───────────────────────── ASSERTIONS ─────────────────────────

  async assertSalesOrderLoaded(): Promise<void> {
    await this.page.waitForLoadState("networkidle");
  }
}
