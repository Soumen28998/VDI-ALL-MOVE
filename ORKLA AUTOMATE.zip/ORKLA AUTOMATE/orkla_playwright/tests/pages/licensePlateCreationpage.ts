import { Page, Locator, expect } from "@playwright/test";
import { ENV } from "../config/env.config";
import { PageUtil } from "../utils/page.util";

export class CreateLicensePlatePage {
    constructor(private readonly page: Page) { }

    // ─── Selectors ────────────────────────────────────────────────────────────────

    private readonly SELECTORS = {
        // Navigation
        MODULE_ICON: ["#navPaneModuleID"],
        WAREHOUSE_MANAGEMENT: ['a[role="treeitem"][data-dyn-title="Warehouse management"]'],
        COLLAPSE_ALL: ['button.modulesFlyout-CollapseAll'],
        SETUP: ['a[role="treeitem"][data-dyn-title="Setup"]'],
        WAREHOUSE: ['a[role="treeitem"][data-dyn-title="Warehouse"]'],
        LICENSE_PLATES: ['a.modulesFlyout-linkText[data-dyn-title="License plates"]'],

        // Toolbar
        NEW_BUTTON: [
            'button[id*="SystemDefinedNewButton"][command="New"]',
            'button:has(span[id$="_SystemDefinedNewButton_label"])',
        ],
        SAVE_BUTTON: ['button:has-text("Save")'],

        // License Plate Input Field
        LICENSE_PLATE_INPUT: ['input[id^="WHSLicensePlate_LicensePlateId_"][id$="_input"]',
            'input[type="text"][role="textbox"][aria-label="License plate"]',
            'input.dyn-field[aria-label="License plate"]',
            'input[aria-label="License plate"][role="textbox"]'],

        // Loader
        LOADER: ["#ShellBlockingDiv"],
    };

    // ───────────────────────── LOCATORS ─────────────────────────

    get moduleIcon(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.MODULE_ICON,
        );
    }

    get warehouseManagement(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.WAREHOUSE_MANAGEMENT,
        );
    }

    get collapseAll(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.COLLAPSE_ALL,
        );
    }

    get setup(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.SETUP,
        );
    }

    get warehouse(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.WAREHOUSE,
        );
    }

    get licensePlates(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.LICENSE_PLATES,
        );
    }


    get licensePlateInput(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.LICENSE_PLATE_INPUT,
        );
    }

    get newButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.NEW_BUTTON,
        );
    }

    get saveButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.SAVE_BUTTON,
        );
    }

    get loader(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.LOADER,
        );
    }

    // ───────────────────────── NAVIGATION URL ─────────────────────────

    async navigateToLicensePlatePage(): Promise<void> {
        await this.page.goto(ENV.DASHBOARD_URL);
        await this.page.waitForLoadState('domcontentloaded');
    }

    // ───────────────────────── NAVIGATION ACTIONS ─────────────────────────

    async clickModuleIcon(): Promise<void> {
        await this.moduleIcon.waitFor({ state: "visible" });
        await this.moduleIcon.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickWarehouseManagement(): Promise<void> {
        await this.warehouseManagement.waitFor({ state: "visible" });
        await this.warehouseManagement.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickCollapseAll(): Promise<void> {
        await this.collapseAll.waitFor({ state: "visible" });
        await this.collapseAll.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickSetup(): Promise<void> {
        await this.setup.waitFor({ state: "visible" });
        await this.setup.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickWarehouse(): Promise<void> {
        await this.warehouse.waitFor({ state: "visible" });
        await this.warehouse.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickLicensePlates(): Promise<void> {
        await this.licensePlates.waitFor({ state: "visible" });
        await this.licensePlates.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    // ───────────────────────── TOOLBAR ACTIONS ─────────────────────────

    async clickNewButton(): Promise<void> {
        await this.newButton.waitFor({ state: "visible" });
        await this.newButton.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickSaveButton(): Promise<void> {
        await this.saveButton.waitFor({ state: "visible" });
        await this.saveButton.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    // ───────────────────────── FILL ACTIONS ─────────────────────────

    async fillLicensePlate(licensePlate: string): Promise<void> {
        await this.licensePlateInput.waitFor({ state: "visible" });
        await this.licensePlateInput.click();
        await this.licensePlateInput.fill(licensePlate);
        await this.page.waitForLoadState("domcontentloaded");
    }

    // ───────────────────────── ASSERTIONS ─────────────────────────

    async assertItemLoaded(): Promise<void> {
        await this.page.waitForLoadState("networkidle");
    }
}
