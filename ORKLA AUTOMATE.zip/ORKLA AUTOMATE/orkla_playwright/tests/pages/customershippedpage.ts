import { Page, Locator, expect } from "@playwright/test";
import { ENV } from "../config/env.config";
import { PageUtil } from "../utils/page.util";

export class CustomerShippedPage {
    constructor(private readonly page: Page) { }

    // ─── Selectors ────────────────────────────────────────────────────────────────
    private readonly SELECTORS = {
        // Navigation
        MODULE_ICON: ["#navPaneModuleID"],
        ACCOUNTS_RECEIVABLE: [
            'a[role="treeitem"][data-dyn-title="Accounts receivable"]'
        ],
        INQUIRIES_AND_REPORTS: [
            'a[role="treeitem"][data-dyn-title="Inquiries and reports"]'
        ],
        INVOICES_UNDER_INVOICE_RELATED: [
            'a[role="treeitem"][data-dyn-title="Invoices"][id*="InquiriesAndReports"][id*="InvoiceRelated"]'
        ],

        SHIPPED_NOT_INVOICED_REPORT: [
            'a.modulesFlyout-linkText[data-dyn-title="Shipped not invoiced report"]'
        ],

        // Toolbar
        NEW_BUTTON: [
            'button[id*="SystemDefinedNewButton"][command="New"]',
            'button:has(span[id$="_SystemDefinedNewButton_label"])',
        ],
        OK_BUTTON: ['button:has-text("OK")'],
        SAVE_BUTTON: ['button:has-text("Save")'],

        CUTOFF_DATE: ['input[name="Fld1_1"]'],
        DOWNLOAD_BUTTON: [
            'span[id$="_PdfViewerExportMenuButton_label"]',
        ],
        EXPORT_EXCEL_BUTTON: [
            'button[id$="PdfViewerExportToExcelButton"]'
        ],

        // Loader
        LOADER: ["#ShellBlockingDiv"],
    };


    private button(buttonName: string): Locator {
        return this.page.getByRole("button", {
            name: new RegExp(buttonName, "i"),
        });
    }

    private option(optionName: string): Locator {
        return this.page.getByRole("option", {
            name: optionName,
            exact: true,
        });
    }

    private comboBox(fieldName: string): Locator {
        return this.page.getByRole("combobox", {
            name: fieldName,
            exact: true,
        });
    }

    // ───────────────────────── LOCATORS ─────────────────────────

    get moduleIcon(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.MODULE_ICON,
        );
    }

    get accountsReceivable(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.ACCOUNTS_RECEIVABLE,
        );
    }

    get inquiriesAndReports(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.INQUIRIES_AND_REPORTS,
        );
    }

    get invoicesUnderInvoiceRelated(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.INVOICES_UNDER_INVOICE_RELATED,
        );
    }

    get shippedNotInvoicedReport(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.SHIPPED_NOT_INVOICED_REPORT,
        );
    }

    get exportExcelButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.EXPORT_EXCEL_BUTTON,
        );
    }

    get downloadButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.DOWNLOAD_BUTTON,
        );
    }

    get waitForD365Loading(): Locator {
        return PageUtil.getFirstMatchingLocator(this.page, ["#ShellBlockingDiv"]);
    }

    get saveButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.SAVE_BUTTON,
        );
    }

    get newButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.NEW_BUTTON,
        );
    }

    get okButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.OK_BUTTON,
        );
    }

    get cutoffDate(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.CUTOFF_DATE,
        );
    }

    // ───────────────────────── NAVIGATION ─────────────────────────

    async openCustomerShippedModule(): Promise<void> {
        await this.moduleIcon.click();
        await this.page.waitForLoadState("domcontentloaded");
        await this.accountsReceivable.click();
        await this.page.waitForLoadState("domcontentloaded");
        await this.inquiriesAndReports.dblclick();
        await this.page.waitForLoadState("domcontentloaded");
        await this.invoicesUnderInvoiceRelated.dblclick();
        await this.page.waitForLoadState("domcontentloaded");
        await this.shippedNotInvoicedReport.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    // ───────────────────────── TOOLBAR ACTIONS ─────────────────────────

    async clickOK(): Promise<void> {
        await this.okButton.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async clickDownloadButton(): Promise<void> {
        await this.page.waitForLoadState("domcontentloaded");
        await this.downloadButton.waitFor({ state: "visible", });
        await this.page.waitForLoadState("domcontentloaded");
        await this.downloadButton.click();
        await this.page.waitForLoadState("domcontentloaded");
        await this.exportExcelButton.click();
        await this.page.waitForLoadState("domcontentloaded");
    }

    async fillCutoffDate(value: string): Promise<void> {
        await this.cutoffDate.waitFor({ state: "visible", });
        await this.cutoffDate.click();
        await this.cutoffDate.fill(value);
        await this.cutoffDate.press("Tab");
        await this.page.waitForLoadState("domcontentloaded");
        await this.clickOK();
    }

    // ───────────────────────── ASSERTIONS ─────────────────────────

    async assertItemLoaded(): Promise<void> {
        await this.page.waitForLoadState("networkidle");
    }
}
