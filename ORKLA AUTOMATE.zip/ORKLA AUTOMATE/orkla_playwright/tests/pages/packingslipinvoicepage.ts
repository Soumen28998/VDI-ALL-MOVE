import { Page, Locator, expect } from "@playwright/test";
import { ENV } from "../config/env.config";
import { PageUtil } from "../utils/page.util";

export class packingInvoice {
  // Loader

  constructor(private readonly page: Page) { }

  // ─── Selectors ────────────────────────────────────────────────────────────────
  private readonly SELECTORS = {
    OK_BUTTON: ['button:has-text("OK")'],
    HEADER_TAB: ['li[role="tab"][data-dyn-mappedtab="HeaderView"]'],
    HEADER_SO: ['div[name="TabHeaderGeneral_SalesTable_SalesId"]'],
    INTERCOMPANY_SETTING_TAB: ['button[aria-label="Intercompany settings"]'],
    AUTOCREATE_INTERCOMPANY_ORDERS_BUTTON: [
      'span[role="switch"][id$="InterCompanyAutoCreateOrders_toggle"]',
    ],
    DIRECT_DELIVERY_BUTTON: [
      'span[role="switch"][id$="InterCompanyDirectDelivery_toggle"]',
    ],
    DELIVERY_TAB: ['button[aria-label="Delivery"]'],
    DELIVERY_DATE_CONTROL_LOOKUP_BUTTON: [
      'input[name="SalesTable_DeliveryDateControl"][role="combobox"]',
    ],
    LINE_TAB: ['li[role="tab"][data-dyn-mappedtab="LineView"]'],
    LINE_ORDER_ITEM_NUMBER: ['input[name="SalesLine_ItemId"][role="combobox"]'],
    LINE_ORDER_QUANTITY: ['input[aria-label="Quantity"][role="textbox"]'],
    LINE_ORDER_BATCH_NUMBER: [
      'input[aria-label="Batch number"][role="combobox"]',
    ],
    LINE_ORDER_UNIT_PRICE: ['input[aria-label="Unit price"][role="textbox"]'],
    ADD_LINES: ['span[id$="LineStripNew_label"]'],
    POST_PACKING_SLIP_BUTTON: [
      'button:has(span[id$="buttonUpdatePackingSlip_label"])',
    ],
    SPEC_QTY: ['input[name="specQty"][role="combobox"]'],
    INVOICE_BUTTON: ['button[id$="_Invoice_button"]'],
    SUB_INVOICE_BUTTON: ['button:has(span[id$="buttonUpdateInvoice_label"])'],
    INVOICE_QTY: ['input[name="specQty"][role="combobox"]'],
  };

  private textBox(fieldName: string, description?: string): Locator {
    return this.page
      .getByRole("textbox", {
        name: fieldName,
        description,
        exact: true,
      })
      .last();
  }

  private comboBox(fieldName: string): Locator {
    return this.page.getByRole("combobox", {
      name: fieldName,
      exact: true,
    });
  }

  private button(buttonName: string): Locator {
    return this.page.getByRole("button", {
      name: new RegExp(buttonName, "i"),
    });
  }

  // ─────────────────────────────────────────────
  // GETTERS
  // ─────────────────────────────────────────────

  get HeaderTab(): Locator {
    return PageUtil.getFirstMatchingLocator(
      this.page,
      this.SELECTORS.HEADER_TAB,
    );
  }

  get invoiceQtyInput(): Locator {
    return PageUtil.getFirstMatchingLocator(
      this.page,
      this.SELECTORS.INVOICE_QTY,
    );
  }

  get invoiceButton(): Locator {
    return PageUtil.getFirstMatchingLocator(
      this.page,
      this.SELECTORS.INVOICE_BUTTON,
    );
  }

  get subinvoiceButton(): Locator {
    return PageUtil.getFirstMatchingLocator(
      this.page,
      this.SELECTORS.SUB_INVOICE_BUTTON,
    );
  }

  get specQtyInput(): Locator {
    return PageUtil.getFirstMatchingLocator(this.page, this.SELECTORS.SPEC_QTY);
  }

  get okButton(): Locator {
    return PageUtil.getFirstMatchingLocator(
      this.page,
      this.SELECTORS.OK_BUTTON,
    );
  }

  get postPackingSlipButton(): Locator {
    return PageUtil.getFirstMatchingLocator(
      this.page,
      this.SELECTORS.POST_PACKING_SLIP_BUTTON,
    );
  }

  get addLineButton(): Locator {
    return PageUtil.getFirstMatchingLocator(
      this.page,
      this.SELECTORS.ADD_LINES,
    );
  }

  get HeaderSO(): Locator {
    return PageUtil.getFirstMatchingLocator(
      this.page,
      this.SELECTORS.HEADER_SO,
    );
  }

  get IntercompanySettingTab(): Locator {
    return PageUtil.getFirstMatchingLocator(
      this.page,
      this.SELECTORS.INTERCOMPANY_SETTING_TAB,
    );
  }

  get AutoCreateIntercompanyOrdersButton(): Locator {
    return PageUtil.getFirstMatchingLocator(
      this.page,
      this.SELECTORS.AUTOCREATE_INTERCOMPANY_ORDERS_BUTTON,
    );
  }

  get DirectDeliveryButton(): Locator {
    return PageUtil.getFirstMatchingLocator(
      this.page,
      this.SELECTORS.DIRECT_DELIVERY_BUTTON,
    );
  }

  get DeliveryTab(): Locator {
    return PageUtil.getFirstMatchingLocator(
      this.page,
      this.SELECTORS.DELIVERY_TAB,
    );
  }

  get DeliveryDateControlLookupButton(): Locator {
    return PageUtil.getFirstMatchingLocator(
      this.page,
      this.SELECTORS.DELIVERY_DATE_CONTROL_LOOKUP_BUTTON,
    );
  }

  get LineTab(): Locator {
    return PageUtil.getFirstMatchingLocator(this.page, this.SELECTORS.LINE_TAB);
  }

  get LineOrderItemNumber(): Locator {
    return PageUtil.getFirstMatchingLocator(
      this.page,
      this.SELECTORS.LINE_ORDER_ITEM_NUMBER,
    );
  }

  get LineOrderQuantity(): Locator {
    return PageUtil.getFirstMatchingLocator(
      this.page,
      this.SELECTORS.LINE_ORDER_QUANTITY,
    );
  }

  get LineOrderBatchNumber(): Locator {
    return PageUtil.getFirstMatchingLocator(
      this.page,
      this.SELECTORS.LINE_ORDER_BATCH_NUMBER,
    );
  }

  get LineOrderUnitPrice(): Locator {
    return PageUtil.getFirstMatchingLocator(
      this.page,
      this.SELECTORS.LINE_ORDER_UNIT_PRICE,
    );
  }

  async expandIfNotExpanded(locator: Locator): Promise<void> {
    await locator.waitFor({ state: "visible" });

    const expanded = await locator.getAttribute("aria-expanded");

    if (expanded !== "true") {
      await locator.click();

      await expect(locator).toHaveAttribute("aria-expanded", "true");
    }
  }

  //---------------------METHODS--------------------------------------
  async clickHeaderAndCopySO(): Promise<string> {
    await this.HeaderTab.waitFor({ state: "visible" });
    await this.HeaderTab.click();
    await expect(this.HeaderSO).not.toHaveText("", {
      timeout: 20000,
    });
    const salesOrderNumber = (
      await this.HeaderSO.innerText()
    ).trim();
    console.log("Sales Order Number:", salesOrderNumber);
    return salesOrderNumber;
  }

  async clickOK(): Promise<void> {
    //await this.okButton.click();
    await this.button("OK").click();
    await this.page.waitForLoadState("domcontentloaded");
  }

  async clickInvoicebutton(): Promise<void> {
    await this.invoiceButton.waitFor({
      state: "visible",
    });
    await this.invoiceButton.click();
  }

  async clickSubInvoice(): Promise<void> {
    await this.subinvoiceButton.waitFor({
      state: "visible",
    });
    await this.subinvoiceButton.click();
  }

  async expandIntercompanySettings(): Promise<void> {
    await this.expandIfNotExpanded(this.IntercompanySettingTab);
  }

  async clickIntercompanyOptions(): Promise<void> {
    await this.AutoCreateIntercompanyOrdersButton.waitFor({
      state: "visible",
    });
    await this.AutoCreateIntercompanyOrdersButton.click();

    await this.DirectDeliveryButton.waitFor({
      state: "visible",
    });
    await this.DirectDeliveryButton.click();
  }

  async expandDeliveryTab(): Promise<void> {
    await this.expandIfNotExpanded(this.DeliveryTab);
  }

  async fillDeliveryDateControl(value: string): Promise<void> {
    await this.DeliveryDateControlLookupButton.waitFor({
      state: "visible",
    });
    await this.DeliveryDateControlLookupButton.click();
    await this.DeliveryDateControlLookupButton.fill(value);
    await this.page.keyboard.press("Enter");
  }

  async clickLineTab(): Promise<void> {
    await this.LineTab.waitFor({ state: "visible" });
    await this.LineTab.click();
  }

  async clickAddLine(): Promise<void> {
    await this.addLineButton.waitFor({ state: "visible" });
    await this.addLineButton.click();
  }

  async addItems(value: string): Promise<void> {
    await this.clickAddLine();
    await this.comboBox("Item number").fill(value);
    await this.page.keyboard.press("Enter");
    await this.page.waitForLoadState("domcontentloaded");
  }

  async fillBatchNumber(value: string): Promise<void> {
    const comboBox = this.comboBox(`Batch number`);
    await comboBox.waitFor({ state: "visible" });
    await comboBox.click();
    await comboBox.fill(value);
    await this.page.waitForLoadState("domcontentloaded");
  }

  async fillQuantity(value: string): Promise<void> {
    const textBox = this.textBox(`Quantity`);
    await textBox.waitFor({ state: "visible" });
    await textBox.click();
    await textBox.fill(value);
    await this.page.waitForLoadState("domcontentloaded");
  }

  async fillUnitPrice(value: string): Promise<void> {
    const textBox = this.textBox(`Unit price`);
    await textBox.waitFor({ state: "visible" });
    await textBox.click();
    await textBox.fill(value);
    await this.page.waitForLoadState("domcontentloaded");
  }

  async clickPostPackingSlip(): Promise<void> {
    await this.postPackingSlipButton.waitFor({
      state: "visible",
    });
    await this.postPackingSlipButton.click();
  }

  async clickInvoicePopupOK(): Promise<void> {
    const popup = this.page.locator(".lightbox-container.active-form");

    const okButton = popup.getByRole("button", {
      name: "OK",
      exact: true,
    });
    await okButton.waitFor({
      state: "visible",
      timeout: 20000,
    });
    await expect(okButton).toBeEnabled();
    await okButton.click();
    console.log("Invoice confirmation OK clicked.");
  }

  async selectQuantityOption(optionValue: string): Promise<void> {
    const comboBox = this.page.getByRole("combobox", {
      name: "Quantity",
      exact: true,
    });

   await comboBox.waitFor({ state: "visible" });
    await comboBox.click();

    const option = this.page.getByRole("option", {
      name: optionValue,
      exact: true,
    });

    await option.waitFor({ state: "visible" });
    await option.click();
    await comboBox.press("Tab");
    await this.page.keyboard.press("Enter");
  }

  async handleyesPopup(): Promise<void> {
    try {
      const popup = this.page.locator('[role="dialog"]');

      await popup.waitFor({
        state: "visible",
        timeout: 20000,
      });

      await popup.getByRole("button", { name: /^Yes$/ }).click();

      console.log("Quantity Recommendation popup handled.");
    } catch {
      // Popup not displayed - continue normally
      console.log("Quantity Recommendation popup not displayed.");
    }
  }
  async clickPostConfirmationOK(): Promise<void> {
    const confirmationPopup = this.page.getByLabel("You are about to post the");

    await confirmationPopup.waitFor({
      state: "visible",
      timeout: 30000,
    });

    const okButton = confirmationPopup.getByRole("button", {
      name: "OK",
      exact: true,
    });

    await okButton.waitFor({
      state: "visible",
      timeout: 20000,
    });

    await expect(okButton).toBeEnabled();
    await okButton.click();
    console.log("Post confirmation OK clicked.");
  }
  
  async clickPickandPack(value: string): Promise<void> {
    await this.page.getByText("Pick and pack", { exact: true }).click();
    await this.clickPostPackingSlip();
    await this.page.waitForLoadState("domcontentloaded");
    await this.handleyesPopup();
    await this.selectQuantityOption(value);
    await this.page.waitForLoadState("domcontentloaded");
    await this.handleyesPopup();
    await this.clickPostConfirmationOK();
    await this.page.waitForLoadState("domcontentloaded");
  }

  async clickInvoice(value: string): Promise<void> {
    await this.clickInvoicebutton();
    await this.clickSubInvoice();
    await this.handleyesPopup();
    await this.selectQuantityOption(value);
    await this.page.waitForLoadState("domcontentloaded");
    await this.handleyesPopup();
    await this.clickPostConfirmationOK();
    await this.page.waitForLoadState("domcontentloaded");
  }

  // ───────────────────────── ASSERTIONS ─────────────────────────

  async assertSalesOrderLoaded(): Promise<void> {
    await this.page.waitForLoadState("networkidle");
  }
}
