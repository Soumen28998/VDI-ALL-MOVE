import { Page, Locator, expect } from "@playwright/test";
import { ENV } from "../config/env.config";
import { PageUtil } from "../utils/page.util";

export class CreateBatchNumberPage {
    constructor(private readonly page: Page) { }

    // ─── Selectors ────────────────────────────────────────────────────────────────

    private readonly SELECTORS = {
        // Navigation
        MODULE_ICON: ["#navPaneModuleID"],
        WAREHOUSE_MANAGEMENT: ['a[role="treeitem"][data-dyn-title="Warehouse management"]'],
        COLLAPSE_ALL: ['button.modulesFlyout-CollapseAll'],
        SETUP: ['a[role="treeitem"][data-dyn-title="Setup"]'],
        INVENTRY: ['a[role="treeitem"][aria-label="Inventory"][aria-expanded="false"]'],
        BATCHES: ['div[role="link"][aria-label="Batches"]'],

        // Toolbar
        NEW_BUTTON: [
            'button[id*="SystemDefinedNewButton"][command="New"]',
            'button:has(span[id$="_SystemDefinedNewButton_label"])',
        ],
        SAVE_BUTTON: ['button:has-text("Save")'],

        // Input Field
        ITEM_NUMBER_INPUT: [
            'input[id^="inventbatch_"][id$="_Header_ItemId_input"]',
            'input[type="text"][role="combobox"][aria-haspopup="grid"][aria-expanded="false"]',
        ],
        BATCH_NUMBER_INPUT: [
            'input[id^="inventbatch_"][id$="_Header_InventBatchId_input"]'],

        // Loader
        LOADER: ["#ShellBlockingDiv"],
    };

    // ───────────────────────── LOCATORS ─────────────────────────

    get moduleIcon(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.MODULE_ICON,
        );
    }

    get warehouseManagement(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.WAREHOUSE_MANAGEMENT,
        );
    }

    get collapseAll(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.COLLAPSE_ALL,
        );
    }

    get setup(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.SETUP,
        );
    }

    get inventory(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.INVENTRY,
        );
    }

    get batches(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.BATCHES,
        );
    }

    get newButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.NEW_BUTTON,
        );
    }

    get saveButton(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.SAVE_BUTTON,
        );
    }

    get itemNumberInput(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.ITEM_NUMBER_INPUT,
        );
    }

    get batchNumberInput(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.BATCH_NUMBER_INPUT,
        );
    }

    get loader(): Locator {
        return PageUtil.getFirstMatchingLocator(
            this.page,
            this.SELECTORS.LOADER,
        );
    }

    // ───────────────────────── NAVIGATION URL ─────────────────────────

    async navigateToBatchesPage(): Promise<void> {
        await this.page.goto(ENV.DASHBOARD_URL);
        await this.page.waitForLoadState('domcontentloaded');
    }

    // ───────────────────────── NAVIGATION ACTIONS ─────────────────────────

    async clickModuleIcon(): Promise<void> {
        await this.moduleIcon.waitFor({ state: "visible" });
        await this.moduleIcon.click();
        await this.page.waitForLoadState('domcontentloaded');
    }

    async clickWarehouseManagement(): Promise<void> {
        await this.warehouseManagement.waitFor({ state: "visible" });
        await this.warehouseManagement.click();
        await this.page.waitForLoadState('domcontentloaded');
    }

    async clickCollapseAll(): Promise<void> {
        await this.collapseAll.waitFor({ state: "visible" });
        await this.collapseAll.click();
        await this.page.waitForLoadState('domcontentloaded');
    }

    async clickSetup(): Promise<void> {
        await this.setup.waitFor({ state: "visible" });
        await this.setup.click();
        await this.page.waitForLoadState('domcontentloaded');
    }

    async clickInventory(): Promise<void> {
        await this.inventory.waitFor({ state: "visible" });
        await this.inventory.click();
        await this.page.waitForLoadState('domcontentloaded');
    }

    async clickBatches(): Promise<void> {
        await this.batches.waitFor({ state: "visible" });
        await this.batches.click();
        await this.page.waitForLoadState('domcontentloaded');
    }

    // ───────────────────────── TOOLBAR ACTIONS ─────────────────────────

    async clickNewButton(): Promise<void> {
        await this.newButton.waitFor({ state: "visible" });
        await this.newButton.click();
        await this.page.waitForLoadState('domcontentloaded');
    }

    async clickSaveButton(): Promise<void> {
        await this.saveButton.waitFor({ state: "visible" });
        await this.saveButton.click();
        await this.page.waitForLoadState('domcontentloaded');
    }

    // ───────────────────────── FILL ACTIONS ─────────────────────────

    async fillItemNumber(itemNumber: string): Promise<void> {
        await this.itemNumberInput.waitFor({ state: "visible" });
        await this.itemNumberInput.click();
        await this.itemNumberInput.fill(itemNumber);
        await this.page.waitForLoadState('domcontentloaded');
    }

    async fillBatchNumber(batchNumber: string): Promise<void> {
        await this.batchNumberInput.waitFor({ state: "visible" });
        await this.batchNumberInput.click();
        await this.batchNumberInput.fill(batchNumber);
        await this.page.waitForLoadState('domcontentloaded');
    }

    // ───────────────────────── ASSERTIONS ─────────────────────────

    async assertItemLoaded(): Promise<void> {
        await this.page.waitForLoadState("networkidle");
    }
}
