@CreateBatchNumber
Feature: Create a new Batch Number in Warehouse Management

  Scenario: Successfully create a new Batch Number
    When I navigate to Warehouse Management and open Batches
    And I click the New button on the Batche page
    And I enter the following value for creating new Batch Number

        | Field   | Value     |
        | Item number | <Item number> |
        | Batch number | <Batch number> |

    And I click to save the Batch Number


    Examples:
            | Item number | Batch number |
            | 117618      | BN_27112026  |

    #Give Batch number value as you prefered like BN_TodayDate

    
