@customershipped

Feature: Shipped Not Invoiced Report Export

  As a Dynamics 365 user
  I want to generate and export the Shipped Not Invoiced report
  So that I can download the report in Excel format

  Background:
    Given I navigate to the Orkla OV01 Dashboard

  Scenario Outline: Generate and download the Shipped Not Invoiced report

    When the user navigates to Accounts receivable Inquiries and reports Invoices Shipped not invoiced report

    And the user enters the cutoff date value
      | Field       | Value         |
      | Cutoff date | <Cutoff Date> |

    And the user clicks to Download Excel file

    Examples:
      | Cutoff Date   |
      |10/8/2026 |

