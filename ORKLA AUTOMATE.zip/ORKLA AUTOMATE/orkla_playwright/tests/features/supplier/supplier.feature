@supplier 
Feature: Create Suppliers in Orkla Operations
  As a procurement user
  I want to create new suppliers in the system
  So that I can manage vendor relationships and purchase orders

  Background:
    Given I navigate to the Orkla UAT2 supplier management page
    #And the page loads completely

  Scenario Outline: Create suppliers with different regions and configurations
    When I click the New button to create a new supplier
    And I fill in the General section with:
      | Field             | Value         |
      | Name              | <VendorName>  |
      | NameAlias         | <VendorName>  |
      | Group             | <VendorGroup> |
      | SalesTax_TaxGroup | <TaxGroup>    |

    
    Examples:
      | VendorName  | VendorGroup | TaxGroup | 

      | OV1EUSUP001 | 100         | UK_VEU   | 
