@itemlist
Feature: Create an Item list number

    As a Sales Management user
    I want to create new item lists in the system
    So that I can manage and release item lists 

    Background:
        Given I navigate to the Orkla BDL dashboard

    Scenario Outline: Create Item list number with different configurations

        And I click on Sales and Marketing and goto Item list and click on Item list
        Then I should be redirected to the Orkla UAT2 Item list page
        And the page loads completely

        When I click the New button to create a new item list   
        And I fill in the Description section with:
            | Field       | Value         |
            | Description | <Description> |

        Then I fill Generate item lists per customer with:
            | Field       | Value         |
            | Generation type   | <Generation type>    |
            | Minimum quantity   | <Minimum quantity>    |
            |Value | <Value> |
        
        And I click OK to generate the item list
        Then I click on Add button and I fill in the item number with:
            | Field       | Value         |
            | Item number | <Item number> |

        And Save Item list
        Then click on filter and search Item list
        And I copy the item number

         Examples:
         | Description | Generation type | Minimum quantity | Value | Item number |
         |Test          |Number of days  | 1               | 100    | 022112502000|
        

        