@CreateWorker
Feature: Create Worker in D365 Warehouse Management

  Scenario Outline: Create a new Worker user in NI01

    # Step 1: Navigate to D365 NI01 dashboard
    Given I navigate to D365 NI01 dashboard

    # Step 2: Open Modules
    When I click on Modules

    # Step 3: Select Warehouse management
    And I select Warehouse management

    # Step 4: Open Worker
    And I open Worker

    # Step 5: Filter Worker by name
    And I filter Worker by name "<Worker Name>"

    # Step 6: Select the matching Worker option
    And I select the Worker option "<Worker Name>"

    # Step 7: Click New
    And I click on New Worker

    # Step 8: Enter Worker user details
    And I enter Worker user details
      | Field              | Value                |
      | User ID            | <User ID>            |
      | User name          | <User Name>          |
      | Default warehouse  | <Default Warehouse>  |
      | Menu name          | <Menu Name>          |

    # Step 9: Save Worker details
    And I save Worker details

    # Step 10: Enter password and confirmation
    And I enter Worker password details
      | Field             | Value             |
      | Password          | <Password>        |
      | Confirm password  | <Confirm Password> |

    # Step 11: Set password
    And I click Set password

    Examples:
      | Worker Name | User ID   | User Name | Default Warehouse | Menu Name | Password | Confirm Password |
      | Satya Ch    | Testdemo | Testdemo | 1000              | Main Menu | 234      | 234              |