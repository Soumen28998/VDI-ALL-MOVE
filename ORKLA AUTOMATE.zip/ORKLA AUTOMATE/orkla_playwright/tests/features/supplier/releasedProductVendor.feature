
@ReleasedProductVendor
Feature: Add vendor to Released Product in D365

    Scenario Outline: Successfully add vendor to a released product

        # Step 1: Navigate to D365
        When I navigate to D365 and open Product information management

        # Step 2: Open Released products
        And I click Released products

        # Step 3: Filter product using Item number
        And I filter Released products using Item number "<Item number>"

        # Step 4: Open Setup
        And I click Setup

        # Step 5: Click Add
        And I click Add vendor record

        # Step 6: Enter Vendor
        And I enter Vendor "<Vendor>"

        # Step 7: Save
        And I click Save vendor record

        Examples:
            | Item number  | Vendor |
            | 084301391200 | 657000 |
