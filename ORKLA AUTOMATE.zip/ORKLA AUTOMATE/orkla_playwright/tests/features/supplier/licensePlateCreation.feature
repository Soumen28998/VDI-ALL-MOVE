@CreateLicensePlate
Feature: Create a new License Plate in Warehouse Management

  Scenario: Successfully create a new License Plate
    When I navigate to Warehouse Management and open License Plates
    And I click the New button on the License Plates page
    And I enter the License Plate value 

        | Field   | Value     |
        | License plate | <License plate> |

    And I click to save the License Plate


    Examples:
            | License plate | 
            |  LP_21112026  | 

    #Give License Plate value as you prefered like LP_TodayDate

    
