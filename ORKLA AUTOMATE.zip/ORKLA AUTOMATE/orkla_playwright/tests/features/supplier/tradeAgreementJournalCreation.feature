@Createtradeagreement
Feature: Create Trade Agreement

    As a Sales User
    I want to Create a Trade Agreement
    So that the order can be confirmed, picked, and posted successfully

    Background:
        Given I navigate to Account Receivable and open Trade Agreement Journal Page

    Scenario Outline: Create and Process Trade Agreement

       And I click the New button on the Trade Agreement Journal Page
        And I enter the following values to create new Trade Agreement 
            | Field       | Value         |
            | Name        | <Name>        |
            | Description | <Description> |

        And I save the Trade Agreement

        And I click on Line button
        And I fill Journal line with:
            | Field               | Value                |
            | Party Code Type     | <Party Code Type>    |
            | Account Section     | <Account Section>    |
            | Product Code Type   | <Product Code Type>  |
            | Item Relation       | <Item Relation>      |
            | Amount in Currency  | <Amount in Currency> |
            | Currency            | <Currency>           |
            | Price Identification| <Price Identification>|

        And I click on Details tab and fill with:
            | Field     | Value       |
            | From Date | <From Date> |
            | To Date   | <To Date>   |
            |Price Unit|<Price Unit>|

        And I click on Post button and then OK
        Then the Trade Agreement should be processed successfully

        Examples:
            | Name      | Description | Party Code Type | Account Section | Product Code Type | Item Relation | Amount in Currency | Currency |Price Identification| From Date  | To Date    |Price Unit|
            | Price_Sal | Price list sales | Table      | 1220            | Table             |  1000004      | 10                 | EUR      |CSP                 | 11/21/2026 | 11/22/2026 |    1     |

            #From Date = Today
            #To Date = Tommorow