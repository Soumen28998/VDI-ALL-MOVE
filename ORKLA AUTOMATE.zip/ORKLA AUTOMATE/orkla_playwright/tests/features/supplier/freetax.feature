@freeTextInvoice
Feature: Create and post a Free Text Invoice

    As an Accounts Receivable user
    I want to create and post a free text invoice
    So that the invoice is successfully posted and the generated invoice document can be accessed


    Background:
        Given I navigate to the Orkla OV01 Dashboard
        And I navigate to free text invoices section under invoice

    Scenario: Successfully create and post a Free Text Invoice

        When I enter the following Free Text Invoice details:
            | Field                | Value                  |
            | Customer account     | <Customer account>     |
            | Description          | <Description>          |
            | Item number          | <Item number>          |
            | Item sales tax group | <Item sales tax group> |
            | Unit price           | <Unit price>           |

        And I open the Line details tab

        And I enter the following financial dimension details:
            | Field                 | Value                   |
            | Operating unit number | <Operating unit number> |
            | Local cost center     | <Local cost center>     |
            | Local project         | <Local project>         |

        And I save Trade Agreement details
        And I click on  Post and OK button then Leasernet section
        And the user clicks on Download button and back

        Examples:
            | Customer account | Description | Item number | Item sales tax group | Unit price | Operating unit number | Local cost center | Local project |
            | C0002                    | Test            | 311002            | ZG                               | 100        | TW                                  | 290               | 400           |
