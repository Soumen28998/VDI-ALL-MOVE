@releasedproduct
Feature: Released Product Management

    As a Product Information Management user
    I want to create a Released Product for Consignment Replenishment
    So that the product can be used for purchasing and inventory transactions

    Background:
        Given I navigate to the Orkla USMF dashboard

    Scenario Outline: Create a Released Product

        When I click on Product information management and goto Released products
            | Module                                             | Parent    | Child             | Menu              |
            | Product information management | Products |                      | Released products |

        Then I should be redirected to the Released Products page
        And the Released Products page loads completely

        When I click the New button to create a Released Product

        And I fill in the Released Product details with:
            | Field                     | Value                     |
            | Product name              | <Product name>            |
            | Item model group          | <Item model group>        |
            | Item group                | <Item group>              |
            | Storage dimension group   | <Storage dimension group> |
            | Tracking dimension group  | <Tracking dimension group>|

        Then I click OK to create the Released Product

        When I open Manage costs

        And I open Item price

        And I click the New button to create an Item Price

        And I fill in the Item Price details with:
            | Field   | Value     |
            | Version | <Version> |
            | Site    | <Site>    |
            | Price   | <Price>   |

        Then I calculate the Item Cost

        And I fill in the Cost Calculation details with:
            | Field            | Value              |
            | Costing version  | <Costing version>  |
            | Site             | <Cost Site>        |

        Then I click OK to calculate Item Cost

        And I activate the pending prices

        And I close the Item Price page

        Then I verify the Released Product is created successfully

        Examples:
            | Product name               | Item model group | Item group | Storage dimension group | Tracking dimension group | Version | Site | Price | Costing version | Cost Site |
            | Consignment Product1       | FIFO              | EXP      | SiteWH                  | None                    | 10      | 1      | 150   | 10            | 1         |