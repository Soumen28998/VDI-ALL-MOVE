@tradeagreement
Feature: Trade Agreement Journal Management

    As a Procurement user
    I want to create a Trade Agreement Journal
    So that pricing agreements can be maintained

    Background:
        Given I navigate to the Orkla USMF dashboard

    Scenario Outline: Create Trade Agreement Journal

        When I click on Procurement and sourcing and goto Trade agreement journals
            | Module                   | Parent               | Child | Menu                     |
            | Procurement and sourcing | Prices and discounts |       | Trade agreement journals |

        Then I should be redirected to the Trade Agreement Journal page
        And the Trade Agreement Journal page loads completely

        When I click the New button to create a Trade Agreement Journal

        And I fill in the Trade Agreement Journal details with:
            | Field                         | Value                           |
            | Name                          | <Name>                          |
            | Price/discount journal number | <Price/discount journal number> |

        And I save the Trade Agreement Journal

        Then I verify the Trade Agreement Journal is created successfully

        Examples:
            | Name | Price/discount journal number |
            | Pric | PDJ-00718                     |