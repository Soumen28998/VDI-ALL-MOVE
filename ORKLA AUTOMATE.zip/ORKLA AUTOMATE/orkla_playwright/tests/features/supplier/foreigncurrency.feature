@foreignCurrencyRevaluation
Feature: Foreign Currency Revaluation

    Background:
        Given I navigate to the Orkla OV01 Dashboard

    Scenario: Successfully perform foreign currency revaluation

        When the user navigates to Foreign currency revaluation
        And the user fill dates and name and click on OK button
            | Field              | Value                |
            | Revaluation date   | <Revaluation date>   |
            | Exchange rate date | <Exchange rate date> |
            | Name               | <Name>               |

        Then click on Process date column header

  Examples:
            | Revaluation date | Exchange rate date     | Name    |
            | 11/19/2026       | 11/20/2026        | DNB Bank EUR  |

            #valid date required

