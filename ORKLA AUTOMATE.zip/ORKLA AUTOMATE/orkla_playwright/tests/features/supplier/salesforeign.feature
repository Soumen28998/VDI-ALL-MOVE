@salesforeigncurrency
Feature: Sales Foreign Currency Revaluation

    Background:
        Given I navigate to the Orkla OV01 Dashboard

    Scenario: Successfully perform sales foreign currency revaluation

        When the user navigates to sales Foreign currency revaluation
        And Click and Fill values 
         | Field                | Value                  |
         |Considered date|<Considered date>|
         |Date of rate|<Date of rate>|
         |Description|<Description>|
         |Notes|<Notes>|

         Then Click ok and validate all Popup

         Examples:
         | Considered date | Date of rate | Description | Notes | 
         |          10/8/2026    |    10/8/2026      | Test     | Test |
         