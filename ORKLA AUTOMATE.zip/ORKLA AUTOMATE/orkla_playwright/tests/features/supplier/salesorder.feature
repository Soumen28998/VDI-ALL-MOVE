@salesorder
Feature: Create a Sales Order for a Customer

    As a Sales Management user
    I want to create Sales Orders in the system
    So that I can manage and release sales orders for customers

    Background:
        Given I navigate to the Orkla BDL dashboard

    Scenario Outline: Create Sales Order for a Customer with different configurations
        And I click on Sales and Marketing and goto Item list and click on Item list
        Then I should be redirected to the Orkla UAT2 Item list page
        And the page loads completely

        When I click the New button to create a new item list
        And I fill in the Description section with:
            | Field       | Value         |
            | Description | <Description> |

        Then I fill Generate item lists per customer with:
            | Field            | Value              |
            | Generation type  | <Generation type>  |
            | Minimum quantity | <Minimum quantity> |
            | Value            | <Value>            |

        And I click OK to generate the item list
        Then I click on Add button and I fill in the item number with:
            | Field       | Value         |
            | Item number | <Item number> |

        And Save Item list
        Then click on filter and search Item list
        And I copy the item number

        And I click on Sales and Marketing and goto Sales Order and click on All Sales Orders
        Then I should be redirected to the Orkla UAT2 Sales Order page
        And the sales page loads completely
        When I click the New button to create a new sales order
        And I fill in the Create sales order section with:
            | Field                | Value                  |
            | Customer account     | <Customer account>     |
            | Warehouse            | <Warehouse>            |
            |Delivery date control|<Delivery date control>|
            |Mode of delivery|<Mode of delivery>|
            |Delivery terms|<Delivery terms>|
            | Customer requisition | <Customer requisition> |
            | Customer reference   | <Customer reference>   |
            | Sales taker          | <Sales taker>          |

        And I click OK to generate sales orders
        Then click on sales filter and search Item list

        And click on Copy and close
        And click on Line details and fill in the Delivery type with:
            | Field         | Value           |
            | Delivery type | <Delivery type> |

        Then Save Sales Order
        And  Click on Intercompany sales order under manage section
        And Click Heade and copy SNL_SO
        And Click Line and select Confirmed ship date
        And Click on cancel
        And Click on Confirm sales order
        And Click ok
        
        Examples:
            | Customer account | Warehouse| Delivery date control |Mode of delivery|Delivery terms| Customer requisition | Customer reference | Sales taker | Delivery type   | Description | Generation type | Minimum quantity | Value | Item number  |
            | 100732           | SBLADM01  |                      |                |              | PO1234               | PO1234             | Cust.Serv   | Direct delivery | Test        | Number of days  | 1                | 100   | 022112502000 |


