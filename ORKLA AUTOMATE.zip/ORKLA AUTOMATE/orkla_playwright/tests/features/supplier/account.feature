@customerAccountStatement
Feature: Customer Account Statement

    As a Dynamics 365 user
    I want to generate and download a customer account statement
    So that I can obtain the customer's statement for the required date range

    Background:
        Given I navigate to the Orkla OV01 Dashboard

    Scenario: Generate and download customer account statement for customer C0805

        When the user navigates to Accounts receivable Customers All customers
        And the user clicks the Account column header and fill
            | Field   | Value     |
            | Account | <Account> |
            
        And Click on Statement under Collect tab
        And the user selects the required date range
            | Field | Value  |
            | From  | <From> |
            | To    | <To>   |
        And the user clicks on Download button

        Examples:
            | Account | From     | To        |
            | C0805   | 11/20/2026 | 11/25/2026 |

#Change From & To Date