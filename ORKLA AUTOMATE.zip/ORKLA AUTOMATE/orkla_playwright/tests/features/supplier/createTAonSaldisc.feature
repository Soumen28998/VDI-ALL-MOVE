@sbl02
Feature: Create Trade Agreements on Saldisc

    As a Sales User
    I want to Creating a Trade Agreement on Saldisc
    So that the order can be confirmed, picked, and posted successfully

    Background:
        Given I navigate to the Orkla Trade Agreement(SBL_02) dashboard

    Scenario Outline: Create and Process Trade Agreement

        When I open Trade Agreement page
        And I create new Trade Agreement and save
            | Field       | Value         |
            | Name        | <Name>        |
            | Description | <Description> |

        And I click on Lines button
        And I fill Journal line Trade Agreement with
            | Field              | Value                |
            | Relation |<Relation>|
            | Party Code Type    | <Party Code Type>    |
            | Account Section    | <Account Section>    |
            | Product Code Type  | <Product Code Type>  |
            | Item Relation      | <Item Relation>      |
            | Unit | <Unit> |
            | Amount in Currency | <Amount in Currency> |
            | Currency           | <Currency>           |

        And I click on Details tab and fill with
            | Field     | Value       |
            | From Date | <From Date> |
            | To Date   | <To Date>   |
            |Discount percentage 1 | <Discount percentage 1> |

        And I save Trade Agreement details
        And I click on Post and OK button
        And I click on Back button
        And The Trade Agreement should be processed successfully
        

        Examples:
            | Name      | Description                       |Relation         |Party Code Type | Account Section | Product Code Type | Item Relation    | Unit | Amount in Currency | Currency      | From Date    | To Date | Discount percentage 1 |
            | SalDisc   | Sales line discount 2hy 2024 | Line discount (Sales)  |Group                  | 01             | Table                      | 035511702000  |     |                            |       EUR       | 10/28/2024 | 12/31/2024 | 15 |