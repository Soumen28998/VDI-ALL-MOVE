@QuantityAdjustment
Feature: Perform Quantity Adjustment in D365 Warehouse Management

    Scenario Outline: Successfully adjust inventory quantity from On-hand list

        # Step 1: Navigate to D365 OV05
        When I navigate to D365 OV05 and open On-hand list

        # Step 2: Filter item number
        And I filter the On-hand list using Item number "<Item number>"

        # Step 3: Open Quantity adjustment
        And I click Quantity adjustment

        # Step 4: Create new quantity adjustment
        And I click New on Quantity adjustment

        # Step 5: Enter inventory dimensions and quantity
        And I enter the following inventory adjustment details
            | Field         | Value             |
            | Site          | <Site>            |
            | Warehouse     | <Warehouse>       |
            | Batch number  | <Batch number>    |
            | Location      | <Location>        |
            | License plate | <License plate>   |
            | Quantity      | <Quantity>        |

        # Step 6: Confirm adjustment
        And I click OK to save the Quantity adjustment

        Examples:
            | Item number | Site | Warehouse | Batch number | Location   | License plate    | Quantity |
            | 54502       |      |           | WO003334     | Opalion 1  | 050602349800003994 | 100      |