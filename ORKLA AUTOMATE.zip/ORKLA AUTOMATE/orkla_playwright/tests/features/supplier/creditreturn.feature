@sbl10
Feature: Create a Packing Slip and Create an Invoice

    As a Sales Management User
    I want to create a sales order, post a packing slip, and generate an invoice
    So that the sales order is completed successfully

    Background:
        Given I navigate to the Orkla BDL dashboard

    Scenario Outline: Create Packing Slip and Invoice for a Customer
        And I click on Sales and Marketing and goto Item list and click on Item list
        Then I should be redirected to the Orkla UAT2 Item list page
        And the page loads completely

        When I click the New button to create a new item list
        And I fill in the Description section with:
            | Field       | Value         |
            | Description | <Description> |

        Then I fill Generate item lists per customer with:
            | Field            | Value              |
            | Generation type  | <Generation type>  |
            | Minimum quantity | <Minimum quantity> |
            | Value            | <Value>            |

        And I click OK to generate the item list
        Then I click on Add button and I fill in the item number with:
            | Field       | Value         |
            | Item number | <Item number> |

        And Save Item list
        Then click on filter and search Item list
        And I copy the item number

        And I click on Sales and Marketing and goto Sales Order and click on All Sales Orders
        Then I should be redirected to the Orkla UAT2 Sales Order page
        And the sales page loads completely
        When I click the New button to create a new sales order
        And I fill in the Create sales order section with:
            | Field                 | Value                   |
            | Customer account      | <Customer account>      |
            | Warehouse             | <Warehouse>             |
            | Delivery date control | <Delivery date control> |
            | Mode of delivery      | <Mode of delivery>      |
            | Delivery terms        | <Delivery terms>        |
            | Customer requisition  | <Customer requisition>  |
            | Customer reference    | <Customer reference>    |
            | Sales taker           | <Sales taker>           |

        And I click OK to generate sales orders
        Then click on sales filter and search Item list

        And click on Copy and close
        And Click Header and copy HEADER_SO
        And Expand Intercompany settings
        And Disable Auto-create intercompany orders and Direct delivery
        
        Then Expand Delivery section
        And  Select Delivery date control lookup with:
            | Field                 | Value                   |
            | Delivery date control lookup | <Delivery date control lookup> |

        And I click on Lines
        And I fill Sales Order line with:
            | Field       | Value          |
            | Item number | <Item number>  |
            | Quantity    | <Quantity>     |
            | Batch number| <Batch number> |
            | Unit price  | <Unit price>   |

        Then Save Sales Order
        And Click on Confirm sales order
        And Click ok
         And Click on Pick Pack button and fill with:
            | Field    | Value      |
            | Post Quantity | <Post Quantity> |

        Then Packing Slip should be posted successfully

        And Click Invoice and fill with:
            | Field    | Value      |
            | Invoice Quantity | <Invoice Quantity> |

        Then Invoice should be posted successfully

        And I click on Back button
      

        Examples:
            | Customer account | Warehouse | Delivery date control | Mode of delivery | Delivery terms | Customer requisition | Customer reference | Sales taker | Item number    | Quantity | Batch number | Unit price | Quantity Type | Description | Generation type | Minimum quantity | Value |Delivery date control lookup|Post Quantity | Invoice Quantity|
            | 101810                   | SBLADM01  | None                          | Road                    | FCA                  | PO1234                       | PO1234                     | Cust.Serv   | 022334702000 | 12            | P363004         | 45             | All                    | Test             | Number of days  | 1                            | 100    | None                                    |All                   |All          |