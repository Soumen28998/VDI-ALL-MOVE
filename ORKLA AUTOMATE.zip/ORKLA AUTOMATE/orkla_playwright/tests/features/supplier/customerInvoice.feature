@customer-invoicing-eu

Feature: EU Customer Invoicing

  As a Finance and Operations user
  I want to invoice shipped but not invoiced EU sales orders
  So that the customer invoice is created and the invoice document can be previewed and downloaded

  Background:
    Given I navigate to the Orkla OV01 Dashboard

  Scenario: Invoice an EU sales order from Shipped but not invoiced sales orders

    When the user navigates to Customer invoicing
    And the user clicks on Shipped but not invoiced sales orders

    And the user click and filters the Sales order column with: 
      | Field       | Value         |
      | Sales order | <Sales order> |

    And the user selects the required sales order
    And the user clicks Invoice
    And click on the Invoice journal button
    Then the user should be able to download the invoice document in PDF format

Examples:
         | Sales order | 
         | ov05S00006752 | 
         #This value need to change every time when run this code; otherwise it will failed; 123,124,122,126,127