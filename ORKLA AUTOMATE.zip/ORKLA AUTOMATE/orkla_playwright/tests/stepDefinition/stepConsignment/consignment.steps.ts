import { When, Then } from '@cucumber/cucumber';
import { ReleasedProductPage } from '../../pages/consignmentpage';

let releasedProductPage: ReleasedProductPage;

// ───────────────────────── NAVIGATION ─────────────────────────

When('I navigate to the Orkla USMF dashboard', async function () {
  releasedProductPage = new ReleasedProductPage(this.page!);
  await releasedProductPage.navigateToReleasedProductPage();
});


When(
  'I click on Product information management and goto Released products',
  async function (dataTable) {

    const data = dataTable.hashes()[0];

    await releasedProductPage.openMenu(
      data.Module,
      data.Parent,
      data.Child,
      data.Menu
    );
  }
);

Then(
  'I should be redirected to the Released Products page',
  async function () {

    await releasedProductPage.assertReleasedProductLoaded();
  }
);

Then(
  'the Released Products page loads completely',
  async function () {

    await releasedProductPage.assertReleasedProductLoaded();
  }
);

// ───────────────────────── TOOLBAR ─────────────────────────

When(
  'I click the New button to create a Released Product',
  async function () {

    await releasedProductPage.clickNew();
  }
);

Then(
  'I click OK to create the Released Product',
  async function () {

    await releasedProductPage.clickOK();
  }
);

// ───────────────────────── RELEASED PRODUCT DETAILS ─────────────────────────

When(
  'I fill in the Released Product details with:',
  async function (dataTable) {

    const data = dataTable.rowsHash();

    await releasedProductPage.fillReleasedProductDetails(
      data['Product name'],
      data['Item model group'],
      data['Item group'],
      data['Storage dimension group'],
      data['Tracking dimension group']
    );
  }
);

// ───────────────────────── MANAGE COSTS ─────────────────────────

When(
  'I open Manage costs',
  async function () {

    await releasedProductPage.openManageCosts();
  }
);

When(
  'I open Item price',
  async function () {

    await releasedProductPage.openItemPrice();
  }
);

// ───────────────────────── ITEM PRICE ─────────────────────────

When(
  'I click the New button to create an Item Price',
  async function () {

    await releasedProductPage.clickNew();
  }
);

When(
  'I fill in the Item Price details with:',
  async function (dataTable) {

    const data = dataTable.rowsHash();

    await releasedProductPage.fillItemPriceDetails(
      data['Version'],
      data['Site'],
      data['Price']
    );
  }
);

// ───────────────────────── COST CALCULATION ─────────────────────────

Then(
  'I calculate the Item Cost',
  async function () {

    await releasedProductPage.clickCalculateItemCost();
  }
);

When(
  'I fill in the Cost Calculation details with:',
  async function (dataTable) {

    const data = dataTable.rowsHash();

    await releasedProductPage.fillCostCalculationDetails(
      data['Costing version'],
      data['Site']
    );
  }
);

Then(
  'I click OK to calculate Item Cost',
  async function () {

    await releasedProductPage.clickOK();
  }
);

// ───────────────────────── FINAL ACTIONS ─────────────────────────

Then(
  'I activate the pending prices',
  async function () {

    await releasedProductPage.activatePendingPrices();
  }
);

Then(
  'I close the Item Price page',
  async function () {

    await releasedProductPage.clickClose();
  }
);

// ───────────────────────── ASSERTIONS ─────────────────────────

Then(
  'I verify the Released Product is created successfully',
  async function () {

    await releasedProductPage.verifyReleasedProductCreated();
  }
);