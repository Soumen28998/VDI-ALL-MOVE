import { Given, When, Then } from '@cucumber/cucumber';
import { OrklaWorld } from '../../support/world';
import { ENV } from '../../config/env.config';
import { SupplierPage } from '../../pages/supplierPage';
import { RuntimeDataStore } from '../../utils/runtime-data.util';
import { Logger } from '../../utils/logger.util';
import { DataTable } from '@cucumber/cucumber';
import { DynamicsUtil } from '@utils/dynamics.util';

// ─── Helper: build a SupplierPage from the World's live page ─────────────────
const sp = (world: OrklaWorld): SupplierPage => new SupplierPage(world.page);


Given<OrklaWorld>('I navigate to the Orkla UAT2 supplier management page', async function () {
  await sp(this).navigateToSupplierList();
});

/*Given<OrklaWorld>('the page loads completely', async function () {
  Logger.step('Waiting for page to fully load via XRM_Client_API_Dynamic');

  await DynamicsUtil.waitForPageLoad(this.page, {
    timeout: ENV.PAGE_LOAD_TIMEOUT,
    waitForCommandBar: true,
    waitForFastTabs: false,  // list pages have no FastTabs
  });
  Logger.success('Page fully loaded');
});*/


When<OrklaWorld>('I click the New button to create a new supplier', async function () {
  await sp(this).clickNew();
  await sp(this).waitForGeneralSection();
  await sp(this).waitForIdentificationHeading();
});

Then<OrklaWorld>('I fill in the General section with:', async function (dataTable: DataTable) {
  const data = dataTable.rowsHash();
  const vendorName = data['Name'] + Math.floor(Math.random() * 10000).toString().padStart(3, '0');
  Logger.info(`Filling General section for vendor: ${vendorName}`);

  await sp(this).fillName(vendorName);
  await sp(this).fillNameAlias(data['NameAlias']);
  await sp(this).selectVendorGroup(data['Group']);
  await sp(this).selectTaxGroup(data['SalesTax_TaxGroup']);
  Logger.success('General section filled');

});

