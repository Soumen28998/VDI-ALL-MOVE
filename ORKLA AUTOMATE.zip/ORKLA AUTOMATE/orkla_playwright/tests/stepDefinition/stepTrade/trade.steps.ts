import { When, Then } from '@cucumber/cucumber';
import { TradeAgreementPage } from '../../pages/tradepage';

let tradeAgreementPage: TradeAgreementPage;

// ───────────────────────── NAVIGATION ─────────────────────────

When(
  'I click on Procurement and sourcing and goto Trade agreement journals',
  async function (dataTable) {

    tradeAgreementPage = new TradeAgreementPage(this.page!);

    const data = dataTable.hashes()[0];

    await tradeAgreementPage.openMenu(
      data.Module,
      data.Parent,
      data.Child,
      data.Menu
    );
  }
);

Then(
  'I should be redirected to the Trade Agreement Journal page',
  async function () {

    await tradeAgreementPage.assertTradeAgreementLoaded();
  }
);

Then(
  'the Trade Agreement Journal page loads completely',
  async function () {

    await tradeAgreementPage.assertTradeAgreementLoaded();
  }
);

// ───────────────────────── TOOLBAR ─────────────────────────

When(
  'I click the New button to create a Trade Agreement Journal',
  async function () {

    await tradeAgreementPage.clickNew();
  }
);

// ───────────────────────── TRADE AGREEMENT DETAILS ─────────────────────────

When(
  'I fill in the Trade Agreement Journal details with:',
  async function (dataTable) {

    const data = dataTable.rowsHash();

    await tradeAgreementPage.fillTradeAgreementDetails(
      data['Name'],
      data['Price/discount journal number']
    );
  }
);

// ───────────────────────── ACTIONS ─────────────────────────

Then(
  'I click OK to create the Trade Agreement Journal',
  async function () {

    await tradeAgreementPage.clickOK();
  }
);

Then(
  'I save the Trade Agreement Journal',
  async function () {

    await tradeAgreementPage.clickSave();
  }
);

// ───────────────────────── ASSERTIONS ─────────────────────────

Then(
  'I verify the Trade Agreement Journal is created successfully',
  async function () {

    await tradeAgreementPage.verifyTradeAgreementCreated();
  }
);