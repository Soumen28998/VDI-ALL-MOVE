import { When, Then } from "@cucumber/cucumber";
import { expect } from "@playwright/test";
import { CreateLicensePlatePage } from "../../pages/licensePlateCreationpage";

let createLicensePlatePage: CreateLicensePlatePage;

// ───────────────────────── NAVIGATION ─────────────────────────

When(
    "I navigate to Warehouse Management and open License Plates",
    async function () {
        createLicensePlatePage = new CreateLicensePlatePage(this.page);

        await createLicensePlatePage.navigateToLicensePlatePage();
        await createLicensePlatePage.clickModuleIcon();
        await createLicensePlatePage.clickWarehouseManagement();
        await createLicensePlatePage.clickCollapseAll();
        await createLicensePlatePage.clickSetup();
        await createLicensePlatePage.clickWarehouse();
        await createLicensePlatePage.clickLicensePlates();
    }
);


// ───────────────────────── CREATE NEW LICENSE PLATE ─────────────────────

When(
    "I click the New button on the License Plates page",
    async function () {
        await createLicensePlatePage.clickNewButton();
    }
);

When(
    "I enter the License Plate value",
    async function (dataTable) {
        const data = dataTable.rowsHash();
        await createLicensePlatePage.fillLicensePlate(data["License plate"]);
    }
);

When(
    "I click to save the License Plate",
    async function () {
        await createLicensePlatePage.clickSaveButton();
    }
);


