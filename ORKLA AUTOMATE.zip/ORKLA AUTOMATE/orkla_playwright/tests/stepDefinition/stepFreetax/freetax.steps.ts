import { When, Then } from "@cucumber/cucumber";
import { expect } from "@playwright/test";
import { FreeTaxPage } from "../../pages/freetaxpage";

let freetaxpage: FreeTaxPage;

When("I navigate to free text invoices section under invoice", async function () {
    freetaxpage = new FreeTaxPage(this.page);
    await freetaxpage.openFreeTaxModule();
});

Then(
    "I enter the following Free Text Invoice details:",
    async function (dataTable) {
        const data = dataTable.rowsHash();
        await freetaxpage.fillOrderAccountInput(data["Customer account"]);
        await freetaxpage.filldescriptionInput(data["Description"]);
        await freetaxpage.fillledgerAccountInput(data["Item number"]);
        await freetaxpage.filltaxItemGroupInput(data["Item sales tax group"]);
        await freetaxpage.fillUnitPrice(data["Unit price"]);
    },
);

When("I open the Line details tab", async function () {
    await freetaxpage.expandLineDetailsTab();
});

When(
    "I enter the following financial dimension details:",
    async function (dataTable) {
        const data = dataTable.rowsHash();
        await freetaxpage.clickFinancialDimensionsLine();
        await freetaxpage.fillBusinessUnit(data["Operating unit number"]);
        await freetaxpage.fillLocalProject(data["Local project"]);
        await freetaxpage.fillLocalCostCenter(data["Local cost center"]);
    },
);

When("I click on  Post and OK button then Leasernet section", async function () {
    await freetaxpage.clickPostButton();
    await freetaxpage.clickOK();
    await freetaxpage.clickLaserNetButton();
    //await freetaxpage.clickLaserNetOriginal();
});

When("the user clicks on Download button and back", async function () {
    await freetaxpage.clickDownloadButton();
});

