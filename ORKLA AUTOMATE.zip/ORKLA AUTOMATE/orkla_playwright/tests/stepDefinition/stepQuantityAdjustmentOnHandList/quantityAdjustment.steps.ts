import { When, Then } from "@cucumber/cucumber";
import { expect } from "@playwright/test";
import { QuantityAdjustmentPage } from "../../pages/quantityAdjustmentPage";

let quantityAdjustmentPage: QuantityAdjustmentPage;


// ───────────────────────── NAVIGATION ─────────────────────────

When(
    "I navigate to D365 OV05 and open On-hand list",
    async function () {

        quantityAdjustmentPage = new QuantityAdjustmentPage(this.page);

        await quantityAdjustmentPage.navigateToQuantityAdjustmentPage();
        await quantityAdjustmentPage.clickModuleIcon();
        await quantityAdjustmentPage.clickInventoryManagement();
        await quantityAdjustmentPage.clickCollapseAll();
        await quantityAdjustmentPage.clickInquiriesAndReports();
        await quantityAdjustmentPage.clickOnHandList();
    }
);


// ───────────────────────── FILTER ITEM NUMBER ─────────────────────────

When(
    'I filter the On-hand list using Item number {string}',
    async function (itemNumber: string) {

        await quantityAdjustmentPage.filterItemNumber(itemNumber);
    }
);


// ───────────────────────── OPEN QUANTITY ADJUSTMENT ─────────────────────────

When(
    "I click Quantity adjustment",
    async function () {

        await quantityAdjustmentPage.clickQuantityAdjustment();
    }
);


// ───────────────────────── CREATE NEW QUANTITY ADJUSTMENT ─────────────────────────

When(
    "I click New on Quantity adjustment",
    async function () {

        await quantityAdjustmentPage.clickNew();
    }
);


// ───────────────────────── FILL INVENTORY ADJUSTMENT DETAILS ─────────────────────────

When(
    "I enter the following inventory adjustment details",
    async function (dataTable) {
        const data = dataTable.rowsHash();

        await quantityAdjustmentPage.enterSite(data["Site"]);
        await quantityAdjustmentPage.enterWarehouse(data["Warehouse"]);
        await quantityAdjustmentPage.enterBatchNumber(data["Batch number"]);
        await quantityAdjustmentPage.enterLocation(data["Location"]);
        await quantityAdjustmentPage.enterLicensePlate(data["License plate"]);
        await quantityAdjustmentPage.enterQuantity(data["Quantity"]);
    }
);

// ───────────────────────── SAVE QUANTITY ADJUSTMENT ─────────────────────────

When(
    "I click OK to save the Quantity adjustment",
    async function () {

        await quantityAdjustmentPage.clickOK();
    }
);