import { When, Then } from "@cucumber/cucumber";
import { expect } from "@playwright/test";
import { ForeignCurrency } from "../../pages/foreigncurrencypage";

let foreigncurrency: ForeignCurrency;

When("the user navigates to Foreign currency revaluation", async function () {
  foreigncurrency = new ForeignCurrency(this.page);
  await foreigncurrency.openForeignCurrencyModule();
});

When(
  "the user fill dates and name and click on OK button",
  async function (dataTable) {
    const data = dataTable.rowsHash();
    await foreigncurrency.fillRevaluationDate(data["Revaluation date"]);
    await foreigncurrency.fillExchangeRateDate(data["Exchange rate date"]);
    await foreigncurrency.fillNameFilter(data["Name"]);
  },
);

Then("click on Process date column header", async function () {
  await foreigncurrency.clickProcessDateColumnHeader();
  await foreigncurrency.clickSortNewestToOldest();
});