import { When, Then } from "@cucumber/cucumber";
import { expect } from "@playwright/test";
import { CreateBatchNumberPage } from "../../pages/batchNumberCreationpage";

let createBatchNumberPage: CreateBatchNumberPage;

// ───────────────────────── NAVIGATION ─────────────────────────

When(
    "I navigate to Warehouse Management and open Batches",
    async function () {
        createBatchNumberPage = new CreateBatchNumberPage(this.page);

        await createBatchNumberPage.navigateToBatchesPage();
        await createBatchNumberPage.clickModuleIcon();
        await createBatchNumberPage.clickWarehouseManagement();
        await createBatchNumberPage.clickCollapseAll();
        await createBatchNumberPage.clickSetup();
        await createBatchNumberPage.clickInventory();
        await createBatchNumberPage.clickBatches();
    }
);

// ───────────────────────── CREATE NEW BATCH NUMBER ─────────────────────

When(
    "I click the New button on the Batche page",
    async function () {
        await createBatchNumberPage.clickNewButton();
    }
);

// ───────────────────────── FILL BATCH DETAILS ─────────────────────────

When(
    "I enter the following value for creating new Batch Number",
    async function (dataTable) {
        const data = dataTable.rowsHash();

        await createBatchNumberPage.fillItemNumber(data["Item number"]);
        await createBatchNumberPage.fillBatchNumber(data["Batch number"]);
    }
);

// ───────────────────────── SAVE BATCH NUMBER ─────────────────────────

When(
    "I click to save the Batch Number",
    async function () {
        await createBatchNumberPage.clickSaveButton();
    }
);
