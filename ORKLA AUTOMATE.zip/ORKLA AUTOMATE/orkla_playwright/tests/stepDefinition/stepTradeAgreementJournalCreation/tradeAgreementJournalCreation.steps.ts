import { Given, When, Then } from "@cucumber/cucumber";
import { expect } from "@playwright/test";
import { CreateTradeAgreementJournalPage } from "../../pages/tradeAgreementJournalCreationpage";

let createTradeAgreementJournalPage: CreateTradeAgreementJournalPage;

Given(
    "I navigate to Account Receivable and open Trade Agreement Journal Page",
    async function () {
        createTradeAgreementJournalPage =
            new CreateTradeAgreementJournalPage(this.page);

        await createTradeAgreementJournalPage.navigateToTradeAgreementJournalPage();

        await createTradeAgreementJournalPage.clickModuleIcon();
        await createTradeAgreementJournalPage.clickAccountReceivable();
        await createTradeAgreementJournalPage.clickCollapseAll();
        await createTradeAgreementJournalPage.clickSetup();
        await createTradeAgreementJournalPage.clickTradeAgreementJournal();
    }
);

When(
    "I click the New button on the Trade Agreement Journal Page",
    async function () {
        await createTradeAgreementJournalPage.clickNewButton();
    }
);

When(
    "I enter the following values to create new Trade Agreement",
    async function (dataTable) {
        const data = dataTable.rowsHash();

        await createTradeAgreementJournalPage.fillName(data["Name"]);
        await createTradeAgreementJournalPage.fillDescription(
            data["Description"]
        );
    }
);

When(
    "I save the Trade Agreement",
    async function () {
        await createTradeAgreementJournalPage.clickSaveButton();
    }
);

When(
    "I click on Line button",
    async function () {
        await createTradeAgreementJournalPage.clickLineButton();
    }
);

When(
    "I fill Journal line with:",
    async function (dataTable) {
        const data = dataTable.rowsHash();

        await createTradeAgreementJournalPage.fillPartyCodeType(
            data["Party Code Type"]
        );

        await createTradeAgreementJournalPage.fillAccountSection(
            data["Account Section"]
        );

        await createTradeAgreementJournalPage.fillProductCodeType(
            data["Product Code Type"]
        );

        await createTradeAgreementJournalPage.fillItemRelation(
            data["Item Relation"]
        );

        await createTradeAgreementJournalPage.fillAmountInCurrency(
            data["Amount in Currency"]
        );

        await createTradeAgreementJournalPage.fillCurrency(
            data["Currency"]
        );

        await createTradeAgreementJournalPage.fillPriceIndication(
            data["Price Identification"]
        );
    }
);

When(
    "I click on Details tab and fill with:",
    async function (dataTable) {
        const data = dataTable.rowsHash();

        await createTradeAgreementJournalPage.fillFromDate(
            data["From Date"]
        );

        await createTradeAgreementJournalPage.fillToDate(
            data["To Date"]
        );

        await createTradeAgreementJournalPage.fillPriceUnit(
            data["Price Unit"]
        );
    }
);


When(
    "I click on Post button and then OK",
    async function () {
        await createTradeAgreementJournalPage.clickPostButton();
        await createTradeAgreementJournalPage.clickOKButton();
    }
);

// ============================================================
// VALIDATION
// ============================================================

Then(
    "the Trade Agreement should be processed successfully",
    async function () {
        await createTradeAgreementJournalPage.assertItemLoaded();

        expect(createTradeAgreementJournalPage).toBeDefined();
    }
);
