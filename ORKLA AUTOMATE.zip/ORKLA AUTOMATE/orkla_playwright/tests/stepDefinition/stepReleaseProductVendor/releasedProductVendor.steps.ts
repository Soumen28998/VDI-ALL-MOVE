import { When } from "@cucumber/cucumber";
import { ReleasedProductVendorPage } from "../../pages/releasedProductVendorPage";

let releasedProductVendorPage: ReleasedProductVendorPage;


// ───────────────────────── NAVIGATION ─────────────────────────

When(
    "I navigate to D365 and open Product information management",
    async function () {

        releasedProductVendorPage =
            new ReleasedProductVendorPage(this.page);

        await releasedProductVendorPage.navigateToD365();

        await releasedProductVendorPage.clickModuleIcon();

        await releasedProductVendorPage
            .clickProductInformationManagement();
    }
);


// ───────────────────────── OPEN RELEASED PRODUCTS ─────────────────────────

When(
    "I click Released products",
    async function () {

        await releasedProductVendorPage.clickReleasedProducts();
    }
);


// ───────────────────────── FILTER PRODUCT ─────────────────────────

When(
    'I filter Released products using Item number {string}',
    async function (itemNumber: string) {

        await releasedProductVendorPage
            .filterReleasedProduct(itemNumber);
    }
);


// ───────────────────────── OPEN SETUP ─────────────────────────

When(
    "I click Setup",
    async function () {

        await releasedProductVendorPage.clickSetup();
    }
);


// ───────────────────────── ADD VENDOR RECORD ─────────────────────────

When(
    "I click Add vendor record",
    async function () {

        await releasedProductVendorPage.clickAdd();
    }
);


// ───────────────────────── ENTER VENDOR ─────────────────────────

When(
    'I enter Vendor {string}',
    async function (vendor: string) {

        await releasedProductVendorPage.enterVendor(vendor);
    }
);


// ───────────────────────── SAVE VENDOR RECORD ─────────────────────────

When(
    "I click Save vendor record",
    async function () {

        await releasedProductVendorPage.clickSave();
    }
);
