import { Given, When } from "@cucumber/cucumber";
import { expect } from "@playwright/test";
import { CreateWorkerPage } from "../../pages/createWorkerPage";

let createWorkerPage: CreateWorkerPage;
Given("I navigate to D365 NI01 dashboard", async function () {
    createWorkerPage = new CreateWorkerPage(this.page);

    await createWorkerPage.navigateToD365Dashboard();
});

When("I click on Modules", async function () {
    await createWorkerPage.clickModules();
});

When("I select Warehouse management", async function () {
    await createWorkerPage.selectWarehouseManagement();
    await createWorkerPage.clickCollapseAll();
    await createWorkerPage.clickSetup();
});

When("I open Worker", async function () {
    await createWorkerPage.openWorker();
});

When("I filter Worker by name {string}", async function (workerName: string) {
    await createWorkerPage.filterWorkerByName(workerName);
});

When("I select the Worker option {string}", async function (workerName: string) {
    await createWorkerPage.selectWorkerOption(workerName);
});

When("I click on New Worker", async function () {
    await createWorkerPage.clickNewWorker();
});

// ─────────────────────────────────────────────
// ENTER WORKER USER DETAILS
// ─────────────────────────────────────────────

When("I enter Worker user details", async function (dataTable) {
    const data = dataTable.rowsHash();

    if (data["User ID"]?.trim()) {
        await createWorkerPage.enterUserId(data["User ID"]);
    }

    if (data["User name"]?.trim()) {
        await createWorkerPage.enterUserName(data["User name"]);
    }

    if (data["Default warehouse"]?.trim()) {
        await createWorkerPage.enterDefaultWarehouse(data["Default warehouse"]);
    }

    if (data["Menu name"]?.trim()) {
        await createWorkerPage.enterMenuName(data["Menu name"]);
    }
});

// ─────────────────────────────────────────────
// SAVE WORKER DETAILS
// ─────────────────────────────────────────────

When("I save Worker details", async function () {
    await createWorkerPage.saveWorkerDetails();
});

// ─────────────────────────────────────────────
// ENTER PASSWORD DETAILS
// ─────────────────────────────────────────────

When("I enter Worker password details", async function (dataTable) {
    const data = dataTable.rowsHash();

    if (data["Password"]?.trim()) {
        await createWorkerPage.enterPassword(data["Password"]);
    }

    if (data["Confirm password"]?.trim()) {
        await createWorkerPage.enterConfirmPassword(data["Confirm password"]);
    }
});

// ─────────────────────────────────────────────
// SET PASSWORD
// ─────────────────────────────────────────────

When("I click Set password", async function () {
    await createWorkerPage.clickSetPassword();
});