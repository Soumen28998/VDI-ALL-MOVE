import { When, Then, Given } from "@cucumber/cucumber";
import { expect } from "@playwright/test";
import { AccountPage } from "../../pages/accountpage";

let accountPage: AccountPage;

Given("I navigate to the Orkla OV01 Dashboard", async function () {
  accountPage = new AccountPage(this.page);
  await accountPage.navigateToOV01Dashboard();
});

When("the user navigates to Accounts receivable Customers All customers", async function () {
  await accountPage.openSalesOrderModule();
});

When(
  "the user clicks the Account column header and fill",
  async function (dataTable) {
    const data = dataTable.rowsHash();
    await accountPage.fillFilterField(data["Account"]);
  },
);

When("Click on Statement under Collect tab", async function () {
    await accountPage.clickCollect();
    await accountPage.clickStatement();
});

When("the user selects the required date range", async function (dataTable) {
  const data = dataTable.rowsHash();
  await accountPage.fillFromDate(data["From"]);
  await accountPage.fillToDate(data["To"]);
  await accountPage.clickOK();
});

When("the user clicks on Download button", async function () {
  await accountPage.clickDownloadButton();
});

