import { When, Then } from "@cucumber/cucumber";
import { expect } from "@playwright/test";
import { CustomerShippedPage } from "../../pages/customershippedpage";

let customerShippedPage: CustomerShippedPage;

When("the user navigates to Accounts receivable Inquiries and reports Invoices Shipped not invoiced report", async function () {
  customerShippedPage = new CustomerShippedPage(this.page);
  await customerShippedPage.openCustomerShippedModule();
});

When(
  "the user enters the cutoff date value",
  async function (dataTable) {
    const data = dataTable.rowsHash();
    await customerShippedPage.fillCutoffDate(data["Cutoff date"]);
  },
);

When("the user clicks to Download Excel file", async function () {
  await customerShippedPage.clickDownloadButton();
});

