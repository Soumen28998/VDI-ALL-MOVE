import { When, Then } from "@cucumber/cucumber";
import { expect } from "@playwright/test";
import { SalesForeignCurrency } from "../../pages/salesforeignpage";

let salesforeigncurrency: SalesForeignCurrency;

When("the user navigates to sales Foreign currency revaluation", async function () {
  salesforeigncurrency = new SalesForeignCurrency(this.page);
  await salesforeigncurrency.openForeignCurrencyModule();
});

When(
  "Click and Fill values",
  async function (dataTable) {
    const data = dataTable.rowsHash();
    await salesforeigncurrency.fillconsideredDate(data["Considered date"]);
    await salesforeigncurrency.fillrateDate(data["Date of rate"]);
    await salesforeigncurrency.filldescription(data["Description"]);
    await salesforeigncurrency.fillnotes(data["Notes"]);
  },
);

Then("Click ok and validate all Popup", async function () {
  await salesforeigncurrency.clickValidatepopup();
});