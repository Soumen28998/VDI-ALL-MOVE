import { When, Then } from "@cucumber/cucumber";
import { expect } from "@playwright/test";
import { CustomerInvoicePage } from "../../pages/customerInvoicepage";

let customerInvoicePage: CustomerInvoicePage;

/*When("I navigate to the Orkla OV01 Dashboard", async function () {
        customerInvoicePage = new CustomerInvoicePage(this.page);
        await customerInvoicePage.navigateToinvoicePage();
    },
);*/

When("the user navigates to Customer invoicing", async function () {
    customerInvoicePage = new CustomerInvoicePage(this.page);
    await customerInvoicePage.openSalesOrderModule();
},
);

When("the user clicks on Shipped but not invoiced sales orders", async function () {
    await customerInvoicePage.clickShippedNotInvoicedTile();
},
);

When("the user click and filters the Sales order column with:", async function (dataTable) {
    const data = dataTable.rowsHash();
    await customerInvoicePage.fillFilterField(data["Sales order"]);
},
);

When("the user selects the required sales order", async function () {
    //await customerInvoicePage.clickSalesOrder();
},
);

When(
    "the user clicks Invoice",
    async function () {
        await customerInvoicePage.clickInvoice();
    },
);

When(
    "click on the Invoice journal button",
    async function () {
        await customerInvoicePage.clickInvoiceJurnal();
    },
);

Then(
    "the user should be able to download the invoice document in PDF format",
    async function () {
        await customerInvoicePage.assertItemLoaded();
    },
);