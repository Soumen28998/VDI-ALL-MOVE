import { Given, When, Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { SalesOrderPage } from '../../pages/salesorderpage';
import { OrklaWorld } from '@support/world';

let salesOrderPage: SalesOrderPage;

When('I click on Sales and Marketing and goto Sales Order and click on All Sales Orders', async function () {
    salesOrderPage = new SalesOrderPage(this.page!);
    await salesOrderPage.openSalesOrderModule();
});

Then('I should be redirected to the Orkla UAT2 Sales Order page', async function () {
    await salesOrderPage.assertSalesOrderLoaded();
});

Then('the sales page loads completely', async function () {
    await salesOrderPage.assertSalesOrderLoaded();
});

When('I click the New button to create a new sales order', async function () {
    await salesOrderPage.clickNew();
});

When('I fill in the Create sales order section with:', async function (dataTable) {
    const data = dataTable.rowsHash();

    await salesOrderPage.fillCustomerAccount(data['Customer account']);
    await salesOrderPage.clickGeneralTab();
    await salesOrderPage.fillWarehouse(data['Warehouse']);
    await salesOrderPage.filldeliveryDateControlsInput(data['Delivery date control']);
    await salesOrderPage.filldeliveryModeInput(data['Mode of delivery']);
    await salesOrderPage.filldeliveryTermsInput(data['Delivery terms']);
    await salesOrderPage.fillCustomerRequisition(data['Customer requisition']);
    await salesOrderPage.fillCustomerReference(data['Customer reference']);
    await salesOrderPage.fillSalesTaker(data['Sales taker']);
});

Then('I click OK to generate sales orders', async function () {
    await salesOrderPage.clickOK();
});

Then('click on sales filter and search Item list', async function () {
    console.log("Using Item Number:", this.testData.itemNumber);
    await salesOrderPage.fillFilter(this.testData.itemNumber);
});

Then('click on Copy and close', async function () {
    await salesOrderPage.clickCopyAndClose();
});

Then('click on Line details and fill in the Delivery type with:', async function (dataTable) {
    const data = dataTable.rowsHash();
    await salesOrderPage.selectDeliveryType(data['Delivery type']);
});

Then('Save Sales Order', async function () {
    await salesOrderPage.clickSave();
});

Then('Click on Intercompany sales order under manage section', async function () {
    await salesOrderPage.clickIntercompanySalesOrder();
});

Then('Click Heade and copy SNL_SO', async function () {
    await salesOrderPage.copySalesOrder();
});

Then('Click Line and select Confirmed ship date', async function () {
    await salesOrderPage.clickConfirmedShipDate();
    await salesOrderPage.updateConfirmedShipDateIfPopupAppears();
});

Then('Click on cancel', async function () {
    await salesOrderPage.clickCancelIfVisible();
});

Then('Click on Confirm sales order', async function () {
    await salesOrderPage.clickConfirmSalesOrder();
});

Then('Click ok', async function () {
    await salesOrderPage.clickConfirmSalesOrderOK();
    await salesOrderPage.clickPostingConfirmationOK();
});