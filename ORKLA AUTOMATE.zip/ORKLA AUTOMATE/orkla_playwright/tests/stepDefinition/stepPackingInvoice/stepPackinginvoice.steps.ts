import { Given, When, Then, DataTable } from "@cucumber/cucumber";
import { packingInvoice } from "../../pages/packingslipinvoicepage";

let packinginvoice: packingInvoice;

// ─────────────────────────────────────────────────────────────
// HEADER
// ─────────────────────────────────────────────────────────────

Then("Click Header and copy HEADER_SO", async function () {
    packinginvoice = new packingInvoice(this.page);

    await packinginvoice.clickHeaderAndCopySO();
});

// ─────────────────────────────────────────────────────────────
// INTERCOMPANY SETTINGS
// ─────────────────────────────────────────────────────────────

Then("Expand Intercompany settings", async function () {
    await packinginvoice.expandIntercompanySettings();
});

// ─────────────────────────────────────────────────────────────
// DISABLE INTERCOMPANY OPTIONS
// ─────────────────────────────────────────────────────────────

Then(
    "Disable Auto-create intercompany orders and Direct delivery",
    async function () {
        await packinginvoice.clickIntercompanyOptions();
    },
);

// ─────────────────────────────────────────────────────────────
// DELIVERY
// ─────────────────────────────────────────────────────────────

Then("Expand Delivery section", async function () {
    await packinginvoice.expandDeliveryTab();
});

// ─────────────────────────────────────────────────────────────
// DELIVERY DATE CONTROL
// ─────────────────────────────────────────────────────────────

Then(
    "Select Delivery date control lookup with:",
    async function (dataTable: DataTable) {
        const data = dataTable.rowsHash();

        await packinginvoice.fillDeliveryDateControl(
            data["Delivery date control lookup"],
        );
    },
);

// ─────────────────────────────────────────────────────────────
// LINES
// ─────────────────────────────────────────────────────────────

Then("I click on Lines", async function () {
    await packinginvoice.clickLineTab();
});

Then(
    "I fill Sales Order line with:",
    async function (dataTable: DataTable) {
        const data = dataTable.rowsHash();

        await packinginvoice.addItems(data['Item number']);
        await packinginvoice.fillQuantity(data['Quantity']);
        await packinginvoice.fillBatchNumber(data['Batch number']);
        await packinginvoice.fillUnitPrice(data['Unit price']);

    },
);

// ─────────────────────────────────────────────
// PICK AND PACK
// ─────────────────────────────────────────────

When(
    "Click on Pick Pack button and fill with:",
    async function (dataTable: DataTable) {
        const data = dataTable.rowsHash();

        await packinginvoice.clickPickandPack(
            data["Post Quantity"],
        );
    },
);

Then(
    "Packing Slip should be posted successfully",
    async function () {
        await packinginvoice.assertSalesOrderLoaded();
    },
);

// ─────────────────────────────────────────────
// INVOICE
// ─────────────────────────────────────────────

When(
    "Click Invoice and fill with:",
    async function (dataTable: DataTable) {
        const data = dataTable.rowsHash();

        await packinginvoice.clickInvoice(
            data["Invoice Quantity"],
        );
    },
);

Then(
    "Invoice should be posted successfully",
    async function () {
        await packinginvoice.assertSalesOrderLoaded();
    },
);
