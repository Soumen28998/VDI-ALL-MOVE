import { Given, When, Then, DataTable } from "@cucumber/cucumber";
import { createTradeAgreement } from "../../pages/createTradeAgreementpage";

let createtradeagreement: createTradeAgreement;

// ───────────────────────── NAVIGATION ─────────────────────────

Given("I navigate to the Orkla Trade Agreement\\(SBL_{float}) dashboard",
    async function (float) {
        createtradeagreement = new createTradeAgreement(this.page);
        await createtradeagreement.navigateToCreateTradeAgreement();
    });

When("I open Trade Agreement page", async function () {
    await createtradeagreement.openTradeAgreementModule();
});

// ───────────────────────── CREATE TRADE AGREEMENT ─────────────────────────

When(
    "I create new Trade Agreement and save",
    async function (dataTable: DataTable) {
        const data = dataTable.rowsHash();

        await createtradeagreement.fillnameInput(data["Name"]);
        await createtradeagreement.filldescriptionInput(data["Description"]);

        await createtradeagreement.clickSave();
    },
);

// ───────────────────────── LINES ─────────────────────────

When("I click on Lines button", async function () {
    await createtradeagreement.clickLine();
});

// ───────────────────────── JOURNAL LINE ─────────────────────────

When("I fill Journal line Trade Agreement with", async function (dataTable: DataTable) {
    const data = dataTable.rowsHash();

    await createtradeagreement.fillRelationInput(data["Relation"]);
    await createtradeagreement.fillPartyCodeInput(data["Party Code Type"]);
    await createtradeagreement.fillAccountInput(data["Account Section"]);
    await createtradeagreement.fillProductCodeInput(data["Product Code Type"]);
    await createtradeagreement.fillItemRelationInput(data["Item Relation"]);
    await createtradeagreement.fillUnitInput(data["Unit"]);
    await createtradeagreement.fillAmountInput(data["Amount in Currency"]);
    await createtradeagreement.fillCurrencyInput(data["Currency"]);
});

// ───────────────────────── DETAILS TAB ─────────────────────────

When(
    "I click on Details tab and fill with",
    async function (dataTable: DataTable) {
        const data = dataTable.rowsHash();

        //await  createtradeagreement.clickDetailsTab();
        await createtradeagreement.expandSection('Details');
        await createtradeagreement.fillDiscountPercentage01Input(data["Discount percentage 1"]);
        await createtradeagreement.fillFromDateInput(data["From Date"]);
        await createtradeagreement.fillToDateInput(data["To Date"]);
        
       
    },
);

// ───────────────────────── SAVE DETAILS ─────────────────────────

When("I save Trade Agreement details", async function () {
    // use the cucumber world page
    await (this as any).page.keyboard.press('Alt');
    await (this as any).page.keyboard.press('S');
});

// ───────────────────────── POST ─────────────────────────

When("I click on Post and OK button", async function () {
    await createtradeagreement.clickPost();
    await createtradeagreement.clickOK();
});

// ───────────────────────── CLICK BACK ─────────────────────────

When("I click on Back button", async function () {
    if (!createtradeagreement) {
        createtradeagreement = new createTradeAgreement(this.page);
    }

    await createtradeagreement.clickBack();
})

// ───────────────────────── ASSERTION ─────────────────────────

Then("The Trade Agreement should be processed successfully", async function () {
    await createtradeagreement.assertProductLoaded();
});
