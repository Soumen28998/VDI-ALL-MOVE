import { Given, When, Then, DataTable } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { ItemListPage } from '../../pages/itemlistpage';

let itemlistPage: ItemListPage;

Given('I navigate to the Orkla BDL dashboard', async function () {
    itemlistPage = new ItemListPage(this.page);
    await itemlistPage.navigateToItemlistPage();
});

When('I click on Sales and Marketing and goto Item list and click on Item list', async function () {
    await itemlistPage.openItemModule();
});

Then('I should be redirected to the Orkla UAT2 Item list page', async function () {
    await itemlistPage.assertItemLoaded();
});

Then('the page loads completely', async function () {
    await itemlistPage.assertItemLoaded();
});

When('I click the New button to create a new item list', async function () {
    await itemlistPage.clickNew();
});

When('I fill in the Description section with:', async function (dataTable) {
    const data = dataTable.rowsHash();

    await itemlistPage.selectSalesItem(data['Description']);
});

Then('I fill Generate item lists per customer with:', async function (dataTable) {
    const data = dataTable.rowsHash();

    await itemlistPage.fillGenerationtype(data['Generation type']);
    await itemlistPage.fillminimumquantity(data['Minimum quantity']);
    await itemlistPage.fillvalue(data['Value']);
});

Then('I click OK to generate the item list', async function () {
    await itemlistPage.clickOK();
});


Then('I click on Add button and I fill in the item number with:', async function (dataTable) {
    const data = dataTable.rowsHash();

    await itemlistPage.addItems(data['Item number']);
});

Then('Save Item list', async function () {
    await itemlistPage.clickSave();
});

Then('click on filter and search Item list', async function () {
    await itemlistPage.fillFilter();
});

//testData is initialized in OrklaWorld, your step can stay simple
/*Then('I copy the item number', async function () {
    const itemNumber = await itemlistPage.copyItemNumber();
    console.log("Copied Item Number:", itemNumber);
    this.testData.itemNumber = itemNumber;
    console.log("Stored Item Number:", this.testData.itemNumber);
});*/


Then('I copy the item number', async function () {
    const itemNumber = await itemlistPage.copyItemNumber();

    console.log('Copied Item Number:', itemNumber);

    // Initialize testData if it does not exist
    this.testData ??= {};

    this.testData.itemNumber = itemNumber;

    console.log('Stored Item Number:', this.testData.itemNumber);
});
