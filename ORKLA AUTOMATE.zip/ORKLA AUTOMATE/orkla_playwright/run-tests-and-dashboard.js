
'use strict';

const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const ROOT = process.cwd();

const CUCUMBER_BIN = path.join(
    ROOT,
    'node_modules',
    '@cucumber',
    'cucumber',
    'bin',
    'cucumber-js'
);

const TEST_RESULTS_DIR = path.join(
    ROOT,
    'test-results'
);

const REPORTS_DIR = path.join(
    ROOT,
    'reports'
);

const JSON_REPORT = path.join(
    TEST_RESULTS_DIR,
    'cucumber-report.json'
);

const DASHBOARD = path.join(
    REPORTS_DIR,
    'dashboard.html'
);

const REPORT_GENERATOR = path.join(
    ROOT,
    'report.js'
);

const RUN_START = path.join(
    REPORTS_DIR,
    'run-start.json'
);

const RUN_END = path.join(
    REPORTS_DIR,
    'run-end.json'
);

/*
 * IMPORTANT:
 *
 * Use a relative JSON formatter path.
 *
 * Do NOT use:
 *
 * json:C:\Users\...
 *
 * Cucumber interprets the ":" in C:
 * as part of the formatter descriptor.
 */
const CUCUMBER_JSON_FORMAT =
    'json:test-results/cucumber-report.json';


function log(message = '') {
    console.log(message);
}


function line(char = '=', length = 64) {
    console.log(char.repeat(length));
}


function ensureDirectories() {

    fs.mkdirSync(
        TEST_RESULTS_DIR,
        { recursive: true }
    );

    fs.mkdirSync(
        REPORTS_DIR,
        { recursive: true }
    );
}


function writeJson(file, data) {

    fs.writeFileSync(
        file,
        JSON.stringify(data, null, 2),
        'utf8'
    );
}


function removeOldReport() {

    try {

        if (fs.existsSync(JSON_REPORT)) {

            fs.rmSync(
                JSON_REPORT,
                { force: true }
            );

            log(
                'Removed previous Cucumber JSON report.'
            );
        }

    } catch (error) {

        console.error(
            'Could not remove previous Cucumber report:',
            error.message
        );
    }
}


function getBrowserMode() {

    const value =
        String(
            process.env.HEADLESS || ''
        )
            .trim()
            .toLowerCase();

    if (
        value === 'true' ||
        value === '1' ||
        value === 'yes'
    ) {
        return 'HEADLESS';
    }

    return 'HEADED';
}


/*
 * Parse command-line arguments.
 *
 * Supported:
 *
 * 1. ALL
 *
 *    run-tests-and-dashboard.js
 *
 *
 * 2. SINGLE FEATURE
 *
 *    run-tests-and-dashboard.js "tests/features/a.feature"
 *
 *
 * 3. MULTIPLE FEATURES
 *
 *    run-tests-and-dashboard.js
 *    "tests/features/a.feature"
 *    "tests/features/b.feature"
 *
 *
 * 4. TAG
 *
 *    run-tests-and-dashboard.js --tags "@supplier"
 *
 *
 * 5. MULTIPLE TAG EXPRESSIONS
 *
 *    run-tests-and-dashboard.js
 *    --tags "@supplier and @uk"
 *
 *
 * 6. TAG + FEATURE
 *
 *    run-tests-and-dashboard.js
 *    --tags "@smoke"
 *    "tests/features/supplier.feature"
 *
 *
 * 7. Multiple --tags options
 *
 *    run-tests-and-dashboard.js
 *    --tags "@supplier"
 *    --tags "@uk"
 *
 *
 * The function separates Cucumber options from
 * feature-file arguments.
 */
function parseUserArguments() {

    const rawArguments =
        process.argv.slice(2);

    const cucumberOptions = [];
    const featureArguments = [];

    let i = 0;

    while (i < rawArguments.length) {

        const current =
            rawArguments[i];

        /*
         * --tags <expression>
         */
        if (current === '--tags') {

            const tagExpression =
                rawArguments[i + 1];

            if (
                !tagExpression ||
                tagExpression.startsWith('--')
            ) {

                console.error(
                    'ERROR: --tags requires a tag expression.'
                );

                console.error(
                    'Example: --tags "@supplier"'
                );

                process.exitCode = 1;

                return null;
            }

            cucumberOptions.push(
                '--tags',
                tagExpression
            );

            i += 2;

            continue;
        }


        /*
         * Support:
         *
         * --tags=@supplier
         */
        if (
            current.startsWith('--tags=')
        ) {

            const tagExpression =
                current.substring(
                    '--tags='.length
                );

            if (!tagExpression.trim()) {

                console.error(
                    'ERROR: --tags requires a tag expression.'
                );

                process.exitCode = 1;

                return null;
            }

            cucumberOptions.push(
                '--tags',
                tagExpression
            );

            i++;

            continue;
        }


        /*
         * Any other --option is passed to Cucumber.
         *
         * This makes the runner more flexible for
         * future Cucumber options.
         */
        if (current.startsWith('--')) {

            cucumberOptions.push(
                current
            );

            i++;

            continue;
        }


        /*
         * Everything else is treated as a
         * feature file / feature path.
         */
        featureArguments.push(
            current
        );

        i++;
    }


    /*
     * If no feature file was supplied,
     * run ALL feature files.
     */
    if (featureArguments.length === 0) {

        featureArguments.push(
            'tests/features/**/*.feature'
        );
    }


    return {
        cucumberOptions,
        featureArguments
    };
}


/*
 * Build the complete Cucumber command.
 */
function buildCucumberArguments() {

    const parsed =
        parseUserArguments();

    if (!parsed) {
        return null;
    }

    const {
        cucumberOptions,
        featureArguments
    } = parsed;


    const args = [

        CUCUMBER_BIN,

        '--require-module',
        'ts-node/register',

        '--require-module',
        'tsconfig-paths/register',

        '--require',
        'tests/stepDefinition/**/*.ts',

        '--require',
        'tests/hooks/**/*.ts',

        '--format',
        'progress',

        '--format',
        CUCUMBER_JSON_FORMAT,

        /*
         * Cucumber options such as --tags
         * come before feature arguments.
         */
        ...cucumberOptions,

        /*
         * Feature files come last.
         */
        ...featureArguments
    ];


    return args;
}


/*
 * Display what the runner is executing.
 */
function showExecutionMode() {

    const parsed =
        parseUserArguments();

    if (!parsed) {
        return;
    }

    const {
        cucumberOptions,
        featureArguments
    } = parsed;


    log('');

    line('-');

    log(
        ' EXECUTION MODE'
    );

    line('-');


    if (cucumberOptions.length === 0) {

        log(
            'Tags       : ALL'
        );

    } else {

        const tags = [];

        for (
            let i = 0;
            i < cucumberOptions.length;
            i++
        ) {

            if (
                cucumberOptions[i] === '--tags' &&
                cucumberOptions[i + 1]
            ) {

                tags.push(
                    cucumberOptions[i + 1]
                );
            }
        }


        if (tags.length > 0) {

            log(
                `Tags       : ${tags.join(' | ')}`
            );

        } else {

            log(
                `Options    : ${cucumberOptions.join(' ')}`
            );
        }
    }


    if (
        featureArguments.length === 1 &&
        featureArguments[0] ===
            'tests/features/**/*.feature'
    ) {

        log(
            'Features   : ALL'
        );

    } else {

        log(
            `Features   : ${featureArguments.length}`
        );

        for (
            const feature of featureArguments
        ) {

            log(
                `             ${feature}`
            );
        }
    }


    line('-');

    log('');
}


function runCucumber() {

    line();

    log(
        '           CUCUMBER + PLAYWRIGHT QA RUN'
    );

    line();


    const mode =
        getBrowserMode();


    log(
        `Browser mode : ${mode}`
    );

    log(
        `HEADLESS     : ${mode === 'HEADLESS'}`
    );

    log(
        `Project root : ${ROOT}`
    );


    showExecutionMode();


    log(
        'Starting Cucumber...'
    );


    const args =
        buildCucumberArguments();


    if (!args) {

        return 1;
    }


    /*
     * Display the actual Cucumber arguments.
     *
     * This is extremely useful when debugging
     * tag / feature execution from PAD.
     */
    log('');

    log(
        'Cucumber command arguments:'
    );

    log(
        args
            .slice(1)
            .map(
                value => `"${value}"`
            )
            .join(' ')
    );

    log('');


    const result =
        spawnSync(
            process.execPath,
            args,
            {
                cwd: ROOT,

                stdio: 'inherit',

                env: {
                    ...process.env,

                    HEADLESS:
                        mode === 'HEADLESS'
                            ? 'true'
                            : 'false'
                }
            }
        );


    if (result.error) {

        console.error(
            'Cucumber process error:',
            result.error.message
        );

        return 1;
    }


    return (
        typeof result.status === 'number'
            ? result.status
            : 1
    );
}


function verifyJsonReport() {

    if (!fs.existsSync(JSON_REPORT)) {

        console.error('');

        console.error(
            'ERROR: Cucumber JSON report was not generated.'
        );

        console.error(
            `Expected: ${JSON_REPORT}`
        );

        return false;
    }


    const stats =
        fs.statSync(
            JSON_REPORT
        );


    if (stats.size === 0) {

        console.error(
            'ERROR: Cucumber JSON report is empty.'
        );

        return false;
    }


    log('');

    log(
        `Cucumber JSON size: ${stats.size} bytes`
    );


    return true;
}


function generateDashboard() {

    line();

    log(
        '              GENERATING DASHBOARD'
    );

    line();


    if (!fs.existsSync(REPORT_GENERATOR)) {

        console.error(
            `ERROR: report.js not found:\n${REPORT_GENERATOR}`
        );

        return false;
    }


    const result =
        spawnSync(
            process.execPath,
            [REPORT_GENERATOR],
            {
                cwd: ROOT,
                stdio: 'inherit'
            }
        );


    if (result.error) {

        console.error(
            'report.js error:',
            result.error.message
        );

        return false;
    }


    if (result.status !== 0) {

        console.error(
            `report.js exited with code ${result.status}`
        );

        return false;
    }


    return verifyDashboard();
}


function verifyDashboard() {

    if (!fs.existsSync(DASHBOARD)) {

        console.error(
            'ERROR: dashboard.html was not generated.'
        );

        return false;
    }


    const html =
        fs.readFileSync(
            DASHBOARD,
            'utf8'
        );


    if (!html.trim()) {

        console.error(
            'ERROR: dashboard.html is empty.'
        );

        return false;
    }


    /*
     * Confirm actual generated data exists.
     */
    if (
        !html.includes(
            'window.__DASHBOARD_DATA__'
        )
    ) {

        console.error(
            'ERROR: dashboard data object is missing.'
        );

        return false;
    }


    /*
     * The template marker must NOT remain.
     */
    if (
        html.includes(
            '/*DASHBOARD_DATA*/'
        )
    ) {

        console.error(
            'ERROR: dashboard data marker was not replaced.'
        );

        return false;
    }


    /*
     * Confirm actual testCases data exists.
     */
    if (
        !html.includes(
            '"testCases"'
        )
    ) {

        console.error(
            'ERROR: testCases data is missing.'
        );

        return false;
    }


    const stats =
        fs.statSync(
            DASHBOARD
        );


    log('');

    log(
        'Dashboard verification: PASSED'
    );

    log(
        `Dashboard size : ${stats.size} bytes`
    );

    log(
        `Dashboard time : ${stats.mtime.toLocaleString()}`
    );


    return true;
}


function openDashboard() {

    if (!fs.existsSync(DASHBOARD)) {

        console.error(
            `Cannot open dashboard:\n${DASHBOARD}`
        );

        return false;
    }


    /*
     * Cache-busting query string.
     *
     * This is important because the dashboard
     * is a local HTML file and the browser may
     * reuse an older document.
     */
    const absolutePath =
        path.resolve(
            DASHBOARD
        );


    const fileUrl =
        'file:///' +
        absolutePath
            .replace(/\\/g, '/')
            .replace(/ /g, '%20');


    const cacheBustedUrl =
        `${fileUrl}?run=${Date.now()}`;


    log('');

    log(
        'Opening dashboard...'
    );


    const result =
        spawnSync(
            'cmd.exe',
            [
                '/c',
                'start',
                '',
                cacheBustedUrl
            ],
            {
                cwd: ROOT,
                windowsHide: true,
                stdio: 'ignore'
            }
        );


    if (
        result.error ||
        result.status !== 0
    ) {

        console.error(
            'Could not automatically open dashboard.'
        );

        return false;
    }


    log(
        'Dashboard opened automatically.'
    );


    return true;
}


function showSummary() {

    try {

        const html =
            fs.readFileSync(
                DASHBOARD,
                'utf8'
            );


        const marker =
            'window.__DASHBOARD_DATA__ = ';


        const markerIndex =
            html.indexOf(marker);


        if (markerIndex === -1) {

            return;
        }


        const jsonStart =
            markerIndex +
            marker.length;


        const jsonEnd =
            html.indexOf(
                ';',
                jsonStart
            );


        if (jsonEnd === -1) {

            return;
        }


        const jsonText =
            html
                .substring(
                    jsonStart,
                    jsonEnd
                )
                .trim();


        const data =
            JSON.parse(
                jsonText
            );


        const tests =
            Array.isArray(
                data.testCases
            )
                ? data.testCases
                : [];


        let passed = 0;
        let failed = 0;
        let skipped = 0;


        for (
            const test of tests
        ) {

            const status =
                String(
                    test.status || ''
                )
                    .trim()
                    .toLowerCase();


            if (
                status === 'passed' ||
                status === 'pass'
            ) {

                passed++;

            } else if (
                status === 'failed' ||
                status === 'fail'
            ) {

                failed++;

            } else if (
                status === 'skipped' ||
                status === 'pending'
            ) {

                skipped++;
            }
        }


        const total =
            tests.length;


        const passRate =
            total
                ? Math.round(
                    (passed / total) * 100
                )
                : 0;


        line('-');

        log(
            ' DASHBOARD DATA'
        );

        line('-');

        log(
            `Tests   : ${total}`
        );

        log(
            `Passed  : ${passed}`
        );

        log(
            `Failed  : ${failed}`
        );

        log(
            `Skipped : ${skipped}`
        );

        log(
            `Pass %  : ${passRate}%`
        );

        line('-');


    } catch (error) {

        console.error(
            'Could not read dashboard summary:',
            error.message
        );
    }
}


function main() {

    line();

    log(
        '        ORKLA AUTOMATION DASHBOARD RUNNER'
    );

    line();


    const started =
        new Date();


    log(
        `Started : ${started.toISOString()}`
    );


    ensureDirectories();


    /*
     * Save actual automation start time.
     */
    writeJson(
        RUN_START,
        {
            iso: started.toISOString(),
            timestamp: started.getTime(),
            startedAt: started.toISOString()
        }
    );


    /*
     * Remove previous report.
     */
    removeOldReport();


    /*
     * Run Cucumber.
     */
    const cucumberExitCode =
        runCucumber();


    const finished =
        new Date();


    /*
     * Save actual automation finish time.
     */
    writeJson(
        RUN_END,
        {
            iso: finished.toISOString(),
            timestamp: finished.getTime(),
            finishedAt: finished.toISOString()
        }
    );


    line();

    log(
        '              CUCUMBER RUN COMPLETE'
    );

    line();


    log(
        `Cucumber exit code: ${cucumberExitCode}`
    );


    /*
     * Even when tests fail, Cucumber can still
     * generate a perfectly valid JSON report.
     *
     * Therefore generate the dashboard whenever
     * the JSON report exists.
     */
    if (!verifyJsonReport()) {

        console.error('');

        console.error(
            'Dashboard was NOT opened because Cucumber JSON is missing.'
        );


        process.exitCode =
            cucumberExitCode || 1;


        return;
    }


    /*
     * Generate dashboard from NEW JSON.
     */
    if (!generateDashboard()) {

        console.error('');

        console.error(
            'Dashboard generation failed.'
        );


        process.exitCode = 1;

        return;
    }


    showSummary();


    /*
     * ALWAYS open newly generated dashboard.
     */
    const opened =
        openDashboard();


    line();

    log(
        '                RUN FINISHED'
    );

    line();


    log(
        `Cucumber exit code : ${cucumberExitCode}`
    );

    log(
        `Dashboard          : ${DASHBOARD}`
    );

    log(
        `Dashboard opened   : ${opened ? 'YES' : 'NO'}`
    );

    log(
        `Finished           : ${finished.toISOString()}`
    );


    /*
     * Preserve test failure status.
     */
    process.exitCode =
        cucumberExitCode;
}


main();
