'use strict';

/**
 * =========================================================
 * ORKLA PLAYWRIGHT - CUCUMBER QA DASHBOARD GENERATOR
 * =========================================================
 *
 * Project structure:
 *
 * orkla_playwright/
 * ├── report.js
 * ├── run-tests-and-dashboard.js
 * ├── cucumber.js
 * ├── tests/
 * │
 * └── reports/
 *     ├── cucumber-report.json
 *     ├── cucumber-report.html
 *     ├── dashboard_template.html
 *     ├── dashboard.html
 *     ├── dashboard-history.json
 *     ├── run-start.json
 *     ├── run-end.json
 *     └── videos/
 *
 * =========================================================
 *
 * Cucumber generates:
 *     reports/cucumber-report.json
 *
 * This script generates:
 *     reports/dashboard.html
 *
 * IMPORTANT:
 *     dashboard_template.html is NEVER overwritten.
 *
 * Run directly:
 *     node report.js
 *
 * Recommended complete run:
 *     npm run test:dashboard
 *
 * =========================================================
 */

const fs = require('fs');
const path = require('path');

const ROOT = __dirname;

/* =========================================================
   FILE PATHS
========================================================= */

const inputPath = path.resolve(
  ROOT,
  'test-results',
  'cucumber-report.json'
);

const templatePath = path.resolve(
  ROOT,
  'reports',
  'dashboard_template.html'
);

const outputPath = path.resolve(
  ROOT,
  'reports',
  'dashboard.html'
);

const historyPath = path.resolve(
  ROOT,
  'reports',
  'dashboard-history.json'
);

/*
 * Created by run-tests-and-dashboard.js
 *
 * This is the ACTUAL automation start time.
 */
const runStartPath = path.resolve(
  ROOT,
  'reports',
  'run-start.json'
);

/*
 * Created by run-tests-and-dashboard.js
 *
 * This is the ACTUAL automation finish time.
 */
const runEndPath = path.resolve(
  ROOT,
  'reports',
  'run-end.json'
);

/* =========================================================
   FILE HELPERS
========================================================= */

function ensureDir(filePath) {
  fs.mkdirSync(
    path.dirname(filePath),
    {
      recursive: true
    }
  );
}

function readJson(filePath) {
  return JSON.parse(
    fs.readFileSync(
      filePath,
      'utf8'
    )
  );
}

function writeJson(
  filePath,
  value
) {
  ensureDir(filePath);

  fs.writeFileSync(
    filePath,
    JSON.stringify(
      value,
      null,
      2
    ),
    'utf8'
  );
}

/* =========================================================
   TEXT HELPERS
========================================================= */

function cleanText(value) {
  return String(
    value ?? ''
  )
    .replace(
      /\u001b\[[0-?]*[ -/]*[@-~]/g,
      ''
    )
    .replace(
      /\r/g,
      ''
    )
    .trim();
}

/*
 * Safe JSON injection inside <script>.
 *
 * Prevents test data from accidentally creating
 * </script> inside the generated dashboard.
 */
function escapeForHtmlScript(value) {
  return JSON.stringify(
    value
  )
    .replace(
      /</g,
      '\\u003c'
    )
    .replace(
      />/g,
      '\\u003e'
    )
    .replace(
      /&/g,
      '\\u0026'
    )
    .replace(
      /\u2028/g,
      '\\u2028'
    )
    .replace(
      /\u2029/g,
      '\\u2029'
    );
}

/* =========================================================
   DATE / TIME
========================================================= */

function pad(number) {
  return String(
    number
  ).padStart(
    2,
    '0'
  );
}

function parseTimestamp(value) {
  if (!value) {
    return null;
  }

  if (
    value instanceof Date
  ) {
    return Number.isNaN(
      value.getTime()
    )
      ? null
      : value;
  }

  if (
    typeof value === 'object'
  ) {
    if (
      typeof value.seconds ===
      'number'
    ) {
      return new Date(
        value.seconds * 1000 +
        Math.floor(
          (
            value.nanos ||
            value.nanoseconds ||
            0
          ) / 1000000
        )
      );
    }

    if (
      typeof value.epochSeconds ===
      'number'
    ) {
      return new Date(
        value.epochSeconds * 1000
      );
    }
  }

  if (
    typeof value === 'number'
  ) {
    return new Date(
      value < 1e12
        ? value * 1000
        : value
    );
  }

  const date =
    new Date(value);

  return Number.isNaN(
    date.getTime()
  )
    ? null
    : date;
}

function getLocalTimeZone() {
  return Intl.DateTimeFormat().resolvedOptions().timeZone || 'Local';
}

/*
 * Uses the machine/runtime local timezone automatically.
 * No timezone is hard-coded here.
 *
 * The function name is kept as formatIST for compatibility with
 * the existing dashboard/template data contract.
 */
function formatIST(date) {
  if (
    !(date instanceof Date) ||
    Number.isNaN(
      date.getTime()
    )
  ) {
    return '—';
  }

  return new Intl.DateTimeFormat(
    'en-GB',
    {
      year:
        'numeric',

      month:
        '2-digit',

      day:
        '2-digit',

      hour:
        '2-digit',

      minute:
        '2-digit',

      second:
        '2-digit',

      hour12:
        false
    }
  )
    .format(date)
    .replace(
      ',',
      ''
    );
}

/* Local machine date only. */
function formatISTDate(date) {
  if (
    !(date instanceof Date) ||
    Number.isNaN(
      date.getTime()
    )
  ) {
    return '—';
  }

  return new Intl.DateTimeFormat(
    'en-GB',
    {
      day:
        '2-digit',

      month:
        'short',

      year:
        'numeric'
    }
  ).format(date);
}

/* =========================================================
   DURATION
========================================================= */

function durationToMs(value) {
  if (value == null) {
    return 0;
  }

  if (
    typeof value === 'object'
  ) {
    if (
      typeof value.seconds ===
      'number'
    ) {
      return (
        value.seconds * 1000 +
        Math.floor(
          (
            value.nanos ||
            value.nanoseconds ||
            0
          ) / 1000000
        )
      );
    }

    if (
      typeof value.nanos ===
      'number'
    ) {
      return (
        value.nanos / 1000000
      );
    }

    return 0;
  }

  if (
    typeof value === 'number'
  ) {
    /*
     * Classic Cucumber JSON normally
     * stores duration in nanoseconds.
     */
    return value > 1e9
      ? value / 1000000
      : value;
  }

  return 0;
}

function formatDuration(ms) {
  ms = Math.max(
    0,
    Math.round(ms || 0)
  );

  const totalSeconds =
    Math.floor(
      ms / 1000
    );

  const hours =
    Math.floor(
      totalSeconds / 3600
    );

  const minutes =
    Math.floor(
      (totalSeconds % 3600) /
      60
    );

  const seconds =
    totalSeconds % 60;

  const milliseconds =
    ms % 1000;

  if (hours) {
    return (
      `${hours}h ` +
      `${pad(minutes)}m ` +
      `${pad(seconds)}s`
    );
  }

  if (minutes) {
    return (
      `${minutes}m ` +
      `${pad(seconds)}s`
    );
  }

  if (milliseconds) {
    return (
      `${seconds}.` +
      `${String(
        milliseconds
      )
        .padStart(
          3,
          '0'
        )
        .slice(
          0,
          2
        )}s`
    );
  }

  return `${seconds}s`;
}

/* =========================================================
   STATUS
========================================================= */

function normalizeStatus(status) {
  const value =
    String(
      status || ''
    ).toUpperCase();

  if (
    value === 'PASSED' ||
    value === 'PASS'
  ) {
    return 'Passed';
  }

  if (
    value === 'FAILED' ||
    value === 'FAIL' ||
    value === 'AMBIGUOUS'
  ) {
    return 'Failed';
  }

  if (
    value === 'SKIPPED' ||
    value === 'PENDING' ||
    value === 'UNDEFINED'
  ) {
    return 'Skipped';
  }

  return '';
}

/* =========================================================
   TAGS
========================================================= */

function getTags(item) {
  return Array.isArray(
    item?.tags
  )
    ? item.tags
    : [];
}

function tagNames(item) {
  return getTags(item)
    .map(tag => {
      if (
        typeof tag ===
        'string'
      ) {
        return tag.replace(
          /^@/,
          ''
        );
      }

      return String(
        tag?.name ||
        tag?.expression ||
        ''
      ).replace(
        /^@/,
        ''
      );
    })
    .filter(Boolean);
}

function findTag(
  item,
  regex
) {
  return tagNames(item).find(
    tag =>
      regex.test(tag)
  );
}

/* =========================================================
   COMPANY
========================================================= */

function companyFrom(
  scenario,
  feature
) {
  const tags = [
    ...tagNames(feature),
    ...tagNames(scenario)
  ];

  const knownCompanies = [
    'OV01',
    'OV02',
    'OV03',
    'SBL',
    'USME'
  ];

  const known =
    tags.find(
      tag =>
        knownCompanies.includes(
          tag.toUpperCase()
        )
    );

  if (known) {
    return known.toUpperCase();
  }

  const companyTag =
    tags.find(
      tag =>
        /^(company|cmp)[=_:-]/i.test(
          tag
        )
    );

  if (companyTag) {
    return companyTag
      .split(
        /[=_:-]/
      )
      .slice(1)
      .join('-')
      .toUpperCase();
  }

  return '';
}

/* =========================================================
   PRIORITY
========================================================= */

function priorityFrom(
  scenario,
  feature
) {
  const tags = [
    ...tagNames(feature),
    ...tagNames(scenario)
  ].map(
    tag =>
      tag.toLowerCase()
  );

  if (
    tags.includes(
      'critical'
    ) ||
    tags.includes(
      'priority-critical'
    ) ||
    tags.includes(
      'p0'
    )
  ) {
    return 'Critical';
  }

  if (
    tags.includes(
      'high'
    ) ||
    tags.includes(
      'priority-high'
    ) ||
    tags.includes(
      'p1'
    )
  ) {
    return 'High';
  }

  if (
    tags.includes(
      'low'
    ) ||
    tags.includes(
      'priority-low'
    ) ||
    tags.includes(
      'p3'
    )
  ) {
    return 'Low';
  }

  return 'Medium';
}

/* =========================================================
   MODULE
========================================================= */

function moduleFrom(
  scenario,
  feature
) {
  const tags = [
    ...tagNames(feature),
    ...tagNames(scenario)
  ];

  const moduleTag =
    tags.find(
      tag =>
        /^(module|area|service)[=_:-]/i.test(
          tag
        )
    );

  if (moduleTag) {
    return (
      moduleTag
        .split(
          /[=_:-]/
        )
        .slice(1)
        .join('-') ||
      'General'
    );
  }

  /*
   * If no module tag exists,
   * use the feature name.
   */
  return (
    cleanText(
      feature?.name ||
      scenario?.feature ||
      'General'
    ) ||
    'General'
  );
}

/* =========================================================
   SCENARIO / STEPS
========================================================= */

function scenarioName(item) {
  return cleanText(
    item?.name ||
    item?.description ||
    item?.title ||
    'Unnamed test case'
  );
}

function featureElements(
  feature
) {
  if (
    !Array.isArray(
      feature?.elements
    )
  ) {
    return [];
  }

  return feature.elements.filter(
    element => {
      const type =
        String(
          element?.type ||
          ''
        ).toLowerCase();

      return (
        type === 'scenario' ||
        type === 'background' ||
        !type
      );
    }
  );
}

function stepObjects(item) {
  const steps = [];

  if (
    Array.isArray(
      item?.steps
    )
  ) {
    steps.push(
      ...item.steps
    );
  }

  if (
    Array.isArray(
      item?.before
    )
  ) {
    steps.push(
      ...item.before
    );
  }

  if (
    Array.isArray(
      item?.after
    )
  ) {
    steps.push(
      ...item.after
    );
  }

  return steps;
}

function extractStepResult(
  step
) {
  if (!step) {
    return {};
  }

  if (
    Array.isArray(
      step.result
    )
  ) {
    return (
      step.result[0] ||
      {}
    );
  }

  return (
    step.result ||
    {}
  );
}

/* =========================================================
   SCENARIO STATUS
========================================================= */

function getScenarioStatus(
  item
) {
  const results =
    stepObjects(item)
      .map(
        extractStepResult
      );

  const statuses =
    results
      .map(
        result =>
          normalizeStatus(
            result.status
          )
      )
      .filter(Boolean);

  if (
    statuses.includes(
      'Failed'
    )
  ) {
    return 'Failed';
  }

  if (
    statuses.includes(
      'Passed'
    ) &&
    !statuses.includes(
      'Skipped'
    )
  ) {
    return 'Passed';
  }

  if (
    statuses.includes(
      'Skipped'
    )
  ) {
    return 'Skipped';
  }

  const direct =
    normalizeStatus(
      item?.status
    );

  return (
    direct ||
    'Skipped'
  );
}

/* =========================================================
   SCENARIO DURATION
========================================================= */

function getScenarioDurationMs(
  item
) {
  const direct =
    durationToMs(
      item?.duration
    );

  if (direct) {
    return direct;
  }

  return stepObjects(item)
    .reduce(
      (
        total,
        step
      ) =>
        total +
        durationToMs(
          extractStepResult(
            step
          ).duration
        ),
      0
    );
}

/* =========================================================
   SCENARIO START / END
========================================================= */

function getScenarioTimes(
  item
) {
  const starts = [];
  const ends = [];

  for (
    const step of stepObjects(
      item
    )
  ) {
    const result =
      extractStepResult(
        step
      );

    const start =
      parseTimestamp(
        step?.timestamp ||
        result?.timestamp ||
        step?.start ||
        result?.start
      );

    if (start) {
      starts.push(
        start
      );

      const duration =
        durationToMs(
          result?.duration
        );

      const end =
        new Date(
          start.getTime() +
          duration
        );

      if (
        !Number.isNaN(
          end.getTime()
        )
      ) {
        ends.push(
          end
        );
      }
    }
  }

  const directStart =
    parseTimestamp(
      item?.start ||
      item?.startTime ||
      item?.timestamp
    );

  const directEnd =
    parseTimestamp(
      item?.end ||
      item?.endTime
    );

  if (directStart) {
    starts.push(
      directStart
    );
  }

  if (directEnd) {
    ends.push(
      directEnd
    );
  }

  return {
    start:
      starts.length
        ? new Date(
            Math.min(
              ...starts.map(
                d =>
                  d.getTime()
              )
            )
          )
        : null,

    end:
      ends.length
        ? new Date(
            Math.max(
              ...ends.map(
                d =>
                  d.getTime()
              )
            )
          )
        : null
  };
}

/* =========================================================
   ERROR
========================================================= */

function extractError(
  item
) {
  const results =
    stepObjects(item)
      .map(
        extractStepResult
      );

  const failed =
    results.find(
      result =>
        normalizeStatus(
          result.status
        ) === 'Failed' &&
        (
          result.error_message ||
          result.message
        )
    );

  const source =
    failed ||
    results.find(
      result =>
        result.error_message ||
        result.message
    );

  if (!source) {
    return {
      name: '',
      message: ''
    };
  }

  const message =
    cleanText(
      source.error_message ||
      source.message ||
      ''
    );

  const nameMatch =
    message.match(
      /^(?:Error:\s*)?([A-Za-z_$][\w$]*(?:Error|Exception))(?::|\s|$)/
    );

  const name =
    cleanText(
      source.error_type ||
      source.exception_type ||
      (
        nameMatch
          ? nameMatch[1]
          : 'TestExecutionError'
      )
    );

  return {
    name,
    message
  };
}

/* =========================================================
   ARTIFACTS
========================================================= */

function extractArtifacts(
  item
) {
  const artifacts = {
    video: '',
    screenshot: ''
  };

  const candidates = [];

  function walk(
    value,
    key = ''
  ) {
    if (value == null) {
      return;
    }

    if (
      typeof value ===
      'string'
    ) {
      candidates.push({
        key,
        value
      });

      return;
    }

    if (
      Array.isArray(value)
    ) {
      value.forEach(
        v =>
          walk(
            v,
            key
          )
      );

      return;
    }

    if (
      typeof value ===
      'object'
    ) {
      for (
        const [
          k,
          v
        ] of Object.entries(
          value
        )
      ) {
        walk(
          v,
          k
        );
      }
    }
  }

  walk(item);

  for (
    const candidate of candidates
  ) {
    const value =
      cleanText(
        candidate.value
      );

    if (
      !value ||
      value.length > 2000
    ) {
      continue;
    }

    const key =
      candidate.key.toLowerCase();

    const lowerValue =
      value.toLowerCase();

    if (
      !artifacts.video &&
      (
        key.includes(
          'video'
        ) ||
        /\.(mp4|webm|mov)(\?|$)/i.test(
          lowerValue
        )
      )
    ) {
      artifacts.video =
        value;
    }

    if (
      !artifacts.screenshot &&
      (
        key.includes(
          'screenshot'
        ) ||
        /\.(png|jpe?g|webp)(\?|$)/i.test(
          lowerValue
        )
      )
    ) {
      artifacts.screenshot =
        value;
    }
  }

  return artifacts;
}

/* =========================================================
   SCENARIO -> DASHBOARD TEST CASE
========================================================= */

function scenarioToTestCase(
  feature,
  scenario,
  index
) {
  const status =
    getScenarioStatus(
      scenario
    );

  const durationMs =
    getScenarioDurationMs(
      scenario
    );

  const times =
    getScenarioTimes(
      scenario
    );

  const error =
    extractError(
      scenario
    );

  const artifacts =
    extractArtifacts(
      scenario
    );

  const uri =
    cleanText(
      feature?.uri ||
      feature?.location?.uri ||
      scenario?.uri ||
      ''
    );

  const fileName =
    uri
      ? path.basename(
          uri.replace(
            /\\/g,
            '/'
          )
        )
      : 'Not available';

  const featureName =
    cleanText(
      feature?.name ||
      'General'
    );

  const company =
    companyFrom(
      scenario,
      feature
    );

  const module =
    moduleFrom(
      scenario,
      feature
    );

  const priority =
    priorityFrom(
      scenario,
      feature
    );

  /*
   * Test case ID:
   *
   * @TC-1001
   * @test-case-id=1001
   * @test_case_id:1001
   */
  const explicitId =
    findTag(
      scenario,
      /^(?:TC-|test[-_]?case[-_]?id[=_:-])/i
    );

  let id = '';

  if (explicitId) {
    id =
      explicitId.replace(
        /^test[-_]?case[-_]?id[=_:-]/i,
        ''
      );

    if (
      !/^TC-/i.test(
        id
      )
    ) {
      id =
        `TC-${id}`;
    }
  }

  if (!id) {
    id =
      `TC-${String(
        index + 1
      ).padStart(
        4,
        '0'
      )}`;
  }

  const statusDetails =
    status === 'Passed'
      ? 'Execution completed successfully.'
      : status === 'Failed'
        ? (
            error.message
              ? 'Execution failed. See the error details and artifacts.'
              : 'Execution failed.'
          )
        : 'Execution skipped or was not executed.';

  return {
    id,

    name:
      scenarioName(
        scenario
      ),

    detail:
      featureName,

    section:
      featureName,

    company,

    fileName,

    testCaseFileName:
      fileName,

    module,

    priority,

    status,

    statusDetails,

    duration:
      formatDuration(
        durationMs
      ),

    durationMs,

    startRun:
      formatIST(
        times.start
      ),

    endRun:
      formatIST(
        times.end
      ),

    lastRun:
      formatIST(
        times.end ||
        new Date()
      ),

    errorName:
      error.name,

    error:
      error.message,

    video:
      artifacts.video,

    screenshot:
      artifacts.screenshot
  };
}

/* =========================================================
   CLASSIC CUCUMBER JSON
========================================================= */

function parseClassicCucumberJson(
  report
) {
  const features =
    Array.isArray(report)
      ? report
      : [];

  const cases = [];

  let counter = 0;

  for (
    const feature of features
  ) {
    for (
      const scenario of featureElements(
        feature
      )
    ) {
      const type =
        String(
          scenario?.type ||
          ''
        ).toLowerCase();

      if (
        type ===
        'background'
      ) {
        continue;
      }

      cases.push(
        scenarioToTestCase(
          feature,
          scenario,
          counter++
        )
      );
    }
  }

  return cases;
}

/* =========================================================
   MESSAGE FORMAT FALLBACK
========================================================= */

function parseMessageLikeJson(
  report
) {
  const cases = [];

  const messages =
    Array.isArray(report)
      ? report
      : Array.isArray(
          report?.messages
        )
        ? report.messages
        : [];

  const finished =
    messages.filter(
      message =>
        message &&
        message.testCaseFinished
    );

  finished.forEach(
    (
      message,
      index
    ) => {
      const finishedCase =
        message.testCaseFinished ||
        {};

      const started =
        messages.find(
          item =>
            item?.testCaseStarted?.id ===
            finishedCase.testCaseStartedId
        )?.testCaseStarted;

      const testCase =
        messages.find(
          item =>
            item?.testCase?.id ===
            started?.testCaseId
        )?.testCase;

      const name =
        cleanText(
          testCase?.name ||
          `Test case ${index + 1}`
        );

      const status =
        normalizeStatus(
          finishedCase?.status
        ) ||
        'Skipped';

      cases.push({
        id:
          `TC-${String(
            index + 1
          ).padStart(
            4,
            '0'
          )}`,

        name,

        detail:
          cleanText(
            testCase?.uri ||
            'Cucumber test case'
          ),

        section:
          cleanText(
            testCase?.uri ||
            'Cucumber test case'
          ),

        company: '',

        fileName:
          path.basename(
            String(
              testCase?.uri ||
              'Not available'
            )
          ),

        testCaseFileName:
          path.basename(
            String(
              testCase?.uri ||
              'Not available'
            )
          ),

        module:
          'General',

        priority:
          'Medium',

        status,

        statusDetails:
          status === 'Passed'
            ? 'Execution completed successfully.'
            : 'Execution completed.',

        duration:
          '0s',

        durationMs:
          0,

        startRun:
          '—',

        endRun:
          '—',

        lastRun:
          formatIST(
            new Date()
          ),

        errorName:
          '',

        error:
          '',

        video:
          '',

        screenshot:
          ''
      });
    }
  );

  return cases;
}

/* =========================================================
   REPORT PARSER
========================================================= */

function parseReport(
  report
) {
  if (
    Array.isArray(report)
  ) {
    const classic =
      parseClassicCucumberJson(
        report
      );

    if (
      classic.length
    ) {
      return classic;
    }
  }

  return parseMessageLikeJson(
    report
  );
}

/* =========================================================
   RUN INFORMATION
========================================================= */

function collectDates(
  cases
) {
  const starts =
    cases
      .map(
        c =>
          parseTimestamp(
            c.startRun
          )
      )
      .filter(Boolean);

  const ends =
    cases
      .map(
        c =>
          parseTimestamp(
            c.endRun
          )
      )
      .filter(Boolean);

  return {
    starts,
    ends
  };
}

/*
 * =========================================================
 * ACTUAL AUTOMATION START
 * =========================================================
 *
 * This function reads:
 *
 *     reports/run-start.json
 *
 * which is created BEFORE Cucumber starts by:
 *
 *     run-tests-and-dashboard.js
 *
 * This prevents the old Cucumber timestamp from being
 * incorrectly displayed as the current run start.
 */
function getRecordedRunStart() {
  try {
    if (
      !fs.existsSync(
        runStartPath
      )
    ) {
      return null;
    }

    const data =
      readJson(
        runStartPath
      );

    const date =
      parseTimestamp(
        data?.startedAt
      );

    if (
      date &&
      !Number.isNaN(
        date.getTime()
      )
    ) {
      return date;
    }

    return null;
  } catch (error) {
    console.warn(
      'Unable to read run-start.json:',
      error.message
    );

    return null;
  }
}

/*
 * =========================================================
 * ACTUAL AUTOMATION END
 * =========================================================
 *
 * This function reads:
 *
 *     reports/run-end.json
 *
 * which is created immediately after Cucumber finishes.
 */
function getRecordedRunEnd() {
  try {
    if (
      !fs.existsSync(
        runEndPath
      )
    ) {
      return null;
    }

    const data =
      readJson(
        runEndPath
      );

    const date =
      parseTimestamp(
        data?.finishedAt
      );

    if (
      date &&
      !Number.isNaN(
        date.getTime()
      )
    ) {
      return date;
    }

    return null;
  } catch (error) {
    console.warn(
      'Unable to read run-end.json:',
      error.message
    );

    return null;
  }
}

/*
 * =========================================================
 * BUILD RUN INFORMATION
 * =========================================================
 *
 * Priority:
 *
 * RUN START:
 *     1. run-start.json
 *     2. Cucumber scenario timestamps
 *     3. generatedAt
 *
 * RUN END:
 *     1. run-end.json
 *     2. generatedAt
 *
 * DURATION:
 *     actual run end - actual run start
 *
 * IMPORTANT:
 *     We DO NOT use cucumber-report.json birthtime
 *     as the current run start.
 */
function buildRunInformation(
  cases,
  generatedAt,
  inputStat
) {
  const dates =
    collectDates(
      cases
    );

  const recordedRunStart =
    getRecordedRunStart();

  const recordedRunEnd =
    getRecordedRunEnd();

  const totalDurationMs =
    cases.reduce(
      (
        total,
        test
      ) =>
        total +
        (
          test.durationMs ||
          0
        ),
      0
    );

  /*
   * Actual automation start.
   *
   * run-start.json has highest priority.
   */
  let start =
    recordedRunStart;

  if (!start) {
    if (
      dates.starts.length
    ) {
      start =
        new Date(
          Math.min(
            ...dates.starts.map(
              date =>
                date.getTime()
            )
          )
        );
    } else {
      /*
       * Last-resort fallback.
       *
       * We intentionally do NOT use
       * inputStat.birthtimeMs because
       * that can represent an old report.
       */
      start =
        new Date(
          generatedAt.getTime() -
          totalDurationMs
        );
    }
  }

  /*
   * Actual automation end.
   *
   * run-end.json has highest priority.
   */
  let end =
    recordedRunEnd;

  if (!end) {
    /*
     * If no run-end.json exists,
     * use the dashboard generation time.
     */
    end =
      generatedAt;
  }

  /*
   * Calculate real elapsed automation time.
   */
  let durationMs =
    end.getTime() -
    start.getTime();

  /*
   * Prevent negative duration.
   */
  durationMs =
    Math.max(
      0,
      durationMs
    );

  /*
   * If no recorded run start/end exists
   * and timestamps are unavailable, use
   * accumulated scenario duration.
   */
  if (
    !recordedRunStart &&
    !recordedRunEnd &&
    durationMs <= 0 &&
    totalDurationMs > 0
  ) {
    durationMs =
      totalDurationMs;
  }

  const passed =
    cases.filter(
      test =>
        test.status ===
        'Passed'
    ).length;

  const failed =
    cases.filter(
      test =>
        test.status ===
        'Failed'
    ).length;

  const skipped =
    cases.filter(
      test =>
        test.status ===
        'Skipped'
    ).length;

  const status =
    failed > 0
      ? `Completed — ${failed} failed`
      : `Completed — ${passed} passed`;

  return {
    runStartedIST:
      formatIST(
        start
      ),

    runFinishedIST:
      formatIST(
        end
      ),

    totalDuration:
      formatDuration(
        durationMs
      ),

    totalDurationMs:
      durationMs,

    dashboardGeneratedIST:
      formatIST(
        generatedAt
      ),

    playwrightStatus:
      status,

    environment:
      process.env.TEST_ENV ||
      process.env.ENVIRONMENT ||
      process.env.NODE_ENV ||
      'QA',

    timeZone:
      getLocalTimeZone(),

    totalTests:
      cases.length,

    passed,

    failed,

    skipped
  };
}

/* =========================================================
   RECENT ACTIVITY
========================================================= */

function buildActivity(
  cases,
  runInfo,
  generatedAt
) {
  const activity = [];

  const total =
    cases.length;

  activity.push({
    type:
      runInfo.failed > 0
        ? 'red'
        : 'green',

    text:
      `Latest test run completed — ` +
      `${runInfo.passed}/${total} passed`,

    time:
      formatIST(
        generatedAt
      )
  });

  cases
    .filter(
      test =>
        test.status ===
        'Failed'
    )
    .slice(
      0,
      3
    )
    .forEach(
      test => {
        activity.push({
          type:
            'red',

          text:
            `Failure detected: ${test.name}` +
            (
              test.company
                ? ` [${test.company}]`
                : ''
            ),

          time:
            test.lastRun
        });
      }
    );

  cases
    .filter(
      test =>
        test.status ===
        'Passed'
    )
    .slice(
      0,
      Math.max(
        0,
        5 -
        activity.length
      )
    )
    .forEach(
      test => {
        activity.push({
          type:
            'green',

          text:
            `${test.id} Passed — ${test.name}` +
            (
              test.company
                ? ` [${test.company}]`
                : ''
            ),

          time:
            test.lastRun
        });
      }
    );

  return activity.slice(
    0,
    5
  );
}

/* =========================================================
   HISTORY
========================================================= */

function loadHistory() {
  /*
   * Historical dashboard runs are intentionally not loaded.
   * Every dashboard represents ONLY the current execution.
   */
  return [];
}

function updateHistory(
  runInfo,
  generatedAt
) {
  const passRate =
    runInfo.totalTests > 0
      ? Number(
          (
            (
              runInfo.passed /
              runInfo.totalTests
            ) *
            100
          ).toFixed(1)
        )
      : 0;

  /*
   * IMPORTANT:
   * Only the current run is returned.
   * Previous dashboard-history.json data is never used.
   */
  return [
    {
      date:
        formatISTDate(
          generatedAt
        ),

      timestamp:
        generatedAt.toISOString(),

      passRate,

      totalTests:
        runInfo.totalTests,

      passed:
        runInfo.passed,

      failed:
        runInfo.failed,

      skipped:
        runInfo.skipped
    }
  ];
}

function buildTrend(
  history
) {
  if (
    !history.length
  ) {
    return {
      labels: [
        formatISTDate(
          new Date()
        )
      ],

      values: [
        0
      ]
    };
  }

  return {
    labels:
      history.map(
        item =>
          item.date
      ),

    values:
      history.map(
        item =>
          Number(
            item.passRate
          ) || 0
      )
  };
}

function buildCoverage() {
  const candidates = [
    path.resolve(ROOT, 'coverage-summary.json'),
    path.resolve(ROOT, 'test-results', 'coverage-summary.json')
  ];
  const file = candidates.find(fs.existsSync);
  if (!file) return { overall: 0, units: 0, integration: 0, e2e: 0 };
  try {
    const total = readJson(file).total || {};
    const lines = Number(total.lines?.pct);
    const statements = Number(total.statements?.pct);
    const branches = Number(total.branches?.pct);
    const values = [lines, statements, branches].filter(Number.isFinite);
    const overall = values.length ? Number((values.reduce((a,b)=>a+b,0)/values.length).toFixed(1)) : 0;
    return { overall, units: Number.isFinite(statements) ? statements : overall, integration: Number.isFinite(branches) ? branches : overall, e2e: Number.isFinite(lines) ? lines : overall };
  } catch {
    return { overall: 0, units: 0, integration: 0, e2e: 0 };
  }
}

/* =========================================================
   TEMPLATE INJECTION
========================================================= */

function injectDashboardData(templateHtml, dashboardData) {
  const json = JSON.stringify(dashboardData, null, 2)
    .replace(/</g, "\\u003c")
    .replace(/>/g, "\\u003e")
    .replace(/&/g, "\\u0026");

  const pattern =
    /window\.__DASHBOARD_DATA__\s*=\s*\{\};/;

  if (!pattern.test(templateHtml)) {
    throw new Error(
      "dashboard_template.html must contain:\n\n" +
      "window.__DASHBOARD_DATA__ = {};"
    );
  }

  return templateHtml.replace(
    pattern,
    `window.__DASHBOARD_DATA__ = ${json};`
  );
}

/* =========================================================
   MAIN
========================================================= */

function main() {
  console.log('');

  console.log(
    '=============================================='
  );

  console.log(
    ' ORKLA PLAYWRIGHT QA DASHBOARD GENERATOR'
  );

  console.log(
    '=============================================='
  );

  console.log('');

  /*
   * =======================================================
   * CHECK CUCUMBER JSON
   * =======================================================
   */

  if (
    !fs.existsSync(
      inputPath
    )
  ) {
    throw new Error(
      `Cucumber JSON report not found:\n${inputPath}\n\nRun Cucumber first:\nnpx cucumber-js`
    );
  }

  /*
   * =======================================================
   * CHECK DASHBOARD TEMPLATE
   * =======================================================
   */

  if (
    !fs.existsSync(
      templatePath
    )
  ) {
    throw new Error(
      `Dashboard template not found:\n${templatePath}`
    );
  }

  /*
   * =======================================================
   * CLEAR PREVIOUS DASHBOARD HISTORY
   * =======================================================
   *
   * The dashboard must never display data from a previous run.
   * The history file is deleted before generating this run.
   */
  if (
    fs.existsSync(
      historyPath
    )
  ) {
    try {
      fs.unlinkSync(
        historyPath
      );
    } catch (error) {
      console.warn(
        'Unable to remove previous dashboard history:',
        error.message
      );
    }
  }

  /*
   * =======================================================
   * READ REPORT
   * =======================================================
   */

  const report =
    readJson(
      inputPath
    );

  /*
   * =======================================================
   * READ TEMPLATE
   * =======================================================
   */

  const template =
    fs.readFileSync(
      templatePath,
      'utf8'
    );

  /*
   * =======================================================
   * VERIFY DASHBOARD CONTRACT
   * =======================================================
   */

  /*
   * =======================================================
   * GENERATE DATA
   * =======================================================
   */

  const generatedAt =
    new Date();

  /*
   * Kept for compatibility with the existing function.
   * It is NO LONGER used as the current run start.
   */
  const inputStat =
    fs.statSync(
      inputPath
    );

  const testCases =
    parseReport(
      report
    );

  /*
   * =======================================================
   * RUN INFORMATION
   * =======================================================
   *
   * IMPORTANT:
   * This now reads the actual start/end timestamps
   * recorded by run-tests-and-dashboard.js.
   */

  const runInformation =
    buildRunInformation(
      testCases,
      generatedAt,
      inputStat
    );

  /*
   * =======================================================
   * RECENT ACTIVITY
   * =======================================================
   */

  const activity =
    buildActivity(
      testCases,
      runInformation,
      generatedAt
    );

  /*
   * =======================================================
   * HISTORY
   * =======================================================
   */

  const history =
    updateHistory(
      runInformation,
      generatedAt
    );

  /*
   * =======================================================
   * TREND DATA
   * =======================================================
   */

  const trendData =
    buildTrend(
      history
    );

  /*
   * =======================================================
   * SAVE HISTORY
   * =======================================================
   */

  writeJson(
    historyPath,
    history
  );

  /*
   * =======================================================
   * INJECT DASHBOARD DATA
   * =======================================================
   */

  const dashboardData = {
    testCases,
    activity,
    runInformation,
    coverage: buildCoverage(),
    trend: trendData,
    statistics: {
      total: runInformation.totalTests,
      passed: runInformation.passed,
      failed: runInformation.failed,
      skipped: runInformation.skipped,
      executed: runInformation.passed + runInformation.failed,
      passRate: runInformation.totalTests > 0
        ? Number(((runInformation.passed / runInformation.totalTests) * 100).toFixed(1))
        : 0,
      totalDuration: runInformation.totalDurationMs
    }
  };

  const dashboard = injectDashboardData(template, dashboardData);

  /*
   * =======================================================
   * ATOMIC DASHBOARD WRITE
   * =======================================================
   */

  ensureDir(
    outputPath
  );

  const temporaryPath =
    `${outputPath}.tmp`;

  fs.writeFileSync(
    temporaryPath,
    dashboard,
    'utf8'
  );

  fs.renameSync(
    temporaryPath,
    outputPath
  );

  /*
   * =======================================================
   * CONSOLE SUMMARY
   * =======================================================
   */

  const passRate =
    runInformation.totalTests > 0
      ? (
          (
            runInformation.passed /
            runInformation.totalTests
          ) *
          100
        ).toFixed(
          1
        )
      : '0.0';

  console.log(
    'Dashboard generated successfully.'
  );

  console.log(
    `Input:       ${inputPath}`
  );

  console.log(
    `Template:    ${templatePath}`
  );

  console.log(
    `Output:      ${outputPath}`
  );

  console.log(
    `Test Cases:  ${runInformation.totalTests}`
  );

  console.log(
    `Passed:      ${runInformation.passed}`
  );

  console.log(
    `Failed:      ${runInformation.failed}`
  );

  console.log(
    `Skipped:     ${runInformation.skipped}`
  );

  console.log(
    `Pass Rate:   ${passRate}%`
  );

  console.log(
    `Run Start:   ${runInformation.runStartedIST}`
  );

  console.log(
    `Run End:     ${runInformation.runFinishedIST}`
  );

  console.log(
    `Duration:    ${runInformation.totalDuration}`
  );

  console.log(
    `Generated:   ${runInformation.dashboardGeneratedIST}`
  );

  console.log(
    `Time Zone:   ${runInformation.timeZone}`
  );

  console.log(
    '=============================================='
  );

  console.log('');
}

/* =========================================================
   EXECUTE
========================================================= */

try {
  main();
} catch (error) {
  console.error('');

  console.error(
    'Dashboard generation failed.'
  );

  console.error(
    error.message
  );

  console.error('');

  process.exitCode = 1;
}