@echo off
cd /d "C:\Users\Userda57ac9a84f\Desktop\AUTOMATION DASHBOARD\orkla_playwright"

set "PATH=C:\Program Files\nodejs;%PATH%"

"C:\Program Files\nodejs\npm.cmd" run test:dashboard

pause