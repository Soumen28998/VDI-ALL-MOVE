//create test
import { test, expect } from '@playwright/test';


test.describe('General Ledger (GL) Tests', () => {


});


test('Prorams and features', async () => {

        let str="satya";
        let char="";
        console.log("Original string is:"+str);
        for(let i=str.length-1;i>=0;i--){
          char=char+str.charAt(i);
          //console.log(str[i]);
        }
        console.log("Reveresed a string is:"+char);

        let num=123;
        let rev=0;

while(num>0){
 let x=num%10;
 rev=rev*10+x;
 num=Math.floor(num/10);
}
console.log("Reversed number is:"+rev);

let num1=5;
let num2=10;

console.log(""+num1+" "+num2);
num1=num1+num2;
num2=num1-num2;
num1=num1-num2;
console.log(""+num1+" "+num2);

let n1=1;
let n2=2;
let temp=0;
console.log(""+n1+" "+n2);
temp=n1;
n1=n2;
n2=temp;
console.log(""+n1+" "+n2);

//fibonacci series
let x=10;
let f1=0;
let f2=1;
let f3=f1+f2;
console.log("Fibonacci series:");
console.log(f1);
console.log(f2);  

for(let i=2;i<x;i++){
  console.log(f3);
  f1=f2;
  f2=f3;
  f3=f1+f2;
}

//factorial of a number
function factorial(num:number):number{
  if(num==0 || num==1){
    return 1;
  }else{
    return num*factorial(num-1);
  }
}
console.log("Factorial of 5 is:"+factorial(5));

// prime number
function isPrime(num:number):boolean{
  if(num<=1){ 
    return false;
  } 
  for(let i=2;i<=Math.sqrt(num);i++){
    if(num%i==0){
      return false;
    }
  }
  return true;
} 
console.log("Is 7 a prime number? "+isPrime(7));

// prime number generator
function generatePrimes(limit:number):number[]{
  let primes:number[]=[];
  for(let i=2;i<=limit;i++){
    if(isPrime(i)){
      primes.push(i);
    }
  }
  return primes;
} 







      });


