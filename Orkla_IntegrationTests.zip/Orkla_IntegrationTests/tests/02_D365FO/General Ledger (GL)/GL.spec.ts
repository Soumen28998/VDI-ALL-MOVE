import { test, expect } from '@playwright/test';
import { BasePage } from '../../../pages/BasePage';
import { GeneralJournalPage } from '../../../pages/GeneralJournalPage';
import { ENV } from '../../../utils/env';
import { timeStamp } from 'node:console';


test.describe('General Ledger (GL) Tests', () => {
  let basePage: BasePage;
  let glPage: GeneralJournalPage;
    test.beforeEach(async ({ page }) => {
    basePage = new BasePage(page);
    glPage = new GeneralJournalPage(page);
    
  });
//GLTC001 – Verify GL Parameters Setup
    test('GL01_Verify GL Parameters Setup', async ({ page }) => {

        await test.step('Open URL '+ENV.baseUrl, async () => {
        await basePage.navigateByUrl(ENV.baseUrl, "ImmersiveHome");
        });
        //await glPage.goto();  
        await test.step('Go to "General ledger parameters"', async () => {
        await basePage.navigateTo('General ledger', 'Ledger setup', 'General ledger parameters');
        });
        // Add assertions to verify GL parameters setup
        await test.step('Verify General ledger parameters form', async () => {
        await expect(page.locator('span.formCaption', { hasText: 'General ledger parameters' })).toBeVisible({ timeout: 15000 });  
      });

        await test.step('Verify Number Sequence Tab', async () => {
        await page.locator('li[data-dyn-controlname="NumberSeqTab_header"]').click();
        await expect(page.locator('input[value="Journal"]').first()).toBeVisible();
        await expect(page.locator('input[value="Journal batch number"]').first()).toBeVisible();
        });

});




//Test data
const MainAccounttestData = {
  // need to increment this  number everytime when we run the test to avoid duplicate main account issue, as our internal env not allowing to delete the created main account    
    mainAccount: '9000'+Math.floor(1000 + Math.random() * 9000).toString(),  
    accountName: 'Automation Test Expense',
    mainaccountType: 'Total'
};
//TC_GL_001 – Create New Main Account
    test('GL_002_Create New Main Account', async ({ page }) => {

        await test.step('Open URL '+ENV.baseUrl, async () => {
        await basePage.navigateByUrl(ENV.baseUrl, "ImmersiveHome");
        });
        await basePage.navigateTo('General ledger', 'Chart of accounts', 'Accounts', 'Main accounts');
        await basePage.newBtnClick();
        await glPage.mainAccountNumber(MainAccounttestData.mainAccount);
        await glPage.accountName(MainAccounttestData.accountName);
        await page.waitForTimeout(4000);
        await basePage.selectLookup('Main account type', MainAccounttestData.mainaccountType);
        await page.waitForTimeout(4000);
        await basePage.saveBtnClick();
        
        await test.step('Verify main account creation', async () => {
        // Add assertions to verify main account creation 
        let GetAccountNum = await page.locator('input[name="DetailAccountNum"]').inputValue();
        console.log('Created Main Account Number:', GetAccountNum);
        expect(GetAccountNum).toEqual(MainAccounttestData.mainAccount);
         });

        
      }); 

    

    //TC_GL_002 – Create General Journal and Post
    test('GL_003_Create General Journal and Post', async ({ page }) => {

        await test.step('Open URL '+ENV.baseUrl, async () => {
        await basePage.navigateByUrl(ENV.baseUrl, "ImmersiveHome");
        });
        await basePage.navigateTo('General ledger', 'Journal entries', 'General journals');
        //await basePage.newBtnClick();
       await test.step('Create new general journal', async () => {
       await page.getByRole('button', { name: ' New' }).click();
       await page.getByRole('combobox', { name: 'Name' }).fill('GenJrn');
       await page.getByRole('combobox', { name: 'Name' }).press('Tab');
       await page.getByRole('button', { name: ' Save' }).click();
       await page.getByRole('button', { name: 'Lines', exact: true }).click();
       await page.waitForTimeout(3000);
       await page.getByRole('combobox', { name: 'Account', exact: true }).click();
       await page.locator('#LedgerJournalTrans_AccountNum_0_segmentedEntryLookup_input').fill('110110');
       await page.locator('#LedgerJournalTrans_AccountNum_0_segmentedEntryLookup_input').press('Tab');
       await page.getByRole('textbox', { name: 'Credit' }).click();
       await page.getByRole('textbox', { name: 'Credit' }).pressSequentially('1000',{ delay: 200 });
       await page.getByRole('textbox', { name: 'Credit' }).press('Tab');
       //await page.getByRole('combobox', { name: 'Offset account type' }).selectOption('LedgerAccount');
        await page.waitForTimeout(2000);
       //await page.getByRole('combobox', { name: 'Offset account' }).click();
       await page.locator('#LedgerJournalTrans_OffsetAccount_0_segmentedEntryLookup_input').fill('110120'); 
       await page.locator('#LedgerJournalTrans_OffsetAccount_0_segmentedEntryLookup_input').press('Tab');
       await page.getByRole('button', { name: ' Save' }).click();
       await page.waitForTimeout(4000);
       await test.step('Post the journal', async () => {
       await page.getByRole('button', { name: 'Post' }).first().click();
       //await page.getByRole('button', { name: 'OK' }).click();
       await page.waitForTimeout(4000);
        // Add assertions to verify journal posting
        
        //const message = await page.locator('(//span[@class="messageBar-message"])[1]').textContent();
        //console.log(message);
        const message = await page.locator("span.messageBar-message").first().innerText();
        console.log(message);
       await expect(message).toContain('Operation completed');
         });


        });       
        //await glPage.createNewJournal('GenJrn');
        //await glPage.journalType('Daily');
        await basePage.saveBtnClick();
        // Add steps to create journal lines and post the journal
        // Add assertions to verify journal creation and posting
      });


      //TC_GL_003 – Validate Journal with Missing Offset Account (Negative Test)
      test('GL_004_Validate Journal with Missing Offset Account', async ({ page }) => {

        await test.step('Open URL '+ENV.baseUrl, async () => {
        await basePage.navigateByUrl(ENV.baseUrl, "ImmersiveHome");
        });
        await basePage.navigateTo('General ledger', 'Journal entries', 'General journals');
        await test.step('Create new general journal', async () => {
       await page.getByRole('button', { name: ' New' }).click();
       await page.getByRole('combobox', { name: 'Name' }).fill('GenJrn');
       await page.getByRole('combobox', { name: 'Name' }).press('Tab');
       await page.getByRole('button', { name: ' Save' }).click();
        });
       await page.getByRole('button', { name: 'Lines', exact: true }).click();
       await page.waitForTimeout(3000);
       
        await page.getByRole('combobox', { name: 'Account', exact: true }).click();
        await page.locator('#LedgerJournalTrans_AccountNum_0_segmentedEntryLookup_input').fill('110110');
        await page.locator('#LedgerJournalTrans_AccountNum_0_segmentedEntryLookup_input').press('Tab');
        await page.getByRole('textbox', { name: 'Debit' }).click();
        await page.getByRole('textbox', { name: 'Debit' }).pressSequentially('1000',{ delay: 200 });
        await page.getByRole('textbox', { name: 'Debit' }).press('Tab');
        await page.waitForTimeout(2000);
        await page.getByRole('button', { name: ' Save' }).click();
        await page.waitForTimeout(2000);
        await page.getByRole('button', { name: 'Validate' }).click();
        await page.locator('span.button-label:has-text("Validate")').nth(2).click();


        });

      //TC_GL_003 – Validate Journal with Missing Offset Account (Negative Test)
      test('TC_005 – Reverse Posted General Journal', async ({ page }) => {

        await test.step('Open URL '+ENV.baseUrl, async () => {
        await basePage.navigateByUrl(ENV.baseUrl, "ImmersiveHome");
        });
        await basePage.navigateTo('General ledger', 'Journal entries', 'Posted General Journals');


      });

    
    
    
    });




