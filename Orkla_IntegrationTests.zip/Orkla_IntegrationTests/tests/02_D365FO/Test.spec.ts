import { test, expect } from '@playwright/test';

// Testcase: Create a Sales order in Dynamics 365
test('Create a Sales Order in Dynamics 365', async ({ page }) => {
  // 1. Go to the login page
  await page.goto('https://acumant-poc.sandbox.operations.dynamics.com/?cmp=USMF&mi=ImmersiveHome');
  
  // 2. Enter Email
  await page.getByPlaceholder('Email, phone, or Skype').fill('Chitikireddy@acumant.com');
  await page.getByRole('button', { name: 'Next' }).click();

  // 3. Enter Password
  await page.getByPlaceholder('Password').fill('Satya@3615');
  await page.getByRole('button', { name: 'Sign in' }).click();

  // 4. Click Yes on Stay signed in
  const yesButton = page.getByRole('button', { name: 'Yes' });
  if (await yesButton.isVisible()) {
    await yesButton.click();
  }

  // 5. Wait for Welcome message
  await expect(page.getByText('Welcome')).toBeVisible({ timeout: 60000 });

  // 6. Click Module icon in left navigation pane
  await page.getByLabel('Show navigation pane').click();

  // 7. Click Account receivable > All sales orders
  await page.getByRole('treeitem', { name: 'Accounts receivable' }).click();
  await page.getByRole('treeitem', { name: 'All sales orders' }).click();
  await expect(page.getByText('All sales orders')).toBeVisible({ timeout: 30000 });

  // 8. Click New button
  await page.getByRole('button', { name: 'New' }).click();
  await expect(page.getByText('Create sales order')).toBeVisible({ timeout: 15000 });

  // 9. Input customer account
  await page.getByLabel('Customer account').fill('US-002');
  await page.keyboard.press('Tab');
  await page.waitForTimeout(2000);

  // 10. Click OK in Create sales order dialog
  await page.getByRole('button', { name: 'OK' }).click();
  await page.waitForTimeout(3000);

  // 11. Input item number
  await page.getByLabel('Item number').fill('D0001');
  await page.keyboard.press('Tab');
  await page.waitForTimeout(2000);

  // 12. Input Warehouse
  await page.getByLabel('Warehouse').fill('11');
  await page.keyboard.press('Tab');
  await page.waitForTimeout(2000);

  // 13. Click Save button
  await page.getByRole('button', { name: 'Save' }).click();
  // If any popup, click OK
  const okPopup = page.getByRole('button', { name: 'OK' });
  if (await okPopup.isVisible()) {
    await okPopup.click();
  }

  // 14. Click Complete in Action menu and OK
  await page.getByRole('menuitem', { name: 'Complete' }).click();
  await page.getByRole('button', { name: 'OK' }).click();

  // 15. Click Sell from Action Menu
  await page.getByRole('menuitem', { name: 'Sell' }).click();

  // 16. Click Confirm sales order
  await page.getByRole('menuitem', { name: 'Confirm sales order' }).click();

  // 17. Wait for 5 seconds
  await page.waitForTimeout(5000);

  // 18. Verify Operation completed message
  await expect(page.getByText('Operation completed')).toBeVisible({ timeout: 15000 });
});




test('Create Sales Order in D365', async ({ page }) => {
  // 1. Open browser and navigate to URL
  await page.goto('https://acumant-poc.sandbox.operations.dynamics.com/?cmp=USMF&mi=ImmersiveHome');

  // 2. Enter Email
  await page.getByPlaceholder('Email, phone, or Skype').fill('Chitikireddy@acumant.com');
  await page.getByRole('button', { name: 'Next' }).click();

  // 3. Enter Password
  await page.getByPlaceholder('Password').fill('Satya@3615');
  await page.getByRole('button', { name: 'Sign in' }).click();

  // 4. Click Yes on Stay signed in
  await page.getByRole('button', { name: 'Yes' }).click();

  // 5. Wait for Welcome message
  await expect(page.getByRole('heading', { name: /Welcome/i })).toBeVisible({ timeout: 60000 });

  // 6. Click Modules in left navigation
  await page.getByRole('treeitem', { name: 'Modules' }).click();

  // 7. Click Accounts receivable
  await page.getByRole('treeitem', { name: 'Accounts receivable' }).click();

  // 8. Click All sales orders
  await page.getByRole('link', { name: 'All sales orders' }).click();
  await page.waitForTimeout(10000); // Wait for page to load

  // 9. Click New button
  await page.getByRole('button', { name: /New/ }).first().click();
  await page.waitForTimeout(5000); // Wait for dialog

  // 10. Enter Customer account
  const custInput = await page.waitForSelector('input[name="SalesTable_CustAccount"]', { timeout: 10000 });
  await custInput.evaluate((el) => el.removeAttribute('readonly'));
  await custInput.fill('US-002');
  await custInput.press('Tab');
  await page.waitForTimeout(3000);

  // 11. Click OK in Create sales order dialog
  await page.getByRole('button', { name: /^OK$/i }).click();
  await page.waitForTimeout(5000);
  //aria-label="Item number"

  // 12. Enter Item number
  const itemInput = await page.waitForSelector('input[name^="SalesLine_ItemId"]', { timeout: 10000 });
  await itemInput.fill('D0001');
  await itemInput.press('Tab');
  await page.waitForTimeout(3000);

  // 13. Enter Warehouse
  const warehouseInput = await page.waitForSelector('input[name^="SalesLine_InventLocationId"]', { timeout: 10000 });
  await warehouseInput.fill('11');
  await warehouseInput.press('Tab');
  await page.waitForTimeout(3000);

  // 14. Click Save button
  await page.getByRole('button', { name: /^Save$/i }).click();
  await page.waitForTimeout(3000);
  // If popup, click OK
  const popupOk = await page.$('button:has-text("OK")');
  if (popupOk) await popupOk.click();

  // 15. Click Complete in Action menu and OK
  await page.getByRole('button', { name: /Complete/i }).click();
  const completeOk = await page.$('button:has-text("OK")');
  if (completeOk) await completeOk.click();

  // 16. Click Sell from Action Menu
  await page.getByRole('button', { name: /Sell/i }).click();

  // 17. Click Confirm sales order
  await page.getByRole('button', { name: /Confirm sales order/i }).click();

  // 18. Wait for 5 seconds
  await page.waitForTimeout(5000);

  // 19. Verify Operation completed message
  await expect(page.getByText(/Operation completed/i)).toBeVisible({ timeout: 20000 });
});
