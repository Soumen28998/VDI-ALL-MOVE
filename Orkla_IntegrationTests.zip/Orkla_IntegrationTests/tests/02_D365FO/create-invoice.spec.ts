import { test, expect } from '@playwright/test';
import { InvoicingPage } from '../../pages/invoicing.page';
import poData from '../../test-data/purchaseOrderData.json';
import { saveData, readData } from '../../utils/fileStore';
import { generateSequence } from '../../utils/sequenceGenerator';

test.describe('@procurement Create Invoice from Purchase Order', () => {

  test('TC03_Create invoice from existing purchase order via journal', async ({ page }) => {
    page.setDefaultTimeout(10000);
    page.setDefaultNavigationTimeout(15000);
    const invoicing = new InvoicingPage(page);
    
    // Get the PO number that was created in previous test
    const poNumber = readData('PO_NUMBER');
    console.log('Creating invoice for PO Number:', poNumber);

    // Open vendor invoice journal
    await invoicing.openVendorInvoiceJournal();
    await invoicing.createNewInvoiceJournal();

    // Get the journal number
    const journalNumber = await invoicing.getJournalNumber();
    console.log('Created Journal Number:', journalNumber);
    saveData('JOURNAL_NUMBER', journalNumber);

    // Open PO lookup and select the existing PO
    await invoicing.openPurchaseOrderLookup();
    await invoicing.selectPurchaseOrder(poNumber);

    // Fill invoice details
    const invoiceNumber = generateSequence('INV');
    const today = new Date().toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: '2-digit', 
      day: '2-digit' 
    });
    
    await invoicing.fillInvoiceDetails(invoiceNumber, today);
    console.log('Invoice Number:', invoiceNumber);
    saveData('INVOICE_NUMBER', invoiceNumber);

    // Save the invoice
    await invoicing.saveInvoice();
    await expect(page.locator('text=Saved')).toBeVisible({ timeout: 5000 }).catch(() => {
      console.log('Save confirmation not visible, continuing...');
    });

    // Post the invoice
    await invoicing.postInvoice();
    await expect(page.locator('text=Operation completed').first()).toBeVisible({ timeout: 5000 }).catch(() => {
      console.log('Post confirmation message not found');
    });

    console.log('Invoice created and posted successfully');
  });

  test('TC04_Create invoice directly from received purchase order', async ({ page }) => {
    page.setDefaultTimeout(10000);
    page.setDefaultNavigationTimeout(15000);
    const invoicing = new InvoicingPage(page);

    // Get the PO number
    const poNumber = readData('PO_NUMBER');
    console.log('Creating invoice from PO:', poNumber);

    // Open received purchase orders
    await invoicing.openReceivedPurchaseOrders();
    await page.waitForTimeout(3000);

    // Filter and open the PO
    await invoicing.filterAndOpenPurchaseOrder(poNumber);

    // Create invoice from the PO
    await invoicing.createInvoiceFromPO();

    // Fill invoice details if needed
    const invoiceNumber = generateSequence('INV');
    const today = new Date().toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: '2-digit', 
      day: '2-digit' 
    });
    
    // Check if we need to fill invoice details (depends on PO configuration)
    const invoiceField = page.locator('input[name="InvoiceId"]').first();
    const isEditable = await invoiceField.isEditable().catch(() => false);
    
    if (isEditable) {
      await invoicing.fillInvoiceDetails(invoiceNumber, today);
    }

    // Get invoice number
    const createdInvoiceNumber = await invoicing.getInvoiceNumber();
    console.log('Invoice Number:', createdInvoiceNumber);
    saveData('INVOICE_NUMBER_PO', createdInvoiceNumber);

    // Save and post invoice
    await invoicing.saveInvoice();
    await invoicing.postInvoice();

    console.log('Invoice created and posted from PO successfully');
  });
});
