import { test, expect } from '@playwright/test';
import { PurchaseOrderPage } from '../../../pages/purchaseOrder.page.ts';
import poData from '../../../test-data/purchaseOrderData.json';
import { saveData } from '../../../utils/fileStore.ts';
import { readData } from '../../../utils/fileStore.ts';
import { getFutureDate } from '../../../utils/util.ts';

//test.describe.configure({ mode: 'serial' });

test.describe('@procurement Create Purchase Order', () => {
  

  test('TC01_Create purchase order', async ({ page }) => {
    page.setDefaultTimeout(10000);
    page.setDefaultNavigationTimeout(15000);    
    const po = new PurchaseOrderPage(page);
    await po.open();
    await po.createPO(poData.basicPO.vendor);    
    await po.addLine(poData.basicPO.item,poData.basicPO.quantity);
    // Set warehouse - Our internal env not set only read only
    //await po.setWarehouse(poData.basicPO.site,poData.basicPO.warehouse);    
    await po.savePO();
    await page.waitForTimeout(3000);
    const poNumber = await po.getPurchaseOrderNumber();
    console.log('Created PO Number:', poNumber);
    saveData('PO_NUMBER', poNumber);
    await page.waitForTimeout(3000);
    await po.confirmPO(poData.basicPO.vendor);
   
  });


  test('TC02_Updatding Created purchase order', async ({ page }) => {
    page.setDefaultTimeout(15000);
    page.setDefaultNavigationTimeout(18000);    
    const po = new PurchaseOrderPage(page);
    await po.open();
    await page.waitForTimeout(6000);
    // filter with po number
    const poNumber = readData('PO_NUMBER');
    console.log('Created PO Number:', poNumber);
    await po.filterPurchaseOrder(poNumber); 
    await po.setWarehouse(poData.basicPO.site,poData.basicPO.warehouse);
    
    await po.updateShipDateInDelivery(getFutureDate(5, 'mm/dd/yyyy'));    
    await po.savePO();
    await po.confirmPO(poData.basicPO.vendor);
    saveData('PO_NUMBER', poNumber);

    });


    test('TC03_Product Receipt purchase order  ', async  ({ page }) => {
    const po = new PurchaseOrderPage(page);
    await po.open();
    await page.waitForTimeout(6000);
    // filter with po number
    const poNumber = readData('PO_NUMBER');
    console.log('Created PO Number:', poNumber);
    await po.filterPurchaseOrder(poNumber); 
    await page.waitForTimeout(3000);
    await po.productReceipt();
    console.log('Product receipt created for PO Number:', poNumber);

    });

    test('TC04_Invoice purchase order  ', async  ({ page }) => {
    const po = new PurchaseOrderPage(page);
    await po.open();
    await page.waitForTimeout(6000);
    // filter with po number
    const poNumber = readData('PO_NUMBER');
    console.log('Created PO Number:', poNumber);
    await po.filterPurchaseOrder(poNumber); 
    await page.waitForTimeout(3000);
    await po.invoicePO();
    console.log('Invoice Posted..', poNumber);

    });

    test('TC05_Create PO and Invoice end to end flow ', async  ({ page }) => {
      const po = new PurchaseOrderPage(page);
      await po.open();  
      await po.createPO(poData.basicPO.vendor);    
      await po.addLine(poData.basicPO.item,poData.basicPO.quantity);
      await po.setWarehouse(poData.basicPO.site,poData.basicPO.warehouse);
      await po.savePO();
      await page.waitForTimeout(3000);
      const poNumber = await po.getPurchaseOrderNumber();
      console.log('Created PO Number:', poNumber);
      saveData('PO_NUMBER', poNumber);
      await page.waitForTimeout(3000);
      await po.confirmPO(poData.basicPO.vendor);
      await po.productReceipt();
      await po.invoicePO();
      console.log('Invoice Posted..', poNumber);

    });







    // test.afterEach(async ({ page }) => {
    //   await page.close();
    // });





});
