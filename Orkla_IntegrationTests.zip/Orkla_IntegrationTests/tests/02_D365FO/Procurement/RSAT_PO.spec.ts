import { test, expect } from '@playwright/test';

test('Create Purchase Order', async ({ page }) => {

  await page.goto("https://acumant-poc.sandbox.operations.dynamics.com/?cmp=USMF&mi=PurchTableListPage");

  page.setDefaultTimeout(10000);
  page.setDefaultNavigationTimeout(15000);

  // Click New
  await page.locator('[data-dyn-controlname="SystemDefinedNewButton"]').click();
  await page.waitForTimeout(3000);

  // Vendor account
  await page.locator('input[name="PurchTable_OrderAccount"]')
    .fill('1001');

  // Warehouse
  await page.locator('input[name="PurchTable_InventLocationId"]')
    .fill('11');

  // OK
  await page.locator('[data-dyn-controlname="OK"]').click();

  // Item number
  await page.locator('input[aria-label="Item number"]').fill('D0001');
  await page.locator('input[aria-label="Item number"]').press('Tab');
  //await page.locator('[data-dyn-controlname="PurchLine_ItemId"]').last().fill('D0001');
  
    

  // Quantity
  await page.locator('input[aria-label="Quantity"]')
    .fill('10');

  // Unit Price
  //await page.locator('[data-dyn-controlname="PurchLine_PurchPriceGrid"]')
  await page.locator('input[aria-label="Unit price"]')
    .fill('1501');

  // Save
  await page.locator('[data-dyn-controlname="SystemDefinedSaveButton"]')
    .click();

});