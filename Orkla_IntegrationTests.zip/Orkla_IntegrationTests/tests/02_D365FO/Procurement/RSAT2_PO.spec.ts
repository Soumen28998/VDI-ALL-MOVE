import { test, expect } from '@playwright/test';

test('Create Purchase Order', async ({ page }) => {

  await page.goto("https://acumant-poc.sandbox.operations.dynamics.com/?cmp=USMF&mi=PurchTableListPage");

  page.setDefaultTimeout(10000);
  page.setDefaultNavigationTimeout(15000);

  // 2. Click New
  await page.getByRole('button', { name: 'New' }).click();

  // 3. Create Purchase Order dialog - Vendor
  await page.getByLabel('Vendor account').click();
  await page.getByLabel('Vendor account').fill('1001'); // Or use lookup
  // If lookup needed:
  // await page.getByRole('gridcell', { name: /1001/ }).first().click(); // Adjust selector

  await page.getByLabel('Warehouse').fill('11');

  await page.getByRole('button', { name: 'OK' }).click();

  // Wait for form to load
  await page.waitForLoadState('networkidle');

  // 4. Add Line
  await page.getByLabel('Item number').fill('D0001');
  await page.getByLabel('Quantity').fill('10');
  await page.getByLabel('Unit price').fill('1501');

  await page.getByRole('button', { name: 'Save' }).click();

  // 5. Confirm
  await page.getByRole('button', { name: 'Confirm' }).click();
  await page.getByRole('button', { name: 'OK' }).click(); // Confirmation dialog

  // Optional: Capture PO number for later use
  const poNumber = await page.getByLabel('Purchase order').inputValue();
  console.log('Created PO:', poNumber);
  expect(poNumber).toBeTruthy();

});