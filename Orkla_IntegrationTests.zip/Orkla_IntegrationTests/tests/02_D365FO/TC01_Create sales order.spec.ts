import { test, expect } from '@playwright/test';
import LoginData from '../../TestData/SOData.json';

const loginData = LoginData.SalesOrderData;
const pwd = decodePassword(loginData.Password);

// function loginToDynamics365() {

//  // 1. Open browser and Navigate to URL
//   await page.goto(loginData.URL);
//   // 2. Enter Email
//   await page.getByRole('textbox', { name: /email|phone|skype/i }).fill(loginData.UserName);
//   await page.getByRole('button', { name: /next/i }).click();

//   // 3. Enter Password
//   // Mask password in logs
//   await test.step('Fill password field (masked)', async () => {
//   await page.getByRole('textbox', { name: /password/i }).fill(pwd);
//   });
//   await page.getByRole('button', { name: /sign in/i }).click();

//   // 4. Click Yes on Stay signed in
//   await page.getByRole('button', { name: /yes/i }).click();


// }



// Testcase: Create a Sales order in Dynamics 365

test('Create a Sales Order in Dynamics 365', async ({ page }) => {
 
  await page.goto(loginData.URL);
  // 5. Wait for Welcome message
  await expect(page.getByRole('heading', { name: /welcome/i })).toBeVisible({ timeout: 60000 });

  // 6. Click Modules in left navigation
  await page.getByRole('treeitem', { name: /modules/i }).click();

  // 7. Click Accounts receivable
  await page.getByRole('treeitem', { name: /accounts receivable/i }).click();

  // 8. Click All sales orders
  await page.getByRole('link', { name: /all sales orders/i }).click();
  await expect(page.getByRole('heading', { name: /all sales orders/i })).toBeVisible({ timeout: 30000 });

  // 9. Click New button
  //await page.getByRole('button', { name: "New" }).click();
  await page.locator('//*[contains(@id,"SystemDefinedNewButton_label")]').click();
  await expect(page.getByRole('heading', { name: /create sales order/i })).toBeVisible({ timeout: 20000 });

  // 10. Input Customer account and press Tab
  await page.getByRole('combobox', { name: /customer account/i }).fill(loginData.Cusomter);
  await page.keyboard.press('Tab');

  // 11. Click OK in Create sales order dialog
  await page.getByRole('button', { name: /^ok$/i }).click();

  // 12. Wait for sales order page/dialog to load
  await page.waitForTimeout(5000);

  // 13. Input Item number (D0001), press Tab
  await page.getByRole('combobox', { name: /item number/i }).fill(loginData.Item);
  await page.keyboard.press('Tab');
  
  await page.waitForTimeout(4000);
  // 14. Input Warehouse (11), press Tab
  await page.getByRole('combobox', { name: /warehouse/i }).fill(loginData.Warehouse);
  await page.keyboard.press('Tab');

  // 15. Click Save button
 // await page.getByRole('button', { name: /save/i }).click();
 // await page.waitForTimeout(10000);

  // 16. If any popup, click OK
  const okPopup = page.locator('//span[text()="Save"]');
  if (await okPopup.isVisible({ timeout: 2000 }).catch(() => false)) {
    await okPopup.click();

  }

  await page.waitForTimeout(5000);
  
  //If any popup, click OK
  const okPopup2 = page.locator('//span[text()="OK"]');
  if (await okPopup2.isVisible({ timeout: 2000 }).catch(() => false)) {
    await okPopup2.click();
    await page.locator('//span[text()="OK"]').press('Enter');
  } 

  
  await page.waitForTimeout(5000);
  
  //await page.locator('//div[text()="Autoreservation"]').press('Enter');

  // 17. Click Complete in Action menu and OK
  //span[contains(@id,'PricingComplete')][2]
  await page.locator('//*[contains(@id,"PricingComplete")][2]').click();
  await page.waitForTimeout(4000);
  //await page.getByRole('button', { name: /Complete/i }).click();
  await page.getByRole('button', { name: /^Submit$/i }).click();

  // 18. Click Sell from Action Menu
  await page.getByRole('button', { name: /sell/i }).click();

  // 19. Click Confirm sales order
  //await page.getByRole('button', { name: /confirm sales order/i }).click();
  await page.locator('//*[contains(@id,"buttonUpdateConfirm_label")]').click();

  
  // 20. Wait for 5 seconds
  await page.waitForTimeout(10000);
  const message = await page.locator("(//span[@class='messageBar-message'])[1]");
  // Wait until toast is displayed
  await expect(message).toBeVisible({ timeout: 10000 });

  // Get the 'title' attribute
  const opc = await message.getAttribute('title');

  console.log('Toast message: ' + opc);

  // 21. Verify Operation completed message
  await expect(page.getByText(/Operation completed/i).first()).toBeVisible({ timeout: 20000 });



});

// decodeBase64 function to decode  encoded strings
export function decodePassword(base64: string): string {
  return Buffer.from(base64, 'base64').toString('utf-8');
}

