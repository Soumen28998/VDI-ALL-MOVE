import { test,expect } from "@playwright/test";


test("TC01_Create Case_BBE", async ({ page }) => {
  
  await page.goto("https://orklaofitest.crm4.dynamics.com/main.aspx");
  await page.waitForTimeout(6000);
  await page.locator('iframe[title="AppLandingPage"]').contentFrame().getByRole('link', { name: 'Sonneveld Customer Engagement' }).click();  
  await page.getByText('Cases').click();  
  await page.getByRole('menuitem', { name: 'New Case' }).click();
  await page.waitForTimeout(4000);
  //await page.locator('//div[@data-id="orkla_casetypeselection.fieldControl_container"]').click();
  const caseTypeLocator = page.locator("(//div[@title='Case Type - Select the relevant case type']/..//div)[2]");
  // Wait for element to be visible
  await caseTypeLocator.waitFor({ state: 'visible' });
  // Hover over it
  await caseTypeLocator.hover();
  // Click it
  await caseTypeLocator.click(); 
  
  //await page.getByRole('option', { name: 'Best Before Extension' }).click();
  const option = page.getByRole('option', { name: 'Best Before Extension' });
  await option.waitFor({ state: 'visible' });
  await option.click();
  await page.waitForTimeout(4000);
  await page.getByRole('combobox', { name: 'Account, Lookup' }).click();
  await page.getByRole('combobox', { name: 'Account, Lookup' }).fill('Bakeplus Haaften B.V.');
  await page.getByText('Bakeplus Haaften B.V.').click();
  await page.waitForTimeout(4000);
  await page.getByRole('button', { name: 'Search records for Product,' }).click();
  await page.getByRole('combobox', { name: 'Product, Lookup' }).fill('SONPLUS WIT RSPO-SG');
  await page.getByLabel('SONPLUS WIT RSPO-SG | ZAK 20 KG, 0222145020', { exact: true }).getByText('SONPLUS WIT RSPO-SG | ZAK 20').click();
  await page.waitForTimeout(4000);
  await page.getByRole('textbox', { name: 'Batch Number' }).click();
  await page.getByRole('textbox', { name: 'Batch Number' }).fill('P1230000');
  await page.getByRole('textbox', { name: 'Batch Number' }).press('Tab');
  await page.waitForTimeout(4000);
  await page.locator('.fui-TagPickerControl.___19kz2ty > .fui-TagPickerControl__aside > .fui-TagPickerControl__expandIcon').first().click();
  await page.getByRole('option', { name: 'Papendrecht HQ' }).click();
  await page.waitForTimeout(4000);
  await page.locator('.fui-TagPickerControl.___19kz2ty > .fui-TagPickerControl__aside > .fui-TagPickerControl__expandIcon').click();
  await page.getByRole('option', { name: 'Duiven - BBD Extension' }).click();
  await page.waitForTimeout(4000);
  await page.getByRole('combobox', { name: 'Date of Original Best Before' }).click();
  await page.getByLabel('Date of Original Best Before').click();
  await page.getByRole('combobox', { name: 'Date of Original Best Before' }).fill('2026/02/26');
  await page.getByRole('combobox', { name: 'Date of Original Best Before' }).press('Tab');
  await page.waitForTimeout(4000);
 
  await page.getByRole('menuitem', { name: 'Save (CTRL+S)' }).click();
  await page.waitForTimeout(8000);
  // Locate the element using XPath
  const casLocator = page.locator("//div[@role='presentation' and contains(text(),'CAS')]");
  // Wait for it to be visible (optional but recommended)
  await casLocator.waitFor();
  // Get the text
  const casText = await casLocator.textContent();
  // Print to console
  console.log('CAS ID:', casText);
  await page.getByRole('button', { name: 'Press Enter to go back.' }).click();
  

});
