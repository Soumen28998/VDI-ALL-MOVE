import { test,expect } from "@playwright/test";


test("TC01_Create Project", async ({ page }) => {

    page.goto("https://businesscentral.dynamics.com/82c61e8c-e5bf-4c20-935b-686cd5fcf8fb/Sandbox3?company=Acumant%20Technologies%20Pvt%20Ltd");
    await page.getByRole('button', { name: 'Search' }).click();
    await page.locator('iframe[title="undefined"]').contentFrame().getByRole('textbox', { name: 'Tell me what you want to do.' }).fill('Project');
    await page.locator('iframe[title="undefined"]').contentFrame().getByText('Projects', { exact: true }).click();
    await page.locator('iframe[title="undefined"]').contentFrame().getByRole('menuitem', { name: 'New', exact: true }).click();
    //Enter or select project

    await page.locator('iframe[title="undefined"]').contentFrame().getByRole('button', { name: 'Review or update the value' }).click();
    await page.locator('iframe[title="undefined"]').contentFrame().getByRole('gridcell', { name: 'Code, sorted in Ascending' }).click();
    await page.locator('iframe[title="undefined"]').contentFrame().getByRole('button', { name: 'OK', exact: true }).click();

    //await page.locator('iframe[title="undefined"]').contentFrame().getByRole('textbox', { name: 'No.', exact: true }).fill('Test1');
    await page.locator('iframe[title="undefined"]').contentFrame().locator('//input[@id="bpree"]').fill('Auto Test');
    await page.waitForTimeout(8000);
    //await page.locator('//input[@id="bpree"]').fill('Auto Test');    
    //await page.locator('iframe[title="undefined"]').contentFrame().getByLabel('New - Project Card').getByRole('textbox', { name: 'Description' }).fill('Testaa');
    //await page.locator('iframe[title="undefined"]').contentFrame().getByLabel('New - Project Card').getByRole('textbox', { name: 'Description' }).press('Tab');
    await page.locator('iframe[title="undefined"]').contentFrame().getByRole('combobox', { name: 'Customer Name' }).click();
    await page.locator('iframe[title="undefined"]').contentFrame().getByRole('button', { name: 'Choose a value for Customer' }).click();
    await page.locator('iframe[title="undefined"]').contentFrame().getByRole('button', { name: 'No., sorted in Ascending order CUST-004' }).click();
    await page.locator('iframe[title="undefined"]').contentFrame().getByRole('button', { name: 'Choose a value for Person' }).click();
    const titleText = await page.locator('iframe[title="undefined"]').contentFrame().locator('//div[@role="heading" and contains(@class,"title") and @aria-level="2"]').last().innerText();
    console.log(titleText);
    await page.locator('iframe[title="undefined"]').contentFrame().getByTitle('Your data is saved now and').click();
    await page.locator('iframe[title="undefined"]').contentFrame().getByLabel('New - Project Card').getByRole('button', { name: 'Back' }).click();
    await page.waitForTimeout(6000);
    await page.locator('iframe[title="undefined"]').contentFrame().getByRole('button', { name: `No., sorted in Ascending order ${titleText}` }).click();
    await page.waitForTimeout(5000);
    await page.locator('iframe[title="undefined"]').contentFrame().getByRole('menuitem', { name: 'Copy Project Tasks to...' }).click();
    await page.locator('iframe[title="undefined"]').contentFrame().getByRole('combobox', { name: 'Project Task No. from' }).click();
    await page.locator('iframe[title="undefined"]').contentFrame().getByRole('button', { name: 'Choose a value for Project Task No. from' }).click();
    await page.locator('iframe[title="undefined"]').contentFrame().getByLabel('Project Task List - PO/AT/').getByRole('menuitem', { name: 'New' }).click();
    await page.locator('iframe[title="undefined"]').contentFrame().getByLabel('New - Project Task Card').getByRole('textbox', { name: 'Project Task No.', exact: true }).fill('123');
    await page.locator('iframe[title="undefined"]').contentFrame().getByLabel('New - Project Task Card').getByRole('button', { name: 'Back' }).click();
    await page.locator('iframe[title="undefined"]').contentFrame().getByRole('gridcell', { name: 'Project Task No., sorted in' }).click();
    await page.locator('iframe[title="undefined"]').contentFrame().getByLabel('Project Task List - PO/AT/').getByRole('button', { name: 'OK' }).click();
    await page.locator('iframe[title="undefined"]').contentFrame().getByRole('button', { name: 'Open the date picker for Starting Date' }).click();
    await page.locator('iframe[title="undefined"]').contentFrame().getByRole('button', { name: '11, June,' }).click();
    await page.locator('iframe[title="undefined"]').contentFrame().getByRole('button', { name: 'Open the date picker for Ending Date' }).click();
    await page.locator('iframe[title="undefined"]').contentFrame().getByRole('button', { name: '30, June,' }).click();
    await page.locator('iframe[title="undefined"]').contentFrame().getByTitle('Close the page').click();
    await page.locator('iframe[title="undefined"]').contentFrame().getByLabel('Project Card').getByRole('menuitem', { name: 'More options' }).click();
    await page.locator('iframe[title="undefined"]').contentFrame().getByText('Saved').click();
   

});