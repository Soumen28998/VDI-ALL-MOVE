//Testcase: Create an order
import { test, expect } from '@playwright/test';
import CBPTestdata from '../../testData/CBPTestData.json' with { type: 'json' };
import { CommonMethods }  from '../../CBP_WebshopUtilities/CBP_CommonMethods.ts';


var TC07=CBPTestdata.TC07_WebshopPricesCustomerSpecificprices;


//Testcase: Webshop - Prices - Customer Specific prices -- D365FO values to be in sync with Webshop values
test('89805_TC07_Webshop - Prices - Customer Specific prices', async ({ page }) => {

  // Object Creation
  const common = new CommonMethods(page);
  // Navigate to the web shop
  await common.goToURL(CBPTestdata.CBP_TestURL);
  //Login
  await common.login(TC07.UserName, TC07.Password);
  // Adding the first item to the cart
  await page.goto(TC07.AddItemToCart1);
  await page.waitForTimeout(5000);
  await expect(page.locator('p[data-async-prop="RawPrice"]')).toContainText('108.50');
  await page.getByRole('combobox').selectOption('pl');
  await page.waitForTimeout(20000);
  await expect(page.locator('p[data-async-prop="RawPrice"]')).toContainText('3,255.00');
  
});