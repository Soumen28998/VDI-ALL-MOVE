//Testcase: Create an order
import { test, expect } from '@playwright/test';
import CBPTestdata from '../../testData/CBPTestData.json' with { type: 'json' };
import { CommonMethods }  from '../../CBP_WebshopUtilities/CBP_CommonMethods.ts';


var TC09=CBPTestdata.TC09_VerifyItemsymbolFood;


//Testcase: Webshop - Prices - Customer Specific prices -- D365FO values to be in sync with Webshop values
test('89812_TC09_Item symbol Food D365 (product in PIM) -  Symbols not available in PIM, (RSPO, Glutefri, Recycled) assigned in D365 shows on food items in the testwebshop', async ({ page }) => {

  // Object Creation
  const common = new CommonMethods(page);
  // Navigate to the web shop
  await common.goToURL(CBPTestdata.CBP_TestURL);
  //Login
  //await common.login(TC09.UserName, TC09.Password);
  // Adding the first item to the cart
  await page.goto(TC09.AddItemToCart);
  await page.waitForTimeout(5000);
  // Verify the tooltip for the symbol on the nonfood item
  await common.verifyTooltipSymbol('RECYCLED','Recycled');
  await page.waitForTimeout(3000);
  await common.verifyTooltipSymbol('RENEWABLE','Genanvendelig emballage');


  
  
});