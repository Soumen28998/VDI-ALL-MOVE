//Testcase: Check discount symbols
import { test, expect } from '@playwright/test';
import CBPTestdata from '../../testData/CBPTestData.json';
import { CommonMethods }  from '../../CBP_WebshopUtilities/CBP_CommonMethods.ts';


test('89779_TC01_Check discount symbols[1.Hvedemel]', async ({ page }) => {
  // Object Creation
  const common = new CommonMethods(page);
  // Navigate to the web shop
  await common.goToURL(CBPTestdata.CBP_ProductionURL);
  //Login
  await common.login(CBPTestdata.ProdUserName, CBPTestdata.ProdPassword);
  // URL Naviagtion to Production category
  await page.goto(CBPTestdata.CBP_ProductionURL + CBPTestdata.Category);
  await page.waitForTimeout(10000);
  await page.goto(CBPTestdata.CBP_ProductionURL + CBPTestdata.Category);
  await page.waitForTimeout(15000);
  // Fetching the first discount symbol text
  //const firstText = await page.locator('//td[@data-async-prop="DiscountString"]').first().innerText();
  //console.log("First discount symbol text: " + firstText);


  const firstPageRecords =
    await common.getColumnValues(
      '//td[@data-async-prop="DiscountString"]',
      10
    );

  console.log('Production:Page 1 Records', firstPageRecords);

  expect(
    firstPageRecords.every(value => value.trim() !== ''),
    'DiscountString column contains empty values'
).toBeTruthy();

  // Navigate to the test web shop
  await common.goToURL(CBPTestdata.CBP_TestURL);
  //Login
  await common.login(CBPTestdata.TestUserName, CBPTestdata.TestPassword);
  // URL Naviagtion to Production category
  await page.goto(CBPTestdata.CBP_TestURL + CBPTestdata.Category);
  await page.waitForTimeout(8000);
   await page.goto(CBPTestdata.CBP_TestURL + CBPTestdata.Category);
  await page.waitForTimeout(20000);
  const secondPageRecords =
    await common.getColumnValues(
      '//td[@data-async-prop="DiscountString"]',
      10
    );

  console.log('Test:Page 2 Records:', secondPageRecords);

   // Compare
  await common.compareArrays(
    firstPageRecords,
    secondPageRecords
  );

});


test('89779_TC01_Check discount symbols[Frugtfyldninger]', async ({ page }) => {
  // Object Creation
  const common = new CommonMethods(page);
  // Navigate to the web shop
  await common.goToURL(CBPTestdata.CBP_ProductionURL);
  //Login
  await common.login(CBPTestdata.ProdUserName, CBPTestdata.ProdPassword);
  // URL Naviagtion to Production category
  await page.goto(CBPTestdata.CBP_ProductionURL + CBPTestdata.Category2);

  await page.waitForTimeout(10000);

  const firstPageRecords =
    await common.getColumnValues(
      '//td[@data-async-prop="DiscountString"]',
      10
    );

  console.log('Production:Page 1 Records', firstPageRecords);
  // Navigate to the test web shop
  await common.goToURL(CBPTestdata.CBP_TestURL);
  //Login
  await common.login(CBPTestdata.TestUserName, CBPTestdata.TestPassword);
  // URL Naviagtion to Production category
  await page.goto(CBPTestdata.CBP_TestURL + CBPTestdata.Category2);
  await page.waitForTimeout(10000);
  const secondPageRecords =
    await common.getColumnValues(
      '//td[@data-async-prop="DiscountString"]',
      10
    );

  console.log('Test:Page 2 Records:', secondPageRecords);

   // Compare
  await common.compareArrays(
    firstPageRecords,
    secondPageRecords
  );

});