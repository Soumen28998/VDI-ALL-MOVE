//Testcase: Create an order
import { test, expect } from '@playwright/test';
import CBPTestdata from '../../testData/CBPTestData.json';
import { CommonMethods }  from '../../CBP_WebshopUtilities/CBP_CommonMethods.ts';
import { CBP_FO } from '../../pages/CBP_FO.ts';
import {BasePage} from '../../pages/BasePage.ts';
import { ENV } from '../../utils/env.ts';
import * as util from '../../utils/util.ts';
import RuntimeTestdata from '../../testData/runtimeData.json'

var TC02=CBPTestdata.TC02_Create_an_order;;
var RunTimedata=RuntimeTestdata;

test('89781_TC04_Get document - open order', async ({ page }) => {
/*
  // Verify the order confirmation in CBPD365FO 
  const cbpFo = new CBP_FO(page);
  const basePage = new BasePage(page);
  await basePage.navigateByUrl(CBPTestdata.CBP_UAT2CG02URL);
  //ALL Webshop orders
  await basePage.navigateTo('Accounts receivable', 'Orders', 'Webshop orders');
  // Sort the Grid by lastest first
  await basePage.sortGridColumn('Created date and time', 'Sort newest to oldest');
  await page.waitForTimeout(10000);
  await basePage.filterGrid('Customer account', TC03.CustomerAccount);
  const WebShoporderId = await basePage.getFirstRowValue('Webshop order id');
  console.log('Order ID:', WebShoporderId);
  await basePage.filterGrid('Webshop order id', WebShoporderId);
  // Store SO number first time
  const salesOrder = await basePage.getFirstRowValue('Sales order');
  console.log('1. Initial Sales Order Number:', salesOrder);
  // Get Status of the order and wait for it to be 'Done' before proceeding
  const statusDoneOrProgress = await basePage.getFirstRowValue('Status');
  console.log('Status :', statusDoneOrProgress);
  // DONE Status check wait 1 min for 16 min
  await cbpFo.waitForWebshopOrderToStatus('Status', 'Done', 16, 1);
  const finalStatus = await basePage.getFirstRowValue('Status');
  expect(finalStatus.toLowerCase()).toBe('done');
  console.log('Final Status:', finalStatus);
  //Click on Sales order number to open the order details page
  if (finalStatus.toLowerCase() === 'done') {
  const salesOrder = await basePage.getFirstRowValue('Sales order');
  console.log(`2.Sales Order Number is : ${salesOrder}`);
  
  */
 let SoNumber=RunTimedata.TC02_Create_an_order.SalesOrder;

 //SoNumber="00007379";
  console.log("Redaing Runtime data JOSON "+SoNumber)
  // Object Creation
  const common = new CommonMethods(page);
  // Navigate to the web shop
  await common.goToURL(CBPTestdata.CBP_TestURL);
  //Login
  await common.login(TC02.UserName, TC02.Password);
  //Click on MIN KONTO Link
  //await common.clickLink("MIN KONTO");
  //await page.getByRole('link', { name: ' Min konto' }).click();
  //await page.getByRole('link', { name: '00026978' }).click();
  await common.clickMenuLink("Min konto");
  await page.waitForTimeout(10000);
  let SO=RuntimeTestdata.TC02_Create_an_order.SalesOrder
  await common.clickMenuLink(SO);
  const orderText = await page
    .locator("//p[contains(.,'Ordrenr.')]")
    .textContent();
  const orderNumber = orderText?.match(/\d+/)?.[0];
  console.log(orderNumber);
  expect(orderNumber,SO);
  
  
      
});




