//Testcase: Create an order
import { test, expect } from '@playwright/test';
import CBPTestdata from '../../testData/CBPTestData.json';
import { CommonMethods }  from '../../CBP_WebshopUtilities/CBP_CommonMethods.ts';
import { CBP_FO } from '../../pages/CBP_FO.ts';
import {BasePage} from '../../pages/BasePage.ts';
import { ENV } from '../../utils/env.ts';
import * as util from '../../utils/util.ts';
import RuntimeTestdata from '../../testData/runtimeData.json'

var TC02=CBPTestdata.TC02_Create_an_order;

test('89780_TC02_Create an order[1.Creating Order in Webshop]', async ({ page }) => {

  // Object Creation
  const common = new CommonMethods(page);
  // Navigate to the web shop
  await common.goToURL(CBPTestdata.CBP_TestURL);
  //Login
  await common.login(TC02.UserName, TC02.Password);
  // Adding the first item to the cart
  await page.goto(TC02.AddItemToCart1);
  await page.waitForTimeout(5000);
  await common.EnterQuantity(TC02.Qty);
  await page.goto(TC02.AddItemToCart2);
  await page.waitForTimeout(5000);
  await common.EnterQuantity(TC02.Qty);
  await page.goto(TC02.AddItemToCart3);
  await page.waitForTimeout(5000);  
  await common.clickLink('Vinylhandsker L pudderfri 100 stk.');
  await common.EnterQuantity(TC02.Qty);
  await page.waitForTimeout(5000);
  await common.verifyCartCount(3);
  // Click on Go to Cart
  await common.clickGoToCart();
  await page.waitForTimeout(5000);
  // Click on Next button
  await common.clickButton('cartnext', 'id');

const webItemPriceMap = new Map<string, number>();
webItemPriceMap.set(
    await common.getElementValue('(//td[@data-label="Varenr."])[1]'),
    await common.normalizeCurrency(await common.getElementValue('(//td[@data-label="Total"])[1]'))
);
webItemPriceMap.set(
    await common.getElementValue('(//td[@data-label="Varenr."])[2]'),
    await common.normalizeCurrency(await common.getElementValue('(//td[@data-label="Total"])[2]'))
);
webItemPriceMap.set(
    await common.getElementValue('(//td[@data-label="Varenr."])[4]'),
    await common.normalizeCurrency(await common.getElementValue('(//td[@data-label="Total"])[4]'))
);

console.log("Web Item Price Map:", webItemPriceMap);
let WebSalesTaxAmount = await common.normalizeCurrency(await common.getElementValue('(//td[@data-label="Total"])[3]'));
console.log('Sales Tax Amount:', WebSalesTaxAmount);

  await page.waitForTimeout(5000); 
  // Click on Accept checkbox
  await common.checkCheckbox('#EcomOrderCustomerAccepted');
  await page.waitForTimeout(8000);  
  await common.clickButton('cartnext', 'id'); 
  await page.waitForTimeout(8000); 

  /*
  
  await common.clickButton('Godkend ordre', 'text');
  await page.waitForTimeout(10000); 
  */
  

  // Verify the order confirmation in CBPD365FO 
  const cbpFo = new CBP_FO(page);
  const basePage = new BasePage(page);
  await basePage.navigateByUrl(CBPTestdata.CBP_UAT2CG02URL);
  //ALL Webshop orders
  await basePage.navigateTo('Accounts receivable', 'Orders', 'Webshop orders');
  // Sort the Grid by lastest first
  await basePage.sortGridColumn('Created date and time', 'Sort newest to oldest');
  // Store SO number first time
  const salesOrder = await basePage.getFirstRowValue('Sales order');
  console.log('1. Initial Sales Order Number:', salesOrder);
  // Get Status of the order and wait for it to be 'Done' before proceeding
  const statusDoneOrProgress = await basePage.getFirstRowValue('Status');
  console.log('Status :', statusDoneOrProgress);
  // DONE Status check wait 1 min for 16 min
  await cbpFo.waitForWebshopOrderToStatus('Status', 'Done', 16, 1);
  const finalStatus = await basePage.getFirstRowValue('Status');
  console.log('Final Status:', finalStatus);
  //Click on Sales order number to open the order details page
  if (finalStatus.toLowerCase() === 'done') {
  const salesOrder = await basePage.getFirstRowValue('Sales order');
  console.log(`2.Sales Order Number is : ${salesOrder}`);
  await basePage.clickFirstRowValue('Sales order');
  } 
  //const WebItemNumbers: string[] = ["4166", "40031", "42957"];
  //const WebUnitPrices: string[] = ["1.00", "45.00", "1.00"];
  await page.waitForTimeout(6000);

  // Filter and Loop through Item numbers
  for (const [WebitemNumber, WebunitPrice] of webItemPriceMap.entries()) {
  console.log(`Filtering Item: ${WebitemNumber}`);
  await basePage.filterLineItemGrid('Item number', WebitemNumber);    
  // Verify Sales order line details
  const ItemNumber = await basePage.getFirstRowValueWhenFilter('Item number');
  console.log(`1.Item Number is : ${ItemNumber}`);
  expect(WebitemNumber).toContain(ItemNumber);    
  const OrderedSalesQty = await basePage.getFirstRowValueWhenFilter('Quantity');
  console.log(`2.Ordered Sales Quantity is : ${OrderedSalesQty}`);
  expect(OrderedSalesQty).toBe('1.00');  
  const UnitPrice = await basePage.getFirstRowValueWhenFilter('Unit price');
  const UnitPriceConverted = await common.normalizeCurrency(await basePage.getFirstRowValueWhenFilter('Unit price'));

  // Verifying Unit prices with respect to the Item numbers
  console.log(`3.D365 Unit Price is : ${UnitPrice}`);
  console.log(`3.D365 Unit Price is : ${UnitPriceConverted}`);
  expect(UnitPriceConverted.toString()).toBe(WebunitPrice.toString());

  }

  await basePage.clickActionButton('Sell');
  await page.waitForTimeout(5000);
  await basePage.clickActionButton('Sales tax');  
  await basePage.filterGrid('Sales tax code', 'D2');
  const SalesTaxAmount = await basePage.getFirstRowValue('Actual sales tax amount');
  const SalesTaxAmountConverted = await common.normalizeCurrency(SalesTaxAmount);
  console.log(`4.D365 Sales Tax Amount is : ${SalesTaxAmountConverted}`);
  // Verifying Sales Tax Amount
  expect(SalesTaxAmountConverted.toString()).toBe(WebSalesTaxAmount.toString());
  await basePage.closeBtnClick();

util.writeJsonData(
    './testData/runtimeData.json',
    'TC02_Create_an_order',
    {
      SalesOrder: salesOrder,
      "Last updated"    :  basePage.getCurrentDateTime     
        
    }
  )


    
});

// List
/*
{
  const WebItemNumbers :string[]=[];
  WebItemNumbers.push(await common.getElementValue('(//td[@data-label="Varenr."])[1]'));
  WebItemNumbers.push(await common.getElementValue('(//td[@data-label="Varenr."])[2]'));
  WebItemNumbers.push(await common.getElementValue('(//td[@data-label="Varenr."])[4]'));
  console.log('Item Numbers:', WebItemNumbers);
  const UnitPrice :string[]=[];
  UnitPrice.push(await common.getElementValue('(//td[@data-label="Total"])[1]'));
  UnitPrice.push(await common.getElementValue('(//td[@data-label="Total"])[2]'));
  UnitPrice.push(await common.getElementValue('(//td[@data-label="Total"])[4]'));
  console.log('Unit Price:', UnitPrice);
  const WebUnitPrice1 = await common.normalizeCurrency(UnitPrice[0]);
  const WebUnitPrice2 = await common.normalizeCurrency(UnitPrice[1]);
  const WebUnitPrice3 = await common.normalizeCurrency(UnitPrice[2]);
  console.log('Normalized Unit Prices:', WebUnitPrice1, WebUnitPrice2, WebUnitPrice3);

}
  */



test('TC02_Create an order[2.Verifying Webshop order in D365FO]', async ({ page }) => {

// Verify the order confirmation in CBPD365FO 
  const cbpFo = new CBP_FO(page);
  const basePage = new BasePage(page);
  await basePage.navigateByUrl(CBPTestdata.CBP_UAT2CG02URL);
  //await page.goto(CBPTestdata.CBP_UAT2CG02URL);
  await basePage.navigateTo('Accounts receivable', 'Orders', 'Webshop orders');
  await basePage.sortGridColumn('Created date and time', 'Sort newest to oldest');
  const salesOrder = await basePage.getFirstRowValue('Sales order');
  console.log('1. Initial Sales Order Number:', salesOrder);
  const statusDoneOrProgress = await basePage.getFirstRowValue('Status');
  console.log('Status :', statusDoneOrProgress);
  await basePage.filterGrid('Customer account', "000023");
  await cbpFo.waitForWebshopOrderToStatus('Status', 'Done', 16, 2);
  const finalStatus = await basePage.getFirstRowValue('Status');
  console.log('Final Status:', finalStatus);
  //Click on Sales order number to open the order details page
  if (finalStatus.toLowerCase() === 'done') {
  const salesOrder = await basePage.getFirstRowValue('Sales order');
  console.log(`2.Sales Order Number is : ${salesOrder}`);
  await basePage.clickFirstRowValue('Sales order');
  } 
  const itemNumbers: string[] = ["4166", "40031", "42957"];
  for (const itemNumber of itemNumbers) {
  console.log(`Filtering Item: ${itemNumber}`);
  await page.waitForTimeout(10000);
  await basePage.filterLineItemGrid('Item number', itemNumber);    
  // Verify Sales order line details
  const ItemNumber = await basePage.getFirstRowValueWhenFilter('Item number');
  console.log(`1.Item Number is : ${ItemNumber}`);
  expect(itemNumbers).toContain(ItemNumber);    
  const OrderedSalesQty = await basePage.getFirstRowValueWhenFilter('Quantity');
  console.log(`2.Ordered Sales Quantity is : ${OrderedSalesQty}`);
  expect(OrderedSalesQty).toBe('1.00');
  const UnitPrice = await basePage.getFirstRowValueWhenFilter('Unit price');
  console.log(`3.Unit Price is : ${UnitPrice}`);
  //expect(UnitPrice).toBe('1.00');
  }
  await basePage.clickActionButton('Sell');
  await page.waitForTimeout(5000);
  await basePage.clickActionButton('Sales tax');
  await page.waitForTimeout(9000);
  await basePage.filterGrid('Sales tax code', 'D2');
  const SalesTaxAmount = await basePage.getFirstRowValue('Actual sales tax amount');
  console.log(`4.Sales Tax Amount is : ${SalesTaxAmount}`);
  await basePage.closeBtnClick();

util.writeJsonData(
    './testData/runtimeData.json',
    'TC02_Create_an_order',
    {
      SalesOrder: salesOrder,
      "Last updated":basePage.getCurrentDateTime      
        
    }
  )


});



