//Testcase: Create an order
import { test, expect } from '@playwright/test';
import CBPTestdata from '../../testData/CBPTestData.json' with { type: 'json' };
import { CommonMethods }  from '../../CBP_WebshopUtilities/CBP_CommonMethods.ts';


var TC08=CBPTestdata.TC08_VerifyItemSymbolsTooltip;


//Testcase: Webshop - Prices - Customer Specific prices -- D365FO values to be in sync with Webshop values
test('89811_TC08_Item symbol Nonfood (not in PIM) - Symbols assigned in D365 shows on nonfood items in the testwebshop', async ({ page }) => {

  // Object Creation
  const common = new CommonMethods(page);
  // Navigate to the web shop
  await common.goToURL(CBPTestdata.CBP_TestURL);
  //Login
  await common.login(TC08.UserName, TC08.Password);
  // Adding the first item to the cart
  await page.goto(TC08.AddItemToCart1);
  await page.waitForTimeout(5000);
  // Verify the tooltip for the symbol on the nonfood item
  await common.verifyTooltipSymbol('GLAS','Glas og gaffel');
  await page.waitForTimeout(3000);
  await common.verifyTooltipSymbol('ECO','ECO Label');


  
  
});