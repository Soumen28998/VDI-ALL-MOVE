//Testcase: Create an order
import { test, expect } from '@playwright/test';
import CBPTestdata from '../../testData/CBPTestData.json';
import { CommonMethods }  from '../../CBP_WebshopUtilities/CBP_CommonMethods.ts';
import { CBP_FO } from '../../pages/CBP_FO.ts';
import {BasePage} from '../../pages/BasePage.ts';
import { ENV } from '../../utils/env.ts';
import * as util from '../../utils/util.ts';
import RuntimeTestdata from '../../testData/runtimeData.json'

var TC06=CBPTestdata.TC06_AlternativeDelivery;
var RunTimedata=RuntimeTestdata;

test('89804_TC06_Alternative delivery - Available options in relation to basket content', async ({ page }) => {

  // Object Creation
  const common = new CommonMethods(page);
  // Navigate to the web shop
  await common.goToURL(TC06.URL);
  //Login
  await common.login(TC06.UserName, TC06.Password);
  
  // Adding the first item to the cart
  await page.goto(TC06.AddItemToCart1);
  await page.waitForTimeout(5000);
  await common.EnterQuantity(TC06.Qty1);
  await common.verifyCartCount(1);
    // Click on Go to Cart
  await common.clickGoToCart();
  await page.waitForTimeout(5000);
  // Click on Next button
  await common.clickButton('cartnext', 'id');
  await page.waitForTimeout(5000);
  await common.checkIfNotChecked('#checkAltAdress');

  // Selecting Date
  await common.selectDate('#AltDeliveryDate', 10);

  await page.waitForTimeout(5000);
  await common.verifyDropdownOptions("#deliverRoutes",
    [
      'Kolli Food - 2 kolli x 25 kg',
      'Post NonFood - maks. 5 kg'
      
    ]

  )


  

  
      
});




