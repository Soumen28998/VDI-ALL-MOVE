//Testcase: Create an order
import { test, expect } from '@playwright/test';
import CBPTestdata from '../../testData/CBPTestData.json';
import { CommonMethods }  from '../../CBP_WebshopUtilities/CBP_CommonMethods.ts';
import { CBP_FO } from '../../pages/CBP_FO.ts';
import {BasePage} from '../../pages/BasePage.ts';
import { ENV } from '../../utils/env.ts';
import * as util from '../../utils/util.ts';
import RuntimeTestdata from '../../testData/runtimeData.json'

var TC05=CBPTestdata.TC05_CreateLargeOrder;

test('89783_TC05_Create an Large order.spec', async ({ page }) => {

  // Object Creation
  const common = new CommonMethods(page);
  // Navigate to the web shop
  await common.goToURL(CBPTestdata.CBP_TestURL);
  //Login
  await common.login(TC05.UserName, TC05.Password);
  // Adding the first item to the cart
  await page.goto(TC05.AddItemToCart1);
  await page.waitForTimeout(5000);
  //await common.updateItem("48192",'ea',3);
  //await common.updateItem("55503",'cs',4);

  const items = util.readExcel(
    './testData/Largitems.xlsx',
    'Items'
);
console.log(items);

for(let i=0;i<items.length;i++){
  const item=items[i];
  await common.updateItem(item.ItemNumber,item.UnitID,item.Quantity); 
  console.log(" "+item.ItemNumber+"--"+item.UnitID+"--"+item.Quantity) 
  await page.waitForTimeout(5000);

  if ((i + 1) % 10 === 0 && (i + 1) < items.length) {
    await page.waitForTimeout(6000);
    await common.clickNextBtn();
    await page.waitForTimeout(6000);
    }
 
  
}


 

    
});

// List
/*
{
  const WebItemNumbers :string[]=[];
  WebItemNumbers.push(await common.getElementValue('(//td[@data-label="Varenr."])[1]'));
  WebItemNumbers.push(await common.getElementValue('(//td[@data-label="Varenr."])[2]'));
  WebItemNumbers.push(await common.getElementValue('(//td[@data-label="Varenr."])[4]'));
  console.log('Item Numbers:', WebItemNumbers);
  const UnitPrice :string[]=[];
  UnitPrice.push(await common.getElementValue('(//td[@data-label="Total"])[1]'));
  UnitPrice.push(await common.getElementValue('(//td[@data-label="Total"])[2]'));
  UnitPrice.push(await common.getElementValue('(//td[@data-label="Total"])[4]'));
  console.log('Unit Price:', UnitPrice);
  const WebUnitPrice1 = await common.normalizeCurrency(UnitPrice[0]);
  const WebUnitPrice2 = await common.normalizeCurrency(UnitPrice[1]);
  const WebUnitPrice3 = await common.normalizeCurrency(UnitPrice[2]);
  console.log('Normalized Unit Prices:', WebUnitPrice1, WebUnitPrice2, WebUnitPrice3);

}
  */







