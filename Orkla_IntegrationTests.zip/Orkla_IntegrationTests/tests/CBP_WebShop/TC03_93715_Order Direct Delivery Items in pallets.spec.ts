//Testcase: Create an order
import { test, expect } from '@playwright/test';
import CBPTestdata from '../../testData/CBPTestData.json';
import { CommonMethods }  from '../../CBP_WebshopUtilities/CBP_CommonMethods.ts';
import { CBP_FO } from '../../pages/CBP_FO.ts';
import {BasePage} from '../../pages/BasePage.ts';
import { ENV } from '../../utils/env.ts';
import * as util from '../../utils/util.ts';

var TC03=CBPTestdata.TC03_OrderDirectDeliveryItmpalet;

test('93715_TC03_OrderDirectDeliveryItmpalet', async ({ page }) => {

  // Object Creation
  const common = new CommonMethods(page);

  
  
  // Navigate to the web shop
  await common.goToURL(CBPTestdata.CBP_TestURL);
  //Login
  await common.login(TC03.UserName, TC03.Password);
  // Adding the first item to the cart
  await page.goto(TC03.AddItemToCart1);
  await page.waitForTimeout(5000);
  await common.EnterQuantity(TC03.Qty1);
  await page.goto(TC03.AddItemToCart2);
  await page.waitForTimeout(5000);
  await common.EnterQuantity(TC03.Qty2);  
  await page.waitForTimeout(5000);

  await common.verifyCartCount(5);
  // Click on Go to Cart
  await common.clickGoToCart();
  await page.waitForTimeout(5000);
  // Click on Next button
  await common.clickButton('cartnext', 'id');

   // Click on Accept checkbox
  await common.checkCheckbox('#EcomOrderCustomerAccepted');
  //await common.clickButton('cartnext', 'id');  
  //Final place the oreder -- then it will generate order form
  await common.clickButton('Godkend ordre', 'text');
  
  

  // Verify the order confirmation in CBPD365FO 
  const cbpFo = new CBP_FO(page);
  const basePage = new BasePage(page);
  await basePage.navigateByUrl(CBPTestdata.CBP_UAT2CG02URL);
  //ALL Webshop orders
  await basePage.navigateTo('Accounts receivable', 'Orders', 'Webshop orders');
  // Sort the Grid by lastest first
  await basePage.sortGridColumn('Created date and time', 'Sort newest to oldest');
  await page.waitForTimeout(10000);
  //Filtering Customer account
  //await basePage.filterGrid('Customer account', TC03.CustomerAccount);
  //await page.waitForTimeout(5000);
  //await page.getByText('Customer account').click();
  //await page.getByRole('combobox', { name: 'Filter field: Customer' }).fill(TC03.CustomerAccount);
  //await page.getByRole('button', { name: 'Apply' }).click();
  await basePage.filterGrid('Customer account', TC03.CustomerAccount);
  const WebShoporderId = await basePage.getFirstRowValue('Webshop order id');
  console.log('Order ID:', WebShoporderId);
  await basePage.filterGrid('Webshop order id', WebShoporderId);
  // Store SO number first time
  const salesOrder = await basePage.getFirstRowValue('Sales order');
  console.log('1. Initial Sales Order Number:', salesOrder);
  // Get Status of the order and wait for it to be 'Done' before proceeding
  const statusDoneOrProgress = await basePage.getFirstRowValue('Status');
  console.log('Status :', statusDoneOrProgress);
  // DONE Status check wait 1 min for 16 min
  await cbpFo.waitForWebshopOrderToStatus('Status', 'Done', 16, 1);
  const finalStatus = await basePage.getFirstRowValue('Status');
  expect(finalStatus.toLowerCase()).toBe('done');
  console.log('Final Status:', finalStatus);
  //Click on Sales order number to open the order details page
  if (finalStatus.toLowerCase() === 'done') {
  const salesOrder = await basePage.getFirstRowValue('Sales order');
  console.log(`2.Sales Order Number is : ${salesOrder}`);
  
  } 

  util.writeJsonData(
      './testData/runtimeData.json',
      '93715_TC03_OrderDirectDeliveryItmpalet',
      {
        SalesOrder: salesOrder,
        "Webshop order id" :WebShoporderId,
        "Last updated"    :  basePage.getCurrentDateTime
          
      }
    )
  
    
});




