import { test } from '@playwright/test';
import { LoginPage } from '../../pages/login.page';
import loginData from '../../test-data/loginData.json';
import { ENV } from '../../utils/env';


  test('TC_001 Login with valid user', async ({ page }) => {
    const login = new LoginPage(page);
    //Go to URL
    await login.navigate(ENV.OrklaKAKUAT2URL);
    await page.waitForTimeout(4000);
    const passwordField = page.locator('input[name="passwd"]');
    const AddAnotherAccountBtn=page.getByText('Use another account');

    if (await passwordField.isVisible({timeout: 10000}))
    {
    await AddAnotherAccountBtn.click();
    await page.getByText('Use another account').click();
    await page.waitForTimeout(4000);
    await login.enterUsername(loginData.validUser.username);
    await login.enterPassword(loginData.validUser.password);
    } 
    else if (await AddAnotherAccountBtn.isVisible({timeout: 10000})) {
        await AddAnotherAccountBtn.click();
        await page.waitForTimeout(4000);
        await login.enterUsername(loginData.validUser.username);
        await login.enterPassword(loginData.validUser.password);
    } else {
        await login.enterUsername(loginData.validUser.username);
        await login.enterPassword(loginData.validUser.password);
         }

    console.log('MFA Call option selected, waiting for 15 seconds to receive the call and approve it.');
    await login.SelectMFACallOption(); // Call option for MFA
    //static wait
    await page.waitForTimeout(4000);
    await login.staySignedIn();
    await page.waitForTimeout(4000);
    await login.verifyLoginSuccess();
    await page.waitForTimeout(8000);
    console.log('Login successful, saving auth state..8000ms.');
    await page.context().storageState({ path: 'auth/d365fo.json' });
  });

  


