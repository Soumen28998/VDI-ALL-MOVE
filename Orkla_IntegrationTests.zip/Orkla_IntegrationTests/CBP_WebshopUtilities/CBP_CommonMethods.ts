import { expect, Page } from '@playwright/test';


var quantityInput1 = 'input[name="quantity"], input[name="Quantity1"]';

export class CommonMethods {

  constructor(private page: Page) {}

  async goToURL(url: string): Promise<void> {
    await this.page.goto(url);
  }

  async login(username: string, password: string): Promise<void> {
    const acceptCookiesButton = this.page.getByRole('button', {name: 'Accept All Cookies'});
   // if (await acceptCookiesButton.isVisible()) {
   //     await acceptCookiesButton.click();}

    try {
    await acceptCookiesButton.waitFor({
    state: 'visible',
    timeout: 10000 // Wait up to 10 seconds
    });
    await acceptCookiesButton.click();
      } catch {
        // Popup didn't appear within 10 seconds - continue the test
              }



        

    await this.page.getByRole('link', {
      name: 'Log ind >',
      exact: true
    }).click();

    await this.page.getByRole('textbox', {
      name: 'Kundenummer'
    }).fill(username);

    await this.page.getByRole('textbox', {
      name: 'Kodeord'
    }).fill(password);
    await this.page.waitForTimeout(5000);
    // Click the "Log ind" button and wait for navigation
    const loginButton = this.page.getByRole('button',{name:'Log ind'});
    await expect(loginButton).toBeVisible();
    await expect(loginButton).toBeEnabled();
    await loginButton.click({noWaitAfter: true});

    await this.page.waitForTimeout(5000);

    if (await acceptCookiesButton.isVisible()) {
        await acceptCookiesButton.click();}

  }

  // Generic Method to get first N records
  async getColumnValues(
    locator: string,
    count: number
  ): Promise<string[]> {
    const elements = this.page.locator(locator);
    const values: string[] = [];
    const totalCount = await elements.count();
    const limit = Math.min(count, totalCount);
    for (let i = 0; i < limit; i++) {
      const text = await elements.nth(i).innerText();
      values.push(text.trim());
    }
    return values;
  }

  // Generic Compare Method
  async compareArrays(
    actual: string[],
    expected: string[]
  ): Promise<void> {
    expect(actual).toEqual(expected);
  }





//TC02_Create an order - Enter Quantity  
async EnterQuantity(quantity: string): Promise<void> {
    const quantityInput = this.page.locator(quantityInput1);
    if (await quantityInput.isVisible()) {
        await quantityInput.fill(quantity);
        await quantityInput.press('Tab');
        await this.page.waitForTimeout(5000)
      }
}
//TC02_Create an order - Click on LinkText
async clickLink(linkText: string): Promise<void> {
    await this.page.locator(`//a[contains(normalize-space(),'${linkText}')]`).click();
}

public async clickMenuLink(linkText: string): Promise<void> {

    const link = this.page.getByRole('link', {name: new RegExp(linkText,'i')}).first();
    await link.waitFor({ state: 'visible', timeout: 30000 });
    await link.scrollIntoViewIfNeeded();
    await link.click({timeout:25000});
  }

//TC02_ Verify card count
async verifyCartCount(expectedCount: number): Promise<void> {
    await expect(
        this.page.locator('#cartcount_value')
    ).toHaveText(`(${expectedCount})`);
}
//Go to Cart
async clickGoToCart(): Promise<void> {
    const cart = this.page.locator('#cartcount_text');

    await cart.waitFor({ state: 'visible' });
    await cart.click({timeout: 15000});
}

//Click buttons
async clickButton(value: string, type: 'id' | 'name' | 'text' | 'class'): Promise<void> {
    let locator: any;

    switch (type) {
        case 'id':
            locator = this.page.locator(`#${value}`);
            break;

        case 'name':
            locator = this.page.locator(`[name="${value}"]`);
            break;

        case 'class':
            locator = this.page.locator(`.${value}`);
            break;

        case 'text':
            locator = this.page.locator('button').filter({
            hasText: value
            });
            break;

        default:
            throw new Error(`Unsupported button locator type: ${type}`);
    }

    await locator.waitFor({ state: 'visible', timeout: 30000 });
    await locator.click({timeout: 15000});
}

//Click Checkbox
async checkCheckbox(locator: string): Promise<void> {
    await this.page.locator(locator).check({timeout: 15000});
}


//Get Text values when pass locator value
async getElementValue(locator: string): Promise<string> {
    const element = this.page.locator(locator);
    await element.waitFor({ state: 'visible', timeout: 10000 });
    return await element.innerText();
}

normalizeCurrency(value: string): number {
    // Remove spaces and currency symbols
    value = value.replace(/[^\d.,-]/g, '').trim();

    const lastDot = value.lastIndexOf('.');
    const lastComma = value.lastIndexOf(',');

    if (lastComma > lastDot) {
        // European format: 1.909,00
        value = value.replace(/\./g, '');
        value = value.replace(',', '.');
    } else {
        // US format: 1,909.00
        value = value.replace(/,/g, '');
    }

    return Number(value);
}


async updateItem(
    itemNumber: string,
    unitId: string,
    quantity: number
): Promise<void> {

    // Find the row containing the item number
    const row = this.page.locator(
        `//td[normalize-space()='${itemNumber}']/ancestor::tr`
    );

    await row.waitFor({ state: 'visible' });

    // Select Unit
    const unitDropdown = row.locator('select[data-async-prop="UnitOfMeasure"]');
    await unitDropdown.selectOption(unitId);
    this.page.waitForTimeout(4000);

    // Enter Quantity
    const qty = row.locator('input[data-async-prop="QtyDiscountPrices"]');
    await qty.click();
    this.page.waitForTimeout(4000);
    await qty.fill(quantity.toString());
    await qty.press('Tab');
    this.page.waitForTimeout(4000);
}

//Click Checkbox
async clickNextBtn(): Promise<void> {
       
    await this.page.locator('//a[@aria-label="Next"]').click({timeout:4000});
}

// Verify Dropdown Values
public async verifyDropdownOptions(
    selector: string,
    expectedValues: string[]
): Promise<void> {

    const dropdown = this.page.locator(selector);
    await dropdown.waitFor({ state: 'visible' });
    await dropdown.click();
    const actualValues = await dropdown
        .locator('option')
        .evaluateAll(options =>
            options
                .filter(option => (option as HTMLOptionElement).value !== '')
                .map(option => option.textContent?.trim() || '')
        );

    console.log('Expected:', expectedValues);
    console.log('Actual:', actualValues);
    expect(actualValues).toEqual(expectedValues);
}

public async checkIfNotChecked(selector: string): Promise<void> {

    const checkbox = this.page.locator(selector);

    await checkbox.waitFor({ state: 'visible' });

    if (!(await checkbox.isChecked())) {
        await checkbox.check();
    }
}


public async enterValue(
    selector: string,
    value: string
): Promise<void> {

    const field = this.page.locator(selector);

    await field.waitFor({ state: 'visible' });
    await field.scrollIntoViewIfNeeded();

    await field.click();

    if (await field.isEditable()) {
        await field.fill(value);
    } else {
        throw new Error(
            `Field '${selector}' is readonly or not editable.`
        );
    }
}

public async selectDate(
    inputSelector: string,
    daysToAdd: number
): Promise<void> {

    // Calculate future working date
    const targetDate = new Date();

    let workingDays = 0;

    while (workingDays < daysToAdd) {

        targetDate.setDate(targetDate.getDate() + 1);

        const dayOfWeek = targetDate.getDay();

        // Skip Saturday (6) and Sunday (0)
        if (dayOfWeek !== 0 && dayOfWeek !== 6) {
            workingDays++;
        }
    }

    const targetDay = targetDate.getDate();
    const targetMonth = targetDate.getMonth(); // 0 = Jan, 7 = Aug
    const targetYear = targetDate.getFullYear();

    console.log(
        `Target date: ${targetDay}-${targetMonth + 1}-${targetYear}`
    );

    // Open date picker
    const input = this.page.locator(inputSelector);

    await input.waitFor({
        state: 'visible',
        timeout: 15000
    });

    await input.click();

    // Wait for date picker
    const datePicker = this.page.locator('.ui-datepicker');

    await datePicker.waitFor({
        state: 'visible',
        timeout: 10000
    });

    // Navigate to required month/year
    while (true) {

        const title = datePicker.locator('.ui-datepicker-title');

        const monthText = await title
            .locator('.ui-datepicker-month')
            .innerText();

        const yearText = await title
            .locator('.ui-datepicker-year')
            .innerText();

        const displayedYear = Number(yearText);

        const monthNames = [
            'January',
            'February',
            'March',
            'April',
            'May',
            'June',
            'July',
            'August',
            'September',
            'October',
            'November',
            'December'
        ];

        const displayedMonth =
            monthNames.indexOf(monthText);

        if (
            displayedYear === targetYear &&
            displayedMonth === targetMonth
        ) {
            break;
        }

        // Target date is in the future
        if (
            targetYear > displayedYear ||
            (
                targetYear === displayedYear &&
                targetMonth > displayedMonth
            )
        ) {
            await datePicker
                .locator('.ui-datepicker-next')
                .click();
        } else {
            await datePicker
                .locator('.ui-datepicker-prev')
                .click();
        }

        await this.page.waitForTimeout(300);
    }

    // Select target date
    const dateCell = datePicker.locator(
        `td[data-handler="selectDay"]` +
        `[data-month="${targetMonth}"]` +
        `[data-year="${targetYear}"]` +
        `:not(.ui-datepicker-unselectable)` +
        `:not(.ui-state-disabled)`,
        {
            has: this.page.locator(
                `a.ui-state-default`,
                { hasText: String(targetDay) }
            )
        }
    );

    await dateCell.waitFor({
        state: 'visible',
        timeout: 15000
    });

    await dateCell.locator('a.ui-state-default').click();

    console.log(
        `Selected date: ${String(targetDay).padStart(2, '0')}-${String(targetMonth + 1).padStart(2, '0')}-${targetYear}`
    );
}



public async verifyTooltipSymbol(
    imageName: string,
    expectedTooltip: string
): Promise<void> {

    const image = this.page.locator(
        `img[src*="/Symbols/${imageName}.png"]`
    );

    await image.waitFor({
        state: 'visible',
        timeout: 15000
    });

    // Verify image exists
    await expect(image).toHaveAttribute(
        'src',
        new RegExp(`${imageName}\\.png$`)
    );

    // Verify tooltip
    await expect(image).toHaveAttribute(
        'data-original-title',
        expectedTooltip
    );

    console.log(
        `Verified ${imageName}.png with tooltip: ${expectedTooltip}`
    );
}



}