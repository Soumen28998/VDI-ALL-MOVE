import { Page, expect } from '@playwright/test';
import { ENV } from '../utils/env';
import { generateSequence } from '../utils/sequenceGenerator';
export class PurchaseOrderPage {
  constructor(private page: Page) {}

  
 
 async open() {
  //https://orkla-uat2.sandbox.operations.dynamics.com/?cmp=con&mi=SalesTableListPage
  //https://acumant-poc.sandbox.operations.dynamics.com/?cmp=USMF  
  await this.page.goto(
      `${ENV.baseUrl}&mi=PurchTableListPage`
    );

    await this.page.waitForLoadState('networkidle');
  }

  
  async createPO(vendor: string) {

    
    //const newButton = this.page.getByRole('button', { name: 'New' });
    const newButton = this.page.locator('[data-dyn-controlname="SystemDefinedNewButton"]');
    await newButton.waitFor({ state: 'visible' });
    await expect(newButton).toBeEnabled();
    await newButton.click();

    
    
    const vendorField = this.page.locator('input[name="PurchTable_OrderAccount"]').first();
    await expect(vendorField).toBeVisible({ timeout: 15000 });
    await expect(vendorField).toBeEditable({ timeout: 15000 });

    await vendorField.fill(vendor);
    await vendorField.press('Tab');
    // OK button click after entering vendor
    const okButton = this.page.getByRole('button', { name: 'OK' });
    await okButton.waitFor({ state: 'visible' });
    await expect(okButton).toBeEnabled();
    await okButton.click();

  }

  async addLine(item: string, qty: number) {
    await this.page.waitForTimeout(3000);
    const itemInput = this.page.locator('input[aria-label="Item number"]');
    await itemInput.waitFor({ state: 'visible' });
    await expect(itemInput).toBeEditable({ timeout: 15000 });
    await itemInput.click();
    await itemInput.fill(item);
    await itemInput.press('Tab');
    await this.page.locator('input[aria-label="Quantity"]').fill(qty.toString());
  }

   async setWarehouse(site: string, warehouse: string) {

    // if Edit avaible then need to click on edit button to set warehouse
    const editButton = this.page.locator('button[name*="Edit"]');
    if (await editButton.isVisible()) {
      await editButton.click();
    }
   // await this.page.locator('input[aria-label="Site"]').fill(site);
    await this.page.waitForTimeout(3000);
    const warehouseInput = this.page.locator('input[aria-label="Warehouse"]');
    await warehouseInput.waitFor({ state: 'visible' });
    await expect(warehouseInput).toBeEditable({ timeout: 15000 });
    await warehouseInput.click();
    await warehouseInput.fill(warehouse);
    await warehouseInput.press('Tab');
   
  }

   async savePO() {
    //if save first button not vissible we need to click sendon button index to save the po
    const saveButton = this.page.locator('button[name="SystemDefinedSaveButton"]');
    if (await saveButton.first().isVisible()) {
      await saveButton.click();
    } else {
      const secondSaveButton = this.page.locator('button[name="SystemDefinedSaveButton"]').nth(1);
      await secondSaveButton.waitFor({ state: 'visible' });
      await secondSaveButton.click();
    }
    //await this.page.locator('button[name="SystemDefinedSaveButton"]').click();
  }

  async getPurchaseOrderNumber(): Promise<string> {
    // Click the header tab
    const headerTab = this.page.locator('[data-dyn-controlname="HeaderView_header"]');
    await headerTab.waitFor({ state: 'visible' });
    await headerTab.click();
    
    // Copy the Purchase Order number
    const poNumber = this.page.locator('input[name="PurchTable_PurchId"]').first();
    await poNumber.waitFor({ state: 'visible' });
    const value = await poNumber.inputValue();
    return value;
  }

  async clickLineTab() {
    //data-dyn-mappedtab="LineView"
    const lineTab = this.page.locator('li[data-dyn-mappedtab="LineView"]').first();
    await lineTab.waitFor({ state: 'visible' });
    await lineTab.click();
  }

  async confirmPO(vendor: string) {
    await this.page.locator('button[id*="Purchase_button"]').click();
    await this.page.waitForTimeout(3000);
    await this.page.locator('button[name="buttonConfirm"]').click();
  }

  async productReceipt() {
    await this.page.locator('button[id*="Receive_button"]').click();
    await this.page.locator('button[name="buttonUpdatePackingSlip"]').click();
    const productReceipt = generateSequence('PR');
    await this.page.locator('input[aria-label="Product receipt"]').fill(productReceipt);
    await this.page.waitForTimeout(5000);
    await this.page.getByRole('button', { name: 'OK' }).click();

  }

  async filterPurchaseOrder(poNumber: string) {

    console.log('Created PO Number:', poNumber);
    await this.page.locator('//input[@aria-label="Filter"]').fill(poNumber);
    //Enter key to trigger search
    await this.page.locator('//input[@name="GridFilter_Input"]').press('Enter');
    await this.page.waitForTimeout(2000);
    await this.page.locator('button[class="button quickFilter-applyButton"]').click();
    await this.page.waitForTimeout(3000);
    //await page.locator('//div[@class="dyn-hoverMarkingColumn"]').first().click();
    await this.page.waitForTimeout(3000);
    await this.page.locator(`//input[@value="${poNumber}"]`).click();
    await this.page.locator(`//input[@value="${poNumber}"]`).press('Enter');
    await this.page.waitForTimeout(3000);

  }

  async updateShipDateInDelivery(shipDate: string) {
    // Click the Delivery tab
    const deliveryTab = this.page.locator('li[data-dyn-controlname="TabLineDelivery_header"]');
    await deliveryTab.waitFor({ state: 'visible' });
    await deliveryTab.click();
    await this.page.waitForTimeout(2000);

    // Enter the shipdate
    const shipDateInput = this.page.locator('input[name="ConfirmedShipDate"]').first();
    await shipDateInput.waitFor({ state: 'visible' });
    await expect(shipDateInput).toBeEditable({ timeout: 15000 });
    await shipDateInput.click();
    await shipDateInput.fill(shipDate);
    await shipDateInput.press('Tab');
  }

  async invoicePO() {
     // Click Invoice menu
    const invoiceButton = this.page.locator('button[id*="Invoice"]').first();
    await invoiceButton.waitFor({ state: 'visible' });
    await invoiceButton.click();
    await this.page.waitForTimeout(2000);

    // Click Create invoice option
    const createInvoiceButton = this.page.locator('button[name*="buttonUpdateInvoice"]').first();
    await createInvoiceButton.waitFor({ state: 'visible' });
    await createInvoiceButton.click();
    await this.page.waitForTimeout(3000);

    // Generate unique invoice number
    const invoiceNumber = generateSequence('INV');
    console.log('Generated Invoice Number:', invoiceNumber);
    await this.page.waitForTimeout(5000);
    await this.page.locator('input[name="PurchParmTable_Num"]').fill(invoiceNumber);
    await this.page.waitForTimeout(5000);
    //Save invoice
    await this.savePO();
    await this.page.waitForTimeout(6000);
    await this.page.locator('button[data-dyn-controlname="UpdateMatchStatus"]').first().click();
    await this.page.locator('span:has-text("Update match status")').locator('..').click();
    // Ok button click after saving invoice
    await this.page.waitForTimeout(3000);
    await this.page.locator('button[name="OK"]').last().click();
   
    // POST the invoice
    //await this.page.waitForTimeout(3000);
    //await this.page.locator('button[name="ParmTableTotals"]').first().click();
   
    await this.page.waitForTimeout(8000);

    const statusField = this.page.locator('input[name="PurchStatus"]');
    console.log(await statusField.inputValue());
    await expect(statusField).toHaveValue('Invoiced', { timeout: 40000 });
    console.log(await statusField.inputValue());

    // const status = await this.page.locator('input[name="PurchStatus"]').inputValue();
    // console.log(status);
    // expect(status).toBe('Invoiced');
    

  }

}  
