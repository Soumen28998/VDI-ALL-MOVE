//D365FO Login
import { Browser, Page } from "@playwright/test";
export class LoginPage {
    readonly page: Page
    constructor(page: Page) {
        this.page = page
    }

    async login(username: string, password: string) {
        await this.page.goto("https://d365fo-uks-001.cloudax.dynamics.com/");
        await this.page.fill('input[name="loginfmt"]', username);
        await this.page.click('input[type="submit"]');
        await this.page.fill('input[name="passwd"]', password);
        await this.page.click('input[type="submit"]');
    }   
}