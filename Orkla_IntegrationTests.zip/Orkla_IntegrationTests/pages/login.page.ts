import { Page, expect } from '@playwright/test';
import { ENV } from '../utils/env';

export class LoginPage {
  constructor(private page: Page) {}

  async navigate(URL:string) {
    //await this.page.goto(ENV.baseUrl);
    await this.page.goto(URL);
  }

  async enterUsername(username: string) {
    //await this.page.getByLabel('Email, phone, or Skype').fill(username);
    await this.page.locator('input[name="loginfmt"]').fill(username);
    await this.page.getByRole('button', { name: 'Next' }).click();
  }

  async enterPassword(password: string) {
    await this.page.getByLabel('Password').fill(password);
    await this.page.getByRole('button', { name: 'Sign in' }).click();
    
  }

  async staySignedIn() {
    const stayBtn = this.page.locator('//input[@data-report-event="Signin_Submit"]');
    if (await stayBtn.isVisible()) {
      await stayBtn.click();
    }
  }

  async selectCompany(company: string) {
    await this.page.waitForURL(/operations\.dynamics\.com/);
    await this.page.getByRole('combobox').selectOption(company);
  }

  async verifyLoginSuccess() {
    await expect(
      this.page.locator('[data-dyn-role="NavigationBar"]')
    ).toBeVisible({timeout: 90000});
  }

async SelectMFACallOption() {
  const callOption = this.page.locator('//div[contains(text(),"Call +XX ")]'); 
  await callOption.click({timeout: 10000});
}

  
}
