import { Page, Locator, expect } from '@playwright/test';

/**
 * BasePage.ts
 * ─────────────────────────────────────────────────────────────
 * D365FO shared base page object.
 * All module page objects should extend this class.
 * ─────────────────────────────────────────────────────────────
 */

export class BasePage {
  constructor(protected page: Page) {}

  // ─── Navigation ──────────────────────────────────────────────────────────────

  /**
   * Navigate using the D365FO left-side navigation panel.
   * @param modulePath  e.g. ['General ledger', 'Journals', 'General journals']
   */
  async navigateTo(...modulePath: string[]): Promise<void> {
    await this.page.locator('[aria-label="Modules"]').click();
    for (const step of modulePath) {
      //await this.page.getByRole('menuitem', { name: step }).click();
      // but for this Journal entries, data-dyn-expanded="false" is true no need to click parent nodes that are already expanded
     const parentNode = this.page.locator(`a[data-dyn-title="${step}"]`).first();
    //  console.log("Expected path step: " +modulePath[1]);
    //  console.log("Step " + step);
    //  console.log("expanded attribute value: " + await parentNode.getAttribute('data-dyn-expanded'));
     let isExpanded = await parentNode.getAttribute('data-dyn-expanded');

      if (modulePath[1] === step && isExpanded === 'true'){
          console.log(step+": Tab already expanded: Not Clicked ");
          await this.waitForD365Load();
          await this.page.waitForTimeout(2000);
        
      }
      else if (modulePath[2] === step && isExpanded === 'true'){
          console.log(step+": Tab already expanded: Not Clicked ");
           await this.waitForD365Load();
           await this.page.waitForTimeout(2000);
        
       }
      else{
        await parentNode.click();        
        await this.waitForD365Load();
        await this.page.waitForTimeout(3000); // wait for menu animation
      }

     // await this.page.locator(`a[data-dyn-title="${step}"]`).click(); // re-open menu for next step
     
    }
  }

  /**
   * Navigate directly via D365FO URL segment.
   * Faster than menu clicks for known forms.
   */
  async navigateByUrl(URL: string): Promise<void> {
    await this.page.goto(URL);
    await this.waitForD365Load(); 
    await this.page.waitForTimeout(5000); // wait for page to load completely
  }
  async navigateByLegalEntity(baseUrl: string, LegalEntity: string): Promise<void> {
    await this.page.goto(`${baseUrl}/?mi=${LegalEntity}`);
    await this.waitForD365Load();
  }

  /**
   * Switch legal entity (company) from the top bar.
   */
  async switchLegalEntity(entityCode: string): Promise<void> {
    await this.page.locator('[data-dyn-bind*="CompanyInfo"], .navBar-company').click();
    await this.page.getByText(entityCode, { exact: true }).click();
    await this.waitForD365Load();
  }

  // ─── Wait Helpers ─────────────────────────────────────────────────────────────

  /**
   * Master wait for D365FO — waits for the loading spinner to disappear
   * AND for the network to go idle.
   */
  async waitForD365Load(timeout = 45_000): Promise<void> {
    // Wait for D365 loading overlay to vanish
    await this.page
      .locator('.loadingIndicator, [data-dyn-bind*="loadingIndicator"]')
      .waitFor({ state: 'hidden', timeout })
      .catch(() => {/* overlay may not appear for fast operations */});

    await this.page.waitForLoadState('networkidle', { timeout });
  }

  /**
   * Wait for a specific form to be fully rendered.
   */
  async waitForForm(formTitle: string, timeout = 30_000): Promise<void> {
    await this.page
      .locator(`.formCaption:has-text("${formTitle}"), [aria-label="${formTitle}"]`)
      .waitFor({ state: 'visible', timeout });
  }

  // ─── Action Pane ──────────────────────────────────────────────────────────────

  /**
   * Click a button on the Action Pane.
   * @param tabName   e.g. 'Sell' tab in the ribbon
   
   */

  async clickActionTab2(tabName: string): Promise<void> {
    const actionTab = this.page.locator(
        `button.appBarTab-header:has(span.appBarTab-headerLabel:text-is("${tabName}"))`
    );

    //await actionTab.waitFor({ state: 'visible', timeout: 5000 });
    await actionTab.click({timeout: 5000});
}

async clickActionButton(buttonName: string): Promise<void> {
    const button = this.page.getByRole('button', {
        name: new RegExp(`^${buttonName}$`, 'i')
    });

    await button.waitFor({ state: 'visible', timeout: 30000 });
    await button.scrollIntoViewIfNeeded();
    await button.click();
}

  /**
   * Click any visible ribbon / toolbar button by its label.
   */
  async clickButton(label: string): Promise<void> {
    await this.page
      .getByRole('button', { name: label })
      .or(this.page.locator(`[aria-label="${label}"]`))
      .first()
      .click();
    await this.waitForD365Load();
  }

  // ─── Dialogs & Messages ───────────────────────────────────────────────────────

  /**
   * Confirm a D365FO modal dialog ('OK', 'Yes', 'No', 'Cancel').
   */
  async confirmDialog(action: 'OK' | 'Yes' | 'No' | 'Cancel' = 'OK'): Promise<void> {
    const btn = this.page
      .locator('.messageBox button, .dialog button')
      .filter({ hasText: action })
      .first();

    if (await btn.isVisible({ timeout: 5_000 })) {
      await btn.click();
      await this.waitForD365Load();
    }
  }

  /**
   * Read the D365 info / warning / error message bar text.
   */
  async getInfoBarMessage(): Promise<string> {
    const bar = this.page.locator(
      '.messageBar, .message-bar, [data-dyn-bind*="messageBar"]'
    );
    await bar.waitFor({ state: 'visible', timeout: 10_000 });
    return (await bar.textContent()) ?? '';
  }

  /**
   * Assert that no error message is displayed.
   */
  async assertNoErrors(): Promise<void> {
    const errorBar = this.page.locator('.messageBar.error, .message-bar.error');
    await expect(errorBar).toBeHidden();
  }

  // ─── Grid Helpers ─────────────────────────────────────────────────────────────

  /**
   * Filter a D365 grid using the quick-filter at the top of the column.
   */
  async filterGrid(columnName: string,  value: string): Promise<void> {
    // Click the column header
    // Below one working fine for grids 
    //const header = this.page.locator(`//div[contains(@class,'dyn-headerCell')]//div[text()='${columnName}']`).last();
    const header = this.page.getByText(`${columnName}`);
    await header.waitFor({ state: 'visible', timeout: 5000 });
    await header.hover();
    await header.click({timeout: 6000});
    await this.page.waitForTimeout(6000);
    // 
    const textbox = this.page.locator(
    `input[aria-label*="Filter field: ${columnName}"]`
);
    await textbox.fill(value);
    await this.page.keyboard.press('Enter');
    await this.waitForD365Load();
  }


  async refreshGrid(): Promise<void> {
    //button[@data-dyn-controlname="SystemDefinedRefreshButton"]
    const refreshButton = this.page.locator('//button[@data-dyn-controlname="SystemDefinedRefreshButton"]');
    await refreshButton.waitFor({ state: 'visible', timeout: 5000 });
    await refreshButton.click();
    await this.waitForD365Load();
  }

  async filterLineItemGrid(columnName: string,  value: string): Promise<void> {
    await this.waitForD365Load();
    // Click the column header
    const header = this.page.locator(
    `//div[@data-dyn-controlname="SalesLine_ItemId"]//div[normalize-space()='Item number']`
);
    //This worked previously
    //const header = this.page.locator(`//div[contains(@class,'dyn-headerCell')]//div[normalize-space()='${columnName}']`).last();
    //const header = this.page.locator(`//div[@data-dyn-controlname="SalesLine_ItemId"]/div[text()='${columnName}']`);
    //await header.waitFor({ state: 'visible' });
    await header.click({timeout: 15000});  
    this.page.waitForTimeout(3000);
    const filterInput = this.page.getByRole('combobox', {
        name: new RegExp(columnName, 'i')
    });
    await filterInput.fill(value);
    await this.page.keyboard.press('Enter');
    await this.waitForD365Load();
  }


  /**
   * Select the first row in a grid (clicks the row selector checkbox).
   */
  async selectFirstGridRow(): Promise<void> {
    await this.page
      .locator('.grid-row, .dyn-row')
      .first()
      .locator('.checkBox, input[type="checkbox"]')
      .check();
  }

  /**
   * Get text value from a specific cell [row index, column field].
   */
  async getGridCellValue(rowIndex: number, columnField: string): Promise<string> {
    const cell = this.page
      .locator(`.grid-row:nth-child(${rowIndex + 1}) [data-column-field="${columnField}"]`);
    return (await cell.textContent()) ?? '';
  }


  async getFirstRowValue(columnName: string): Promise<string> {
    await this.page.waitForTimeout(5000); 
    const cell = this.page.locator(`(//input[@aria-label="${columnName}"])[1]`);
    await cell.waitFor({ state: 'visible' });    
    return (await cell.inputValue({ timeout: 5000 })).trim();
}

async getFirstRowValueWhenFilter(columnName: string): Promise<string> {
    await this.page.waitForTimeout(5000); 
    const cell = this.page.locator(`//input[@aria-label="${columnName}"]`).last();    
    await cell.waitFor({ state: 'visible' });    
    return (await cell.inputValue({ timeout: 5000 })).trim();
}


//Click on firstRow value of a column
 async clickFirstRowValue(columnName: string): Promise<void> {
    await this.page.waitForTimeout(5000); 
    const cell = this.page.locator(`(//input[@aria-label="${columnName}"])[1]`);
    await cell.waitFor({ state: 'visible' });    
    await cell.click({timeout: 5000});
    await cell.press('Enter');
    await this.waitForD365Load();
}

  // ─── Field Interactions ───────────────────────────────────────────────────────

  /**
   * Fill a D365FO field by its label text.
   */
  async fillField(label: string, value: string): Promise<void> {
    const field = this.page
      .getByLabel(label)
      .or(this.page.locator(`input[aria-label="${label}"], textarea[aria-label="${label}"]`))
      .first();
    await field.clear();
    await this.page.waitForTimeout(5000);// wait for clear to take effect
    await field.fill(value);
    await this.page.keyboard.press('Tab'); // triggers D365 field validation
  }

/* Table Grid column filter latest to first
*/

async sortGridColumn(columnName: string, sortOption: string): Promise<void> {

    // Click the column header
    const header = this.page.locator(
        `//div[contains(@class,'dyn-headerCell')]//div[normalize-space()='${columnName}']`
    );

    await header.waitFor({ state: 'visible' });
    await header.click({timeout: 5000});
    await this.page.waitForTimeout(5000); // wait for sort options to appear

    // Click the sort option
    const option = this.page.locator(
        `//span[normalize-space()='${sortOption}']`
    );

    await option.waitFor({ state: 'visible' });
    await option.click({timeout: 5000});
}



  /**
   * Set a D365FO date field (handles the custom date picker).
   */
  async setDate(label: string, dateStr: string): Promise<void> {
    const field = this.page.getByLabel(label).first();
    //await field.triple_click?.() ?? field.click();
    //await field.selectAll?.() ?? this.page.keyboard.press('Control+a');
    await field.click();
    await this.page.keyboard.press('Control+a');
    await field.fill(dateStr);
    await this.page.keyboard.press('Tab');
    await this.waitForD365Load();
  }

  /**
   * Select from a D365FO lookup dropdown.
   */
  async selectLookup(label: string, value: string): Promise<void> {
    const field = this.page.getByLabel(label).first();
    await field.clear();
    await field.fill(value);
    // Wait for lookup dropdown and click the matching option
    await this.page
      .locator(`.lookup-list li, .dropDown-list li, [role="option"]`)
      .filter({ hasText: value })
      .first()
      .click();
    await this.waitForD365Load();
  }


  async selectDropdownValue(fieldName: string, value: string) {
 // const input = this.page.locator(`input[name="${fieldName}"]`);
  await this.page
  .locator(`input[name="${fieldName}"]`)
  .locator('xpath=following::div[@title="Open"][1]')
  .click();
  // Click the dropdown input
  //await input.click();

  // Wait for dropdown options to appear
  const option = this.page.locator('ul li', { hasText: value });

  await option.first().waitFor({ state: 'visible', timeout: 5000 });

  // Click the matching option
  await option.first().click();
}




  /**
   * Select a value from a D365FO combo box / enum field.
   */
  async selectComboBox(label: string, option: string): Promise<void> {
    await this.page.getByLabel(label).first().selectOption({ label: option });
    await this.waitForD365Load();
  }

  // ─── FastTab Helpers ──────────────────────────────────────────────────────────

  /**
   * Expand a FastTab section if it is currently collapsed.
   */
  async expandFastTab(tabName: string): Promise<void> {
    const tab = this.page.locator(`.headerSection:has-text("${tabName}")`).first();
    const isCollapsed = await tab.getAttribute('aria-expanded') === 'false';
    if (isCollapsed) await tab.click();
  }

  // ─── Assertions ───────────────────────────────────────────────────────────────

  async assertFieldValue(label: string, expected: string): Promise<void> {
    const field = this.page.getByLabel(label).first();
    await expect(field).toHaveValue(expected);
  }

  async assertPageTitle(title: string): Promise<void> {
    await expect(
      this.page.locator('.formCaption, [data-dyn-bind*="formCaption"]').first()
    ).toContainText(title);
  }

  async assertSuccessMessage(text: string): Promise<void> {
    await expect(
      this.page.locator('.messageBar.success, .message-bar, .notification')
    ).toContainText(text, { timeout: 15_000 });
  }

 async newBtnClick(): Promise<void> {
    await this.page.locator('button[name="SystemDefinedNewButton"], [role="button"]:has-text("New")').first().click();
    await this.waitForD365Load();
  
  }

  async saveBtnClick(): Promise<void> {
    //if save first button not vissible we need to click sendon button index to save the po
    const saveButton = this.page.locator('button[name="SystemDefinedSaveButton"]');
    if (await saveButton.first().isVisible()) {
      await saveButton.click();
    } else {
      const secondSaveButton = this.page.locator('button[name="SystemDefinedSaveButton"]').nth(1);
      await secondSaveButton.waitFor({ state: 'visible' });
      await secondSaveButton.click();
    }
    //await this.page.locator('button[name="SystemDefinedSaveButton"]').click();
  }

  public async clickRefresh(): Promise<void> {

    const refreshButton = this.page.getByRole('button', {
        name: 'Refresh'
    });

    for (let i = 1; i <= 3; i++) {
        try {
            await refreshButton.waitFor({ state: 'visible' });
            await refreshButton.scrollIntoViewIfNeeded();
            await refreshButton.click({ trial: true });
            await refreshButton.click();
            return;
        } catch {
            console.log(`Retry ${i} clicking Refresh...`);
            await this.page.waitForTimeout(1000);
        }
    }

    throw new Error('Unable to click Refresh button.');
}


  async closeBtnClick(): Promise<void> {
    // const closeButton = this.page.locator('button[name="SystemDefinedCloseButton"]');
    // await closeButton.waitFor({ state: 'visible' });
    await this.page.keyboard.press('Escape');
   
  }


  public getCurrentDateTime(): string {

    const now = new Date();

    return `${String(now.getDate()).padStart(2, '0')}-` +
           `${String(now.getMonth() + 1).padStart(2, '0')}-` +
           `${now.getFullYear()} ` +
           `${String(now.getHours()).padStart(2, '0')}:` +
           `${String(now.getMinutes()).padStart(2, '0')}`;
}



}
