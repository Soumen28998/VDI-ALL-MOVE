import { Page, expect } from '@playwright/test';
import { ENV } from '../utils/env';

export class InvoicingPage {
  constructor(private page: Page) {}

  /**
   * Open the vendor invoice journal
   */
  async openVendorInvoiceJournal() {
    await this.page.goto(
      `${ENV.baseUrl}&mi=VendInvoiceJournal`
    );
    await this.page.waitForLoadState('networkidle');
  }

  /**
   * Create new vendor invoice journal
   */
  async createNewInvoiceJournal(journalName: string = 'AP journal') {
    const newButton = this.page.locator('[data-dyn-controlname="SystemDefinedNewButton"]');
    await newButton.waitFor({ state: 'visible' });
    await expect(newButton).toBeEnabled();
    await newButton.click();
    await this.page.waitForTimeout(2000);
  }

  /**
   * Get vendor invoice journal number
   */
  async getJournalNumber(): Promise<string> {
    const journalNumber = this.page.locator('input[name="JournalNum"]').first();
    await journalNumber.waitFor({ state: 'visible' });
    const value = await journalNumber.inputValue();
    return value;
  }

  /**
   * Open purchase order lookup to select PO for invoicing
   */
  async openPurchaseOrderLookup() {
    // Click on the lookup button in the Purchase order field
    const poLookupButton = this.page.locator('button[id*="VendInvoiceJour_PurchId"]').first();
    await poLookupButton.waitFor({ state: 'visible' });
    await poLookupButton.click();
    await this.page.waitForTimeout(2000);
  }

  /**
   * Filter and select purchase order by PO number
   */
  async selectPurchaseOrder(poNumber: string) {
    // Filter in lookup
    const filterInput = this.page.locator('input[aria-label="Filter"]').first();
    await filterInput.waitFor({ state: 'visible' });
    await filterInput.fill(poNumber);
    await this.page.waitForTimeout(1000);
    
    // Click apply filter button
    const applyButton = this.page.locator('button[class*="quickFilter-applyButton"]').first();
    await applyButton.waitFor({ state: 'visible' });
    await applyButton.click();
    await this.page.waitForTimeout(2000);

    // Select the PO from the grid
    const poRow = this.page.locator(`input[value="${poNumber}"]`).first();
    await poRow.waitFor({ state: 'visible' });
    await poRow.click();
    await this.page.waitForTimeout(1000);

    // Click OK to confirm selection
    const okButton = this.page.getByRole('button', { name: 'OK' }).first();
    await okButton.waitFor({ state: 'visible' });
    await okButton.click();
    await this.page.waitForTimeout(3000);
  }

  /**
   * Fill invoice details
   */
  async fillInvoiceDetails(invoiceNumber: string, invoiceDate: string) {
    // Fill invoice number
    const invoiceNumberInput = this.page.locator('input[name="InvoiceId"]').first();
    await invoiceNumberInput.waitFor({ state: 'visible' });
    await expect(invoiceNumberInput).toBeEditable({ timeout: 15000 });
    await invoiceNumberInput.fill(invoiceNumber);

    // Fill invoice date
    const invoiceDateInput = this.page.locator('input[name="InvoiceDate"]').first();
    await invoiceDateInput.waitFor({ state: 'visible' });
    await expect(invoiceDateInput).toBeEditable({ timeout: 15000 });
    await invoiceDateInput.fill(invoiceDate);
    await invoiceDateInput.press('Tab');
  }

  /**
   * Save the invoice
   */
  async saveInvoice() {
    const saveButton = this.page.locator('button[name="SystemDefinedSaveButton"]');
    await saveButton.waitFor({ state: 'visible' });
    await expect(saveButton).toBeEnabled();
    await saveButton.click();
    await this.page.waitForTimeout(2000);
  }

  /**
   * Post the invoice
   */
  async postInvoice() {
    // Click the Post button
    const postButton = this.page.locator('button[id*="Post"]').first();
    await postButton.waitFor({ state: 'visible' });
    await expect(postButton).toBeEnabled();
    await postButton.click();
    await this.page.waitForTimeout(3000);

    // Click OK on the dialog
    const okButton = this.page.getByRole('button', { name: 'OK' }).first();
    await okButton.waitFor({ state: 'visible' });
    await okButton.click();
    await this.page.waitForTimeout(3000);
  }

  /**
   * Open received purchase orders
   */
  async openReceivedPurchaseOrders() {
    await this.page.goto(
      `${ENV.baseUrl}&mi=PurchTableListPageReceived`
    );
    await this.page.waitForLoadState('networkidle');
  }

  /**
   * Filter and open specific purchase order by PO number
   */
  async filterAndOpenPurchaseOrder(poNumber: string) {
    const filterInput = this.page.locator('//input[@aria-label="Filter"]').first();
    await filterInput.waitFor({ state: 'visible' });
    await filterInput.fill(poNumber);
    await this.page.waitForTimeout(1000);

    // Press Enter to search
    await filterInput.press('Enter');
    await this.page.waitForTimeout(2000);

    // Click apply filter button
    const applyButton = this.page.locator('button[class*="quickFilter-applyButton"]').first();
    await applyButton.waitFor({ state: 'visible' });
    await applyButton.click();
    await this.page.waitForTimeout(3000);

    // Click on the PO  
    const poRow = this.page.locator(`//input[@value="${poNumber}"]`).first();
    await poRow.waitFor({ state: 'visible' });
    await poRow.click();
    await this.page.waitForTimeout(3000);
  }

  /**
   * Create invoice from purchase order
   */
  async createInvoiceFromPO() {
    // Click Invoice menu
    const invoiceButton = this.page.locator('button[id*="Invoice"]').first();
    await invoiceButton.waitFor({ state: 'visible' });
    await invoiceButton.click();
    await this.page.waitForTimeout(2000);

    // Click Create invoice option
    const createInvoiceButton = this.page.locator('button[name*="CreateInvoice"]').first();
    await createInvoiceButton.waitFor({ state: 'visible' });
    await createInvoiceButton.click();
    await this.page.waitForTimeout(3000);
  }

  /**
   * Verify invoice number is visible
   */
  async getInvoiceNumber(): Promise<string> {
    const invoiceNumber = this.page.locator('input[name="InvoiceId"]').first();
    await invoiceNumber.waitFor({ state: 'visible' });
    const value = await invoiceNumber.inputValue();
    return value;
  }

  /**
   * Get vendor information
   */
  async getVendorInfo(): Promise<string> {
    const vendorField = this.page.locator('input[name="OrderAccount"]').first();
    await vendorField.waitFor({ state: 'visible' });
    const value = await vendorField.inputValue();
    return value;
  }
}
