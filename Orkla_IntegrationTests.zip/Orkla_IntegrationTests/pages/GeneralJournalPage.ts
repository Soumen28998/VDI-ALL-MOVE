import { Page, expect } from '@playwright/test';
import { BasePage } from './BasePage';

/**
 * GeneralJournalPage.ts
 * ─────────────────────────────────────────────────────────────
 * Page Object for D365FO General Ledger > Journals > General Journals
 *
 * Covers:
 *   - Create / open journal batches
 *   - Add / edit journal lines
 *   - Validate, simulate, and post journals
 *   - Retrieve voucher numbers
 * ─────────────────────────────────────────────────────────────
 */
export class GeneralJournalPage extends BasePage {

  // ─── Selectors ─────────────────────────────────────────────────────────────
  // Chart of accounts >> Main accounts
  private readonly mainAccountField = 'input[name="DetailAccountNum"]'; 
  //input[id*="mainaccount"]
  private readonly mainAccountNameField = 'input[name="DetailAccountName"]';
  

  private readonly journalGridRow     = '.grid-row, .dyn-row';
  private readonly journalNameField   = '[aria-label="Journal batch number"], [data-dyn-bind*="JournalNum"]';
  private readonly linesTab           = 'button:has-text("Lines"), [aria-label="Lines"]';
  private readonly newLineBtn         = '[aria-label="New"], button:has-text("New")';
  private readonly postBtn            = 'button:has-text("Post"), [aria-label="Post"]';
  private readonly validateBtn        = 'button:has-text("Validate"), [aria-label="Validate"]';
  private readonly simulateBtn        = 'button:has-text("Simulate posting")';
  private readonly voucherField       = '[data-column-field="Voucher"], [aria-label="Voucher"]';
  private readonly accountTypeField   = '[aria-label="Account type"]';
  private readonly accountField       = '[aria-label="Account"]';
  private readonly descriptionField   = '[aria-label="Description"]';
  private readonly debitField         = '[aria-label="Debit"]';
  private readonly creditField        = '[aria-label="Credit"]';
  private readonly offsetAccountType  = '[aria-label="Offset account type"]';
  private readonly offsetAccountField = '[aria-label="Offset account"]';
  private readonly currencyField      = '[aria-label="Currency"]';
  private readonly journalNameLookup  = '[aria-label="Journal name"]';
  private readonly postingDateField   = '[aria-label="Date"]';

  constructor(page: Page) {
    super(page);
  }

  // ─── Navigation ────────────────────────────────────────────────────────────

  /**
   * Navigate to General Ledger > Journals > General journals.
   */
  async goto(): Promise<void> {
    await this.navigateTo('General ledger', 'Journal entries', 'General journals');
    await this.waitForForm('General journals');
  }

  // ─── Journal Header ────────────────────────────────────────────────────────

  /**
   * Create a new journal batch.
   * @param journalName  D365FO journal name (e.g. 'GenJrn', 'APInv')
   * @returns The generated journal batch number
   */
  async createNewJournal(journalName: string): Promise<string> {
    await this.clickButton('New');
    await this.selectLookup('Name', journalName);
    await this.waitForD365Load();

    // Read the auto-generated batch number
    const batchNumber = await this.page
      .locator(this.journalNameField)
      .first()
      .inputValue();

    return batchNumber;
  }

  /**
   * Open an existing journal by its batch number.
   */
  async openJournal(batchNumber: string): Promise<void> {
    await this.filterGrid('JournalNum', batchNumber);
    await this.page.locator(this.journalGridRow).first().dblclick();
    await this.waitForD365Load();
  }

  // ─── Journal Lines ─────────────────────────────────────────────────────────

  /**
   * Navigate to the Lines sub-form.
   */
  async openLines(): Promise<void> {
    await this.page.locator(this.linesTab).click();
    await this.waitForD365Load();
  }

  /**
   * Add a single journal line.
   *
   * @param line  JournalLine data object
   */
  async addLine(line: JournalLine): Promise<void> {
    //await this.page.locator(this.newLineBtn).click();
    await this.waitForD365Load();

    if (line.date)              await this.fillField('Date', line.date);
    if (line.accountType)       await this.selectComboBox('Account type', line.accountType);
    if (line.account)           await this.selectLookup('Account', line.account);
    if (line.description)       await this.fillField('Description', line.description);
    if (line.debit !== undefined)  await this.fillField('Debit', String(line.debit));
    if (line.credit !== undefined) await this.fillField('Credit', String(line.credit));
    if (line.offsetAccountType) await this.selectComboBox('Offset account type', line.offsetAccountType);
    if (line.offsetAccount)     await this.selectLookup('Offset account', line.offsetAccount);
    if (line.currency)          await this.fillField('Currency', line.currency);
    if (line.dimension1)        await this.fillField('Department', line.dimension1);
    if (line.dimension2)        await this.fillField('Cost center', line.dimension2);
  }

  /**
   * Add multiple journal lines from an array.
   */
  async addLines(lines: JournalLine[]): Promise<void> {
    for (const line of lines) {
      await this.addLine(line);
    }
  }

  // ─── Validation & Posting ──────────────────────────────────────────────────

  /**
   * Validate the journal (checks for errors without posting).
   * @returns true if validation passes, false if errors found
   */
  async validateJournal(): Promise<boolean> {
    await this.page.locator(this.validateBtn).click();
    await this.waitForD365Load();

    const message = await this.getInfoBarMessage().catch(() => '');
    const hasError = message.toLowerCase().includes('error') ||
                     message.toLowerCase().includes('invalid');
    return !hasError;
  }

  /**
   * Simulate posting (dry run — creates draft vouchers but doesn't finalise).
   */
  async simulatePosting(): Promise<void> {
    await this.page.locator(this.simulateBtn).click();
    await this.waitForD365Load();
    await this.confirmDialog('OK');
  }

  /**
   * Post the journal.
   * @returns The voucher number(s) created
   */
  async postJournal(): Promise<string[]> {
    await this.page.locator(this.postBtn).click();
    await this.waitForD365Load();
    await this.confirmDialog('OK'); // "Are you sure?" dialog

    // Collect voucher numbers from lines grid
    const vouchers = await this.page
      .locator(this.voucherField)
      .allTextContents();

    return [...new Set(vouchers.filter(v => v.trim() !== ''))];
  }

  /**
   * Post the journal and assert it succeeds.
   */
  async postAndVerify(): Promise<string[]> {
    const vouchers = await this.postJournal();
    await this.assertSuccessMessage('The journal was posted');
    return vouchers;
  }

  // ─── Reversal ──────────────────────────────────────────────────────────────

  /**
   * Reverse a posted journal.
   * @param reversalDate  Date for the reversal entry
   */
  async reverseJournal(reversalDate: string): Promise<void> {
    await this.clickActionPaneButton('Functions', 'Reverse');
    await this.fillField('Reversal date', reversalDate);
    await this.confirmDialog('OK');
    await this.waitForD365Load();
  }

  // ─── Approval Workflow ─────────────────────────────────────────────────────

  /**
   * Submit journal for approval (if workflow is enabled).
   */
  async submitForApproval(comment = 'Submitted for review'): Promise<void> {
    await this.clickButton('Submit');
    await this.fillField('Comment', comment);
    await this.confirmDialog('OK');
    await this.waitForD365Load();
  }

  /**
   * Approve a journal in the workflow.
   */
  async approveJournal(comment = 'Approved'): Promise<void> {
    await this.clickButton('Approve');
    await this.fillField('Comment', comment);
    await this.confirmDialog('OK');
    await this.waitForD365Load();
  }

  // ─── Assertions ────────────────────────────────────────────────────────────

  async assertJournalStatus(status: 'Open' | 'Posted'): Promise<void> {
    await expect(
      this.page.locator('[aria-label="Posted"], [data-dyn-bind*="Posted"]').first()
    ).toContainText(status);
  }

  async assertLineCount(expected: number): Promise<void> {
    const rows = this.page.locator(`${this.journalGridRow}:not(.grid-header)`);
    await expect(rows).toHaveCount(expected);
  }

  async assertTotalDebitCredit(): Promise<void> {
    const debitTotal = await this.page
      .locator('[aria-label="Total debit"], .total-debit')
      .textContent() ?? '0';
    const creditTotal = await this.page
      .locator('[aria-label="Total credit"], .total-credit')
      .textContent() ?? '0';

    expect(parseFloat(debitTotal.replace(/,/g, '')))
      .toBeCloseTo(parseFloat(creditTotal.replace(/,/g, '')), 2);
  }

  async mainAccountNumber(mainacc: string): Promise<void> {
    await this.page.locator(this.mainAccountField).first().fill(mainacc);
    
  }

  async accountName(accname: string): Promise<void> {
    await this.page.locator(this.mainAccountNameField).first().fill(accname);
  }
}

// ─── Types ─────────────────────────────────────────────────────────────────────

export interface JournalLine {
  date?:              string;
  voucher?:           string;
  accountType?:       'Ledger' | 'Customer' | 'Vendor' | 'Bank' | 'Fixed assets';
  account:            string;
  description?:       string;
  debit?:             number;
  credit?:            number;
  offsetAccountType?: 'Ledger' | 'Customer' | 'Vendor' | 'Bank' | 'Fixed assets';
  offsetAccount?:     string;
  currency?:          string;
  dimension1?:        string;  // Department
  dimension2?:        string;  // Cost center
  dimension3?:        string;  // Project
}
