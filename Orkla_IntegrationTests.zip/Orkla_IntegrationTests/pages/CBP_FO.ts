import {Page,expect} from '@playwright/test';
import { ENV } from '../utils/env';
import { generateSequence } from '../utils/sequenceGenerator';
import { BasePage } from './BasePage';
export class CBP_FO {
constructor(private page: Page) {}

async waitForWebshopOrderToStatus(
    statusColumn: string = 'Status',
    expectedStatus: string = 'Done',
    timeoutMinutes: number = 16,
    intervalMinutes: number = 1
): Promise<string> {
  
    const basePage = new BasePage(this.page);
    const timeout = timeoutMinutes * 60 * 1000;
    const interval = intervalMinutes * 60 * 1000;
    const start = Date.now();

    while (Date.now() - start < timeout) {

        await basePage.clickRefresh();
        const status = (await basePage.getFirstRowValue(statusColumn)).trim();
        console.log(`Current Status: ${status}`);
        if (status.toLowerCase() === expectedStatus.toLowerCase()) {
            return status;
        }
        await this.page.waitForTimeout(interval);
        console.log("Refreshing...")
        await this.page.waitForTimeout(8000);
        await basePage.clickRefresh();
        //await this.page.reload({ waitUntil: 'networkidle' });
        
    }

    throw new Error(`Status did not change to '${expectedStatus}' within ${timeoutMinutes} minutes.`);
}
  


}