
// Use Node's fs module
declare const require: any;
const fs = require('fs');
import * as XLSX from 'xlsx';

//Generic functio for create a util.ts file in demo project under utils folder, write one generic method or function for the date should accept two parameters first one days to add current date, and second should be accepect date format like ddmmyy or dd/mm/yyy or mm/dd/yyy or other famous formats for d365FO date fields
export function getFutureDate(daysToAdd: number, dateFormat: string): string {
    const currentDate = new Date();
    currentDate.setDate(currentDate.getDate() + daysToAdd);
    const day = String(currentDate.getDate()).padStart(2, '0');
    const month = String(currentDate.getMonth() + 1).padStart(2, '0');
    const year = currentDate.getFullYear();
    switch (dateFormat) {
        case 'ddmmyy':
            return `${day}${month}${String(year).slice(-2)}`;
        case 'dd/mm/yyyy':
            return `${day}/${month}/${year}`;
        case 'mm/dd/yyyy':
            return `${month}/${day}/${year}`;
        case 'yyyy-mm-dd':
            return `${year}-${month}-${day}`;
        default:
            throw new Error('Unsupported date format');
    }
}

// adding dates and skipping sunday and sturday
export function getFutureWorkingDateSkipWeekends(daysToAdd: number): string {

    const date = new Date();
    let daysAdded = 0;
    while (daysAdded < daysToAdd) {
        date.setDate(date.getDate() + 1);
        const day = date.getDay();
        // 0 = Sunday, 6 = Saturday
        if (day !== 0 && day !== 6) {
            daysAdded++;
        }
    }

    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();

    return `${day}-${month}-${year}`;
}


export function writeJsonData(
    filePath: string,
    testCaseName: string,
    data: Record<string, any>
): void {

    let jsonData: any = {};

    if (fs.existsSync(filePath)) {
        jsonData = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    }

    if (!jsonData[testCaseName]) {
        jsonData[testCaseName] = {};
    }

    Object.assign(jsonData[testCaseName], data);

    fs.writeFileSync(filePath, JSON.stringify(jsonData, null, 4));
}


export function readExcel(filePath: string, sheetName: string): any[] {

        const workbook = XLSX.readFile(filePath);

        const worksheet = workbook.Sheets[sheetName];

        return XLSX.utils.sheet_to_json(worksheet);
    }