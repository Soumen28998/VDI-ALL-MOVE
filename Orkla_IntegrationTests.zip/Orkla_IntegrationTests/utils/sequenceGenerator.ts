import fs from 'fs';
import path from 'path';

const filePath = path.resolve('test-data/sequenceStore.json');

function readStore() {
  return JSON.parse(fs.readFileSync(filePath, 'utf-8'));
}

function writeStore(data: any) {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

export function generateSequence(
  prefix: string,
  padLength = 3
): string {
  const store = readStore();

  if (store[prefix] === undefined) {
    store[prefix] = 0;
  }

  store[prefix] += 1;
  writeStore(store);

  const number = String(store[prefix]).padStart(padLength, '0');
  return `${prefix}${number}`;
}
