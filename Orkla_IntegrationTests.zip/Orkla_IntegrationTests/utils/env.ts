export const ENV = {
  baseUrl: 'https://acumant-poc.sandbox.operations.dynamics.com/?cmp=USMF',
  OrklaKAKUAT2URL: 'https://orkla-uat2.sandbox.operations.dynamics.com/?cmp=KAK',
  OrklaCBPUAT2URL: 'https://orkla-uat2.sandbox.operations.dynamics.com/?cmp=CG02&mi=DefaultDashboard',
  
  loginUrl: 'https://login.microsoftonline.com'
};
