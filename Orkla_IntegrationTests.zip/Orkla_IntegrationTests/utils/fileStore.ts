import fs from 'fs';

export function saveData(key: string, value: string) {
  const file = 'test-data/runtimeData.json';
  let data: any = {};

  if (fs.existsSync(file)) {
    data = JSON.parse(fs.readFileSync(file, 'utf-8'));
  }

  data[key] = value;
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

export function readData(key: string) {
  const file = 'test-data/runtimeData.json';
  const data = JSON.parse(fs.readFileSync(file, 'utf-8'));
  return data[key];
}
