# Power Automate Desktop setup

## 1. Create the desktop flow

Create a PAD flow named:

Excel Dashboard Runner

## 2. Create input variable

You can optionally create a list input variable named `SelectedFiles` for cloud/desktop-to-desktop scenarios. PAD supports list input variables. For this local dashboard architecture, however, the reliable handoff is the JSON job file created by the Node server.

Microsoft documents input/output variables and list inputs here:
https://learn.microsoft.com/en-us/power-automate/desktop-flows/manage-variables

## 3. Read the job file

Use PAD actions:

1. Read text from file
   File:
   `%DashboardRoot%\data\current-job.json`

2. Parse JSON / convert JSON to custom object using the JSON-related action available in your PAD version.

If your PAD version does not expose a JSON parsing action you prefer, use a PowerShell action to parse the JSON and return a JSON string/list.

Expected JSON:

{
  "jobId": "JOB-...",
  "selectedFiles": [
    "OV01_Supplier.xlsx",
    "OV02_Product.xlsx"
  ]
}

## 4. Set the list

Create/produce a list variable named:

SelectedFiles

The list must contain only file names.

Example:

SelectedFiles
  0 = OV01_Supplier.xlsx
  1 = OV02_Product.xlsx

## 5. Loop

Use:

Loop -> For each

Value to iterate:
%SelectedFiles%

Current item:
CurrentFile

Inside the loop:

1. Build full path:
   %DashboardFolder%\ExcelFiles\%CurrentFile%

2. Update that file's status to RUNNING.

3. Run your existing Excel automation.

4. If successful, update status to SUCCESS.

5. If error, update status to FAILED and store the error message.

6. Continue to the next item if your business rule allows it.

## 6. Status file

The Node server expects `data/status.json`.

For example:

{
  "OV01_Supplier.xlsx": {
    "status": "SUCCESS",
    "lastRun": "2026-09-22T03:20:00.000Z",
    "durationMs": 42000,
    "retryCount": 0,
    "error": null
  }
}

The simplest PAD implementation is to use a PowerShell action to safely update this JSON.

## 7. Recommended PowerShell helper

In PAD, add an "Run PowerShell script" action. Replace the paths with your actual dashboard folder.

Use this pattern to update one file:

param(
  [string]$StatusFile,
  [string]$FileName,
  [string]$Status,
  [Nullable[int]]$DurationMs,
  [string]$ErrorMessage
)

if (Test-Path $StatusFile) {
  $raw = Get-Content -Raw -Path $StatusFile
  if ([string]::IsNullOrWhiteSpace($raw)) { $data = @{} }
  else { $data = $raw | ConvertFrom-Json -AsHashtable }
} else {
  $data = @{}
}

if (-not $data.ContainsKey($FileName)) {
  $data[$FileName] = @{
    status = "READY"
    lastRun = $null
    durationMs = $null
    retryCount = 0
    error = $null
  }
}

if ($Status -eq "FAILED") {
  $data[$FileName].retryCount = [int]$data[$FileName].retryCount + 1
}

$data[$FileName].status = $Status
$data[$FileName].lastRun = (Get-Date).ToUniversalTime().ToString("o")
$data[$FileName].durationMs = $DurationMs
$data[$FileName].error = $ErrorMessage

$data | ConvertTo-Json -Depth 10 | Set-Content -Path $StatusFile -Encoding UTF8

## 8. Triggering PAD

The Node dashboard can trigger a configured desktop flow with:

ms-powerautomate:/console/flow/run?workflowId=YOUR_FLOW_ID&runId=YOUR_JOB_ID

Microsoft documents this URL/shortcut method here:
https://learn.microsoft.com/en-us/power-automate/desktop-flows/run-desktop-flows-url-shortcuts

If the URI does not launch on your machine, set `autoTriggerPAD` to false and first verify that the desktop flow starts correctly from the PAD console. Then enable the URI trigger.

## 9. Alternative enterprise architecture

For a Microsoft 365/Dataverse setup, replace the local JSON queue with a Power Automate cloud flow and use "Run a flow built with Power Automate for desktop". Microsoft supports passing input variables from cloud flows to desktop flows.

Documentation:
https://learn.microsoft.com/en-us/power-automate/desktop-flows/trigger-desktop-flows
