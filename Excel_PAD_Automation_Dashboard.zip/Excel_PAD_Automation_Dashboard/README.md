# Excel PAD Automation Dashboard

A local Windows dashboard that:
- scans a folder dynamically for `.xlsx` / `.xls` files
- detects company codes such as OV01, OV02, OV05, SBL, USME, NI01 from filenames
- supports checkboxes and builds `SelectedFiles`
- supports Run, Retry, Run Selected, and Run All
- stores a current job in `data/current-job.json`
- stores per-file status in `data/status.json`
- can launch Power Automate Desktop through the `ms-powerautomate:` URL scheme

## Requirements

- Windows 10/11
- Node.js 18+ recommended
- Power Automate for desktop
- Your existing Excel automation desktop flow

## Quick start

1. Put your Excel files in the folder configured in `config.json`.
2. Open `config.json`.
3. Set `folderPath`.
4. Set `padWorkflowId` to your desktop flow ID.
5. Set `autoTriggerPAD` to `true`.
6. Open Command Prompt in this folder.
7. Run:

   npm start

8. Open:

   http://localhost:3030

## Job model

The dashboard creates:

{
  "jobId": "...",
  "selectedFiles": ["OV01_Supplier.xlsx", "OV02_Product.xlsx"],
  "status": "QUEUED"
}

Power Automate Desktop should read `data/current-job.json`, process `selectedFiles` sequentially, and update `data/status.json`.

## Important

The dashboard is local. Do not expose port 3030 to the public internet without authentication and access controls.
