param(
  [Parameter(Mandatory=$true)][string]$StatusFile,
  [Parameter(Mandatory=$true)][string]$FileName,
  [Parameter(Mandatory=$true)][string]$Status,
  [Parameter(Mandatory=$false)][Nullable[int]]$DurationMs,
  [Parameter(Mandatory=$false)][string]$ErrorMessage = ""
)

$data = @{}
if (Test-Path -LiteralPath $StatusFile) {
  $raw = Get-Content -LiteralPath $StatusFile -Raw
  if (-not [string]::IsNullOrWhiteSpace($raw)) {
    $data = $raw | ConvertFrom-Json -AsHashtable
  }
}

if (-not $data.ContainsKey($FileName)) {
  $data[$FileName] = @{
    status = "READY"
    lastRun = $null
    durationMs = $null
    retryCount = 0
    error = $null
  }
}

if ($Status -eq "FAILED") {
  $data[$FileName].retryCount = [int]$data[$FileName].retryCount + 1
}

$data[$FileName].status = $Status
$data[$FileName].lastRun = (Get-Date).ToUniversalTime().ToString("o")
$data[$FileName].durationMs = $DurationMs
$data[$FileName].error = $ErrorMessage

$data | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $StatusFile -Encoding UTF8
