const http = require("http");
const fs = require("fs");
const path = require("path");
const { exec } = require("child_process");
const crypto = require("crypto");

const ROOT = __dirname;
const CONFIG_PATH = path.join(ROOT, "config.json");
const DATA_DIR = path.join(ROOT, "data");
const JOB_PATH = path.join(DATA_DIR, "current-job.json");
const STATUS_PATH = path.join(DATA_DIR, "status.json");
const HISTORY_PATH = path.join(DATA_DIR, "history.json");

fs.mkdirSync(DATA_DIR, { recursive: true });

const config = JSON.parse(fs.readFileSync(CONFIG_PATH, "utf8"));
const PUBLIC_DIR = path.join(ROOT, "public");

function readJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, "utf8")); }
  catch { return fallback; }
}
function writeJson(file, value) {
  fs.writeFileSync(file, JSON.stringify(value, null, 2), "utf8");
}
function now() { return new Date().toISOString(); }

function detectCompany(fileName) {
  const upper = fileName.toUpperCase();
  const codes = Array.isArray(config.companyCodes) ? config.companyCodes : [];
  return codes.find(c => upper.includes(String(c).toUpperCase())) || "UNKNOWN";
}

function scanFiles() {
  const folder = config.folderPath;
  if (!fs.existsSync(folder)) {
    return { error: `Folder does not exist: ${folder}`, files: [] };
  }

  const names = fs.readdirSync(folder, { withFileTypes: true })
    .filter(e => e.isFile() && /\.xlsx?$/i.test(e.name))
    .map(e => e.name)
    .sort((a,b) => a.localeCompare(b, undefined, { numeric: true }));

  const statuses = readJson(STATUS_PATH, {});
  return {
    files: names.map(name => ({
      fileName: name,
      company: detectCompany(name),
      ...(statuses[name] || {
        status: "READY",
        lastRun: null,
        durationMs: null,
        retryCount: 0,
        error: null
      })
    }))
  };
}

function updateStatus(fileName, patch) {
  const statuses = readJson(STATUS_PATH, {});
  statuses[fileName] = {
    ...(statuses[fileName] || {
      status: "READY", lastRun: null, durationMs: null, retryCount: 0, error: null
    }),
    ...patch,
    updatedAt: now()
  };
  writeJson(STATUS_PATH, statuses);
}

function appendHistory(job) {
  const history = readJson(HISTORY_PATH, []);
  history.unshift(job);
  writeJson(HISTORY_PATH, history.slice(0, 500));
}

function triggerPAD(jobId) {
  if (!config.autoTriggerPAD) return { triggered: false, reason: "autoTriggerPAD is false" };
  const flowId = String(config.padWorkflowId || "").trim();
  if (!flowId || flowId.includes("PASTE-YOUR")) {
    return { triggered: false, reason: "Configure padWorkflowId in config.json" };
  }

  // Microsoft documents the ms-powerautomate URL scheme for starting desktop flows.
  const uri = `ms-powerautomate:/console/flow/run?workflowId=${encodeURIComponent(flowId)}&runId=${encodeURIComponent(jobId)}`;
  exec(`start "" "${uri}"`, { windowsHide: true }, (error) => {
    if (error) console.error("PAD trigger error:", error.message);
  });
  return { triggered: true, uri };
}

function createJob(selectedFiles, mode = "selected") {
  const files = Array.from(new Set(selectedFiles)).filter(Boolean);
  if (!files.length) throw new Error("No Excel files selected.");

  const available = scanFiles().files.map(f => f.fileName);
  const invalid = files.filter(f => !available.includes(f));
  if (invalid.length) throw new Error(`Files not found in folder: ${invalid.join(", ")}`);

  const jobId = `JOB-${new Date().toISOString().replace(/\D/g,"").slice(0,14)}-${crypto.randomBytes(2).toString("hex")}`;
  const job = {
    jobId,
    mode,
    status: "QUEUED",
    createdAt: now(),
    startedAt: null,
    completedAt: null,
    currentFile: null,
    selectedFiles: files
  };

  writeJson(JOB_PATH, job);
  for (const file of files) updateStatus(file, { status: "QUEUED", error: null });

  const trigger = triggerPAD(jobId);
  job.trigger = trigger;
  writeJson(JOB_PATH, job);
  return job;
}

function send(res, status, data, type = "application/json") {
  res.writeHead(status, { "Content-Type": `${type}; charset=utf-8`, "Cache-Control": "no-store" });
  res.end(type.startsWith("application/json") ? JSON.stringify(data) : data);
}

function body(req) {
  return new Promise((resolve, reject) => {
    let raw = "";
    req.on("data", c => { raw += c; if (raw.length > 2e6) req.destroy(); });
    req.on("end", () => {
      try { resolve(raw ? JSON.parse(raw) : {}); } catch(e) { reject(e); }
    });
    req.on("error", reject);
  });
}

const mime = { ".html":"text/html", ".js":"text/javascript", ".css":"text/css", ".json":"application/json" };

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host}`);

    if (req.method === "GET" && url.pathname === "/api/files") {
      return send(res, 200, scanFiles());
    }
    if (req.method === "GET" && url.pathname === "/api/job") {
      return send(res, 200, readJson(JOB_PATH, null));
    }
    if (req.method === "GET" && url.pathname === "/api/history") {
      return send(res, 200, readJson(HISTORY_PATH, []));
    }
    if (req.method === "GET" && url.pathname === "/api/config") {
      return send(res, 200, {
        folderPath: config.folderPath,
        port: config.port,
        companyCodes: config.companyCodes,
        autoTriggerPAD: config.autoTriggerPAD,
        padConfigured: Boolean(config.padWorkflowId && !String(config.padWorkflowId).includes("PASTE-YOUR"))
      });
    }

    if (req.method === "POST" && url.pathname === "/api/run") {
      const data = await body(req);
      const selected = data.runAll ? scanFiles().files.map(x => x.fileName) : data.selectedFiles;
      const job = createJob(selected || [], data.runAll ? "all" : "selected");
      return send(res, 201, job);
    }

    if (req.method === "POST" && url.pathname === "/api/retry") {
      const data = await body(req);
      const job = createJob([data.fileName], "retry");
      return send(res, 201, job);
    }

    if (req.method === "POST" && url.pathname === "/api/refresh") {
      return send(res, 200, scanFiles());
    }

    // Static files
    let filePath = url.pathname === "/" ? path.join(PUBLIC_DIR, "index.html") :
      path.join(PUBLIC_DIR, url.pathname.replace(/^\/+/, ""));
    if (!filePath.startsWith(PUBLIC_DIR)) return send(res, 403, { error: "Forbidden" });
    if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
      const ext = path.extname(filePath).toLowerCase();
      return send(res, 200, fs.readFileSync(filePath), mime[ext] || "application/octet-stream");
    }
    return send(res, 404, { error: "Not found" });
  } catch (e) {
    console.error(e);
    return send(res, 400, { error: e.message || String(e) });
  }
});

server.listen(config.port, () => {
  console.log(`Dashboard: http://localhost:${config.port}`);
  console.log(`Watching folder: ${config.folderPath}`);
  console.log(`PAD auto-trigger: ${config.autoTriggerPAD}`);
});

// Refresh status/file view when folder changes. The dashboard itself polls the API.
if (fs.existsSync(config.folderPath)) {
  fs.watch(config.folderPath, { persistent: true }, () => {});
}
