let allFiles = [];
const selected = new Set();

async function api(url, options={}) {
  const r = await fetch(url, {headers: {"Content-Type":"application/json"}, ...options});
  const data = await r.json();
  if (!r.ok) throw new Error(data.error || "Request failed");
  return data;
}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c]));}
function statusClass(s){return "s-"+String(s||"READY").toLowerCase();}
function fmtDate(x){return x ? new Date(x).toLocaleString() : "—";}
function fmtDuration(ms){if(ms==null)return "—";let s=Math.round(ms/1000);return s<60?`${s}s`:`${Math.floor(s/60)}m ${s%60}s`;}

async function refreshAll(){
  try{
    const [f,c,j]=await Promise.all([api("/api/files"),api("/api/config"),api("/api/job")]);
    allFiles=f.files||[];
    document.getElementById("folderLabel").textContent=c.folderPath;
    const b=document.getElementById("padBadge");
    b.textContent=c.padConfigured ? "PAD: connected" : "PAD: configure flow ID";
    b.className="badge "+(c.padConfigured?"ok":"warn");
    const companies=[...new Set(allFiles.map(x=>x.company))].sort();
    const sel=document.getElementById("company"), old=sel.value;
    sel.innerHTML='<option value="ALL">All companies</option>'+companies.map(x=>`<option>${esc(x)}</option>`).join("");
    if(companies.includes(old))sel.value=old;
    updateStats(); render();
  }catch(e){toast(e.message)}
}
function updateStats(){
  const c=s=>allFiles.filter(x=>x.status===s).length;
  document.getElementById("total").textContent=allFiles.length;
  document.getElementById("ready").textContent=c("READY");
  document.getElementById("running").textContent=c("RUNNING");
  document.getElementById("success").textContent=c("SUCCESS");
  document.getElementById("failed").textContent=c("FAILED");
}
function visible(){
  const q=document.getElementById("search").value.toLowerCase();
  const co=document.getElementById("company").value;
  const st=document.getElementById("statusFilter").value;
  return allFiles.filter(x=>
    (!q||x.fileName.toLowerCase().includes(q)) &&
    (co==="ALL"||x.company===co) &&
    (st==="ALL"||x.status===st)
  );
}
function render(){
  const rows=document.getElementById("rows"), v=visible();
  rows.innerHTML=v.length?v.map(x=>`<tr>
    <td><input type="checkbox" ${selected.has(x.fileName)?"checked":""} onchange="pick('${esc(x.fileName)}',this.checked)"></td>
    <td class="file">${esc(x.fileName)}</td>
    <td><span class="company-pill">${esc(x.company)}</span></td>
    <td><span class="status ${statusClass(x.status)}">${esc(x.status)}</span></td>
    <td>${fmtDate(x.lastRun)}</td>
    <td>${fmtDuration(x.durationMs)}</td>
    <td>${x.retryCount||0}</td>
    <td><div class="row-actions">
      <button class="mini run" onclick="runOne('${esc(x.fileName)}')">▶ Run</button>
      <button class="mini" onclick="retryOne('${esc(x.fileName)}')">↻ Retry</button>
    </div></td>
  </tr>`).join(""):`<tr><td colspan="8" class="empty">No Excel files match the current filters.</td></tr>`;
  document.getElementById("selectedCount").textContent=selected.size;
  document.getElementById("selectedPreview").textContent="SelectedFiles = "+JSON.stringify([...selected]);
}
function pick(file,on){on?selected.add(file):selected.delete(file);render();}
function toggleAll(on){visible().forEach(x=>on?selected.add(x.fileName):selected.delete(x.fileName));render();}
function selectAllVisible(){toggleAll(true)}
function clearSelection(){selected.clear();render()}
async function submit(files,mode="selected"){
  if(!files.length){toast("Select at least one Excel file.");return}
  try{
    const job=await api("/api/run",{method:"POST",body:JSON.stringify({selectedFiles:files})});
    toast(`Job ${job.jobId} queued.`);
    refreshAll();
  }catch(e){toast(e.message)}
}
function runSelected(){submit([...selected])}
async function runAll(){
  try{
    const job=await api("/api/run",{method:"POST",body:JSON.stringify({runAll:true})});
    toast(`All files queued: ${job.selectedFiles.length}`);
    refreshAll();
  }catch(e){toast(e.message)}
}
async function runOne(file){submit([file])}
async function retryOne(file){
  try{
    const job=await api("/api/retry",{method:"POST",body:JSON.stringify({fileName:file})});
    toast(`Retry queued: ${job.jobId}`);
    refreshAll();
  }catch(e){toast(e.message)}
}
function toast(msg){const t=document.getElementById("toast");t.textContent=msg;t.classList.add("show");clearTimeout(window._toast);window._toast=setTimeout(()=>t.classList.remove("show"),2800)}
refreshAll();
setInterval(refreshAll,3000);
